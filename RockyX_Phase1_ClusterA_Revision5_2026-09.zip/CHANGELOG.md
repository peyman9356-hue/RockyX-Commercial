
## Architecture Revision 5 — Phase 1 Cluster A Local Data Integrity
- Rebased from the actually stored Revision 3 source snapshot after detecting that the previously reported Revision 4 archive was not present in the current Library listing.
- Reconstructed the four documented Revision 4 hardening corrections (Build-Candidate terminology, dog-profile corruption refusal, monotonic profileVersion save, multi-question quiz UI) in the new source snapshot.
- Replaced silent empty-list recovery in `SubmissionStore` and `LocalSyncStore` with quarantine + explicit `LocalDataCorruptionException`.
- Invalid persisted enum values and invalid sync invariants now fail closed instead of silently defaulting.
- Added local-data corruption policy unit coverage.
- Build status remains NOT_REBUILT; no APK/AAB claim is made.
# Changelog — Phase 28

## 0.32.0 — Integrated Release
- Consolidated Phases 1–31 into a single application/backend source tree.
- Added CI Gradle provisioning and integrated static checks.
- Added explicit release build configuration without committed signing secrets.
- Added end-to-end integration readiness documentation.


## 0.28.0
- Added Android Google Play purchase orchestration.
- Added provider-neutral purchase verification boundary.
- Added fail-closed handling for unconfigured backend verification.
- Added product/offer lookup and purchase launch.
- Added strict PURCHASED-state processing.
- Kept entitlement authority on the secure backend.

## 0.25.0 — Phase 25
- Added provider-neutral AI personalization with deterministic offline fallback.
- Added safety validation, confidence/explanation signals, and authorized backend recommendations endpoint.

# CHANGELOG

## 0.24.0 — Phase 24
- Added Admin/CMS content management boundary.
- Added draft/publish lifecycle, optimistic revision control, PostgreSQL persistence, revision history and audit events.
- Added role + scope protected admin content APIs and locale-based published catalog endpoint.
- Added content JSON validation and bounded document size.

# Changelog

## 0.23.0 — Phase 23
- Added centralized per-app locale management.
- Added English and Persian resource translations for core UI.
- Enabled Android RTL support.
- Added locale-aware number, currency, and date/time formatting.
- Added language/region settings screen with safe recreation.
- Added globalization documentation and regression checks.

## 0.21.0 — Phase 21
- Crash/error recovery and reliability hardening.
- Bounded background retries, crash marker, safe local failure queue.
- Structured backend errors, request-ID correlation, readiness checks.

# Changelog

## 0.20.0
- Added backend Telemetry boundary and request/error counters.
- Added health/readiness endpoints and development metrics snapshot.
- Added privacy sanitization for telemetry tags.
- Added Android analytics event/repository boundary with persistent offline buffering.
- Bumped Android versionCode to 20 and versionName to 0.20.0.


## Phase 25
AI Personalization is provider-neutral, safety-gated, deterministic/offline-capable, and does not embed model credentials or vendor SDKs.

## 0.26.0 — Phase 26
- Added Google Play Billing 9.1.0 client adapter.
- Added secure backend purchase verification boundary.
- Added Google Play subscriptions v2 verification adapter.
- Added server-side entitlement persistence and token-fingerprint purchase records.
- Added product allow-list and cross-account purchase-token protection.
- Added server-side acknowledgement flow with persisted acknowledgement state.
- Added production fail-closed billing configuration.
- Local trial UI is debug-only; production cannot self-grant entitlement.


## 0.27.0 — Phase 27
- Added authenticated Google Play RTDN Pub/Sub push endpoint.
- Added OIDC token validation boundary with fixed audience and service-account identity checks.
- Added durable RTDN message deduplication with recovery lease in PostgreSQL.
- Added subscription lifecycle reconciliation by re-verifying the purchase token with Google Play.
- Added entitlement updates for RTDN-driven state changes.
- Unknown tokens are ignored safely; invalid notifications fail without marking the message processed.
- Added production fail-closed RTDN configuration.


## 0.29.0 — Phase 29
- Added authenticated Ktor Android API client boundary.
- Added server entitlement synchronization.
- Hardened purchase verification idempotency.
- Hardened Google Play offer selection and purchase UX.


## 0.30.0 — Phase 30
- Added first-party RS256 session access tokens.
- Added durable rotating refresh sessions and auth exchange/refresh/logout APIs.
- Added Android Keystore-backed token storage and provider-neutral session coordinator.
- Production remains fail-closed until real identity-provider configuration exists.


## 0.31.0 — Phase 31
- Added real Google Credential Manager identity adapter.
- Added server-side Google OIDC verification and provider-aware exchange.
- Added authenticated account profile/onboarding persistence.
- Added passkey Credential Manager transport boundary without fake verification.

## Master Ecosystem Foundation — 2026-09
- Added lifelong Dog Identity domain with multi-dog ownership and optimistic profile versioning.
- Added durable dog event/history model.
- Added device identity foundation for future Smart Module/Collar hardware.
- Added safety event foundation separating location data from transport.
- Added owner-controlled, expiring/revocable veterinary access grants.
- Added AI insight storage separating evidence, inference and recommendation.
- Added app-side device/safety/AI domain contracts without vendor SDK coupling.
- Added Flyway V11 migration; existing migrations remain unchanged.
- Added ecosystem domain tests.

## Architecture Revision 2 — UX-01 Owner-First Integration
- Integrated UX-01 — Simple, Fast, Owner-First into the Master Product Definition.
- Integrated UX-01 into the Master System Architecture as a navigation/information-architecture constraint.
- Added one/two-tap routine-task target, progressive disclosure, cross-platform navigation consistency, owner-task acceptance gate, and UX state requirements.

## Architecture Revision 3 — Atom-Level Hardening
- Performed forensic review of the ecosystem foundation and UX-01 architecture changes.
- Added shared ecosystem validation invariants across in-memory and PostgreSQL persistence.
- Closed cross-owner idempotency/collision paths for ecosystem entities.
- Added database-level dog/owner integrity constraints for ecosystem child records.
- Hardened safety coordinates, JSON payloads, input lengths and query limits.
- Hardened PostgreSQL persistence semantics and clarified explicit non-claims around build/deployment validation.

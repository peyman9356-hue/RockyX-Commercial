package com.rockyx.app

import android.app.Activity
import android.content.Context
import com.rockyx.app.i18n.LocaleManager
import com.rockyx.app.i18n.Globalization
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.os.Build
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.rockyx.app.media.MediaDescriptor
import com.rockyx.app.media.MediaEngine
import com.rockyx.app.domain.model.*
import com.rockyx.app.ui.AppController
import com.rockyx.app.ui.shell.AppDestination
import com.rockyx.app.ui.shell.AppShellState
import com.rockyx.app.ui.shell.SessionSnapshot
import com.rockyx.app.ui.shell.SessionStore
import com.rockyx.app.ui.shell.key
import com.rockyx.app.background.NotificationCenter
import com.rockyx.app.background.RockyXBackgroundWork

@UnstableApi
class MainActivity : Activity() {
    override fun attachBaseContext(newBase: Context) { super.attachBaseContext(LocaleManager.wrap(newBase)) }
    private fun s(id: Int, vararg args: Any): String = getString(id, *args)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private lateinit var app: AppController
    private var mediaEngine: MediaEngine? = null
    private var pendingSubmissionMissionId: String? = null
    private val billingScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var billingClient: com.rockyx.app.data.commerce.GooglePlayBillingClient? = null
    private var pendingSubmissionVisibility: SubmissionVisibility = SubmissionVisibility.PRIVATE
    private var backTarget: (() -> Unit)? = null
    private var currentSection: String = ""
    private val shellState = AppShellState()
    private lateinit var sessionStore: SessionStore
    private lateinit var shellContent: FrameLayout
    private lateinit var shellRoot: LinearLayout
    private var shellReady = false

    private val bgColor = Color.rgb(250, 250, 248)
    private val inkColor = Color.rgb(24, 24, 24)
    private val mutedColor = Color.rgb(105, 105, 105)
    private val accentColor = Color.rgb(24, 24, 24)
    private val accentSoft = Color.rgb(244, 244, 241)
    private val pickVideo = 801
    private val captureVideo = 802
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = true
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = true
        app = AppController(this)
        sessionStore = SessionStore()
        installRockyShell()
        NotificationCenter.createChannels(this)
        RockyXBackgroundWork.schedule(this)
        if (app.reliability.consumePreviousCrash()) Toast.makeText(this, s(com.rockyx.app.R.string.previous_crash), Toast.LENGTH_LONG).show()
        if (getPreferences(Context.MODE_PRIVATE).getBoolean("onboarding_complete_v1", false)) showHome() else showWelcome()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val missionId = pendingSubmissionMissionId ?: return
        val source = data.data ?: return
        val local = importVideo(source) ?: run { Toast.makeText(this, s(com.rockyx.app.R.string.camera_no_storage), Toast.LENGTH_LONG).show(); return }
        showSubmissionReview(missionId, local)
    }

    private fun importVideo(source: Uri): String? = runCatching {
        val dir = File(filesDir, "submissions").apply { mkdirs() }
        val file = File(dir, "${UUID.randomUUID()}.mp4")
        contentResolver.openInputStream(source).use { input -> requireNotNull(input); FileOutputStream(file).use { output -> input.copyTo(output) } }
        file.absolutePath
    }.getOrNull()

    override fun onBackPressed() {
        if (shellState.leftMenuOpen || shellState.rightPanel != null) {
            shellState.closePanels()
            showHome()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() { billingScope.cancel(); billingClient?.disconnect(); billingClient = null; mediaEngine?.release(); mediaEngine = null; app.api.close(); super.onDestroy() }
    private fun setScreen(name: String, back: (() -> Unit)? = null) {
        currentSection = name
        backTarget = back
        val destination = legacyDestination(name)
        shellState.navigateTo(destination)
        val existingSession = sessionStore.get(destination)
        sessionStore.activate(existingSession ?: SessionSnapshot(destination))
    }

    private fun legacyDestination(name: String): AppDestination = when {
        name == "home" -> AppDestination.Home
        name == "courses" -> AppDestination.Library
        name == "progress" -> AppDestination.Progress
        name == "dog" -> AppDestination.Dog
        name == "commerce" -> AppDestination.Commerce
        name == "account" -> AppDestination.Account
        name == "settings" || name == "language" -> AppDestination.Settings
        name.startsWith("course:") -> AppDestination.Course(name.removePrefix("course:"))
        name.startsWith("lesson:") -> {
            val parts = name.removePrefix("lesson:").split(":", limit = 2)
            if (parts.size == 2) AppDestination.Lesson(parts[0], parts[1]) else AppDestination.Home
        }
        else -> AppDestination.Home
    }

    private fun rounded(fill: Int, radius: Float = 22f): GradientDrawable = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius.toInt()).toFloat()
    }

    private fun base(title: String, subtitle: String? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(24))
        setBackgroundColor(bgColor)
        val top = LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(56)
        }
        backTarget?.let { action ->
            top.addView(TextView(this@MainActivity).apply {
                text = "‹"; textSize = 38f; gravity = Gravity.CENTER; setTextColor(inkColor)
                background = rounded(Color.WHITE, 16f)
                setOnClickListener { action() }
                contentDescription = "بازگشت"
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) })
        }
        top.addView(TextView(this@MainActivity).apply {
            text = title; textSize = 25f; typeface = Typeface.DEFAULT_BOLD; setTextColor(inkColor)
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        addView(top)
        subtitle?.let { addView(TextView(this@MainActivity).apply {
            text = it; textSize = 14f; setTextColor(mutedColor); setPadding(0, dp(6), 0, dp(18))
        }) }
    }

    private fun button(text: String, enabled: Boolean = true, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; isEnabled = enabled; textSize = 15f
        setTextColor(if (enabled) Color.WHITE else mutedColor)
        background = rounded(if (enabled) accentColor else Color.rgb(225, 225, 221), 16f)
        setPadding(dp(14), dp(4), dp(14), dp(4))
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun installRockyShell() {
        shellRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
        }

        val topBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = ColorDrawable(bgColor)
        }
        topBar.addView(iconButton("⋯", "منوی بیشتر") { 
            if (shellState.leftMenuOpen) { shellState.closePanels(); showHome() } else { shellState.toggleLeftMenu(); showShellMenu() }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        topBar.addView(TextView(this).apply {
            text = "ROCKY X"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(inkColor)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        topBar.addView(iconButton("▤", "کتابخانه") {
            if (shellState.rightPanel == AppShellState.RightPanel.LIBRARY) { shellState.closePanels(); showHome() }
            else { shellState.openRightPanel(AppShellState.RightPanel.LIBRARY); showLibraryPanel() }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        shellRoot.addView(topBar, LinearLayout.LayoutParams(-1, dp(68)))

        shellContent = FrameLayout(this).apply { setBackgroundColor(bgColor) }
        shellRoot.addView(shellContent, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(10))
            background = rounded(Color.WHITE, 22f)
        }
        val input = EditText(this).apply {
            hint = "از Rocky X چیزی بپرس…"
            textSize = 14f
            maxLines = 3
            background = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(10), 0, dp(10), 0)
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        composer.addView(iconButton("➤", "ارسال") {
            val q = input.text.toString().trim()
            if (q.isNotBlank()) {
                Toast.makeText(this@MainActivity, "Coach: ${q.take(80)}", Toast.LENGTH_SHORT).show()
                input.text.clear()
            }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        shellRoot.addView(composer, LinearLayout.LayoutParams(-1, dp(70)).apply { setMargins(dp(10), 0, dp(10), dp(8)) })
        shellReady = true
    }

    private fun iconButton(label: String, description: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 20f
        isAllCaps = false
        setTextColor(inkColor)
        background = ColorDrawable(Color.TRANSPARENT)
        contentDescription = description
        setOnClickListener { action() }
    }

    private fun renderShellContent(content: LinearLayout) {
        if (!shellReady) { setContentView(content); return }
        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor); addView(content) }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(v.paddingLeft, bars.top, v.paddingRight, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(scroll)
        shellContent.removeAllViews()
        shellContent.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(shellRoot)
    }

    private fun page(content: LinearLayout, useShell: Boolean = true) {
        if (!useShell) {
            val scroll = ScrollView(this).apply { setBackgroundColor(bgColor); addView(content) }
            ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
                val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(v.paddingLeft, bars.top, v.paddingRight, bars.bottom)
                insets
            }
            ViewCompat.requestApplyInsets(scroll)
            setContentView(scroll)
            return
        }
        renderShellContent(content)
    }

    private fun panelHeader(title: String, subtitle: String? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(12))
        addView(TextView(this@MainActivity).apply { text = title; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(inkColor) })
        subtitle?.let { addView(TextView(this@MainActivity).apply { text = it; textSize = 13f; setTextColor(mutedColor); setPadding(0, dp(5), 0, 0) }) }
    }

    private fun menuRow(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setTextColor(inkColor)
        background = rounded(Color.WHITE, 14f)
        setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { action() }
    }

    private fun libraryCategory(title: String, children: List<String> = emptyList()): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var expanded = false
        lateinit var header: Button
        header = menuRow("$title   +") {
            expanded = !expanded
            header.text = "$title   ${if (expanded) "−" else "+"}"
            for (i in 1 until box.childCount) box.getChildAt(i).visibility = if (expanded) View.VISIBLE else View.GONE
        }
        box.addView(header, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(4), 0, dp(4)) })
        children.forEach { child ->
            box.addView(menuRow("   $child") { showCourses() }, LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(dp(12), 0, 0, 0) })
        }
        for (i in 1 until box.childCount) box.getChildAt(i).visibility = View.GONE
        return box
    }

    private fun showShellMenu() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(24)); setBackgroundColor(bgColor) }
        root.addView(panelHeader("منوی بیشتر", "امکانات عمومی و سیستمی Rocky X"))
        root.addView(menuRow("به‌روزرسانی نرم‌افزار") { Toast.makeText(this, "بررسی نسخه جدید در مسیر Update انجام می‌شود.", Toast.LENGTH_SHORT).show() })
        root.addView(menuRow("فایل‌های آپلودشده") { Toast.makeText(this, "مدیریت فایل‌ها در بخش Files انجام می‌شود.", Toast.LENGTH_SHORT).show() })
        root.addView(menuRow("زبان نرم‌افزار") { showLanguageSettings() })
        root.addView(menuRow("خانه") { shellState.closePanels(); showHome() })
        page(root)
    }

    private fun showLibraryPanel() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(18)); setBackgroundColor(bgColor) }
        root.addView(panelHeader("ROCKY X", "کتابخانه آموزشی"))
        val search = EditText(this).apply {
            hint = "جست‌وجوی درس…"
            textSize = 14f
            singleLine = true
            background = rounded(Color.WHITE, 16f)
            setPadding(dp(14), 0, dp(14), 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(libraryCategory("بیماری سگ‌ها"))
        root.addView(libraryCategory("نژاد سگ‌ها", listOf("سگ‌های بزرگ", "سگ‌های متوسط", "سگ‌های کوچک")))
        root.addView(libraryCategory("آموزش مبتدی"))
        root.addView(libraryCategory("آموزش متوسط"))
        root.addView(libraryCategory("آموزش پیشرفته PRO"))
        root.addView(menuRow("خانه") { shellState.closePanels(); showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(10), 0, 0) })
        root.addView(menuRow("👤 حساب کاربری") { showAccountProfile() }, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(10), 0, 0) })
        page(root)
    }

    // Compatibility boundary: general settings are intentionally routed through More Menu in Phase 1.
    private fun showSettingsPanel() { showShellMenu() }

    private fun section(title: String, subtitle: String? = null): LinearLayout = base(title, subtitle)

    private fun completeOnboarding() {
        getPreferences(Context.MODE_PRIVATE).edit().putBoolean("onboarding_complete_v1", true).apply()
        showHome()
    }

    private fun showWelcome() {
        setScreen("welcome")
        val root = section("ROCKY X", "آموزش هوشمند و مرحله‌ای برای سگ تو")
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(TextView(this).apply {
            text = "از اولین فرمان تا آموزش پیشرفته، Rocky X مسیر آموزش را بر اساس سگ و پیشرفت واقعی او تنظیم می‌کند."
            textSize = 18f
            setPadding(0, dp(16), 0, dp(28))
            gravity = Gravity.CENTER
        })
        root.addView(button("🚀 شروع آموزش") { showOnboardingDog() }, LinearLayout.LayoutParams(-1, dp(64)).apply { setMargins(0, 0, 0, dp(12)) })
        root.addView(button("🔐 ورود به حساب") { signInWithGoogle() }, LinearLayout.LayoutParams(-1, dp(58)))
        page(root)
    }

    private fun showOnboardingDog() {
        setScreen("onboarding-dog")
        val dog = app.dog.current()
        val root = section("1 از 2 — معرفی سگ", "این اطلاعات پایه، مسیر آموزش Rocky X را شخصی می‌کند.")
        val name = EditText(this).apply { hint = "نام سگ"; setText(if (dog.name == "Rocky") "" else dog.name) }
        val age = EditText(this).apply { hint = "سن به ماه"; inputType = 2; setText(if (dog.ageMonths > 0) dog.ageMonths.toString() else "") }
        val breed = EditText(this).apply { hint = "نژاد"; setText(dog.breed) }
        val level = Spinner(this).apply {
            val values = arrayOf("Beginner", "Intermediate", "Advanced")
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, values)
            setSelection(values.indexOf(dog.level).coerceAtLeast(0))
        }
        root.addView(name); root.addView(age); root.addView(breed)
        root.addView(TextView(this).apply { text = "سطح فعلی"; setPadding(0, dp(16), 0, dp(4)) }); root.addView(level)
        root.addView(button("ادامه →") {
            val cleanName = name.text.toString().trim()
            if (cleanName.isBlank()) { name.error = "نام سگ را وارد کن"; return@button }
            val updated = dog.copy(name = cleanName, ageMonths = age.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: dog.ageMonths, breed = breed.text.toString().trim(), level = level.selectedItem.toString(), profileVersion = dog.profileVersion + 1)
            app.dog.save(updated)
            showOnboardingGoals()
        }, LinearLayout.LayoutParams(-1, dp(60)).apply { setMargins(0, dp(24), 0, dp(8)) })
        root.addView(button("بعداً") { completeOnboarding() })
        page(root)
    }

    private fun showOnboardingGoals() {
        setScreen("onboarding-goals") { showOnboardingDog() }
        val dog = app.dog.current()
        val root = section("2 از 2 — هدف آموزشی", "چند هدف را انتخاب کن تا اولین مسیر Rocky X ساخته شود.")
        val options = linkedMapOf(
            "اطاعت پایه" to "obedience",
            "تمرکز" to "focus",
            "فراخوانی / بیا" to "recall",
            "کنترل هیجان" to "impulsivity",
            "ایمنی" to "safety"
        )
        val checks = options.map { (label, _) -> CheckBox(this).apply { text = label; isChecked = dog.goals.contains(options[label]) } }
        checks.forEach { root.addView(it) }
        root.addView(button("🎯 ساخت برنامه من") {
            val goals = checks.mapIndexedNotNull { i, c -> if (c.isChecked) options.values.elementAt(i) else null }.ifEmpty { listOf("obedience") }
            app.dog.save(dog.copy(goals = goals, profileVersion = dog.profileVersion + 1))
            completeOnboarding()
        }, LinearLayout.LayoutParams(-1, dp(64)).apply { setMargins(0, dp(24), 0, dp(8)) })
        root.addView(button("← بازگشت") { showOnboardingDog() })
        page(root)
    }

    private fun nav(root: LinearLayout) {
        // Legacy five-button navigation is intentionally disabled. Rocky X now
        // uses the fixed AppShell: left menu, active content, Library/Settings
        // rail, and bottom composer. Underlying feature actions remain reusable.
    }

    private fun showCourses() {
        setScreen("courses") { showHome() }
        val root = section("دوره‌ها", "مسیرهای آموزشی بر اساس سطح و دسترسی")
        app.catalog().forEach { course ->
            val p = app.courseProgress(course.id)
            val accessible = app.canAccess(course.access)
            root.addView(TextView(this).apply { text = "${if (course.access == Access.PRO) "🔒 PRO" else "🆓 FREE"}\n${course.title}\n${course.description}\nپیشرفت: ${p.percent}%"; textSize = 17f; setPadding(0, dp(12), 0, dp(8)) })
            root.addView(button(if (accessible) "ادامه دوره" else "مشاهده PRO") { if (accessible) showCourse(course.id) else showCommerce() }, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, 0, 0, dp(14)) })
        }
        nav(root); page(root)
    }

    private fun showProgress() {
        setScreen("progress") { showHome() }
        val dog = app.dog.current(); val root = section("پیشرفت ${dog.name}", "وضعیت واقعی یادگیری، تمرین و مهارت‌ها")
        app.catalog().forEach { course ->
            val p = app.courseProgress(course.id)
            root.addView(TextView(this).apply { text = "${course.title}\n${p.completedLessons} از ${p.totalLessons} درس — ${p.percent}%"; textSize = 18f; setPadding(0, dp(12), 0, dp(16)) })
        }
        val all = app.catalog().flatMap { it.chapters.flatMap { c -> c.lessons } }
        val done = all.count { val st = app.state(it.id)?.state; st == LearningState.COMPLETED || st == LearningState.MASTERED }
        root.addView(TextView(this).apply { text = "مهارت‌های تکمیل‌شده: $done\nهدف فعلی: ${dog.goals.joinToString("، ").ifBlank { "اطاعت پایه" }}"; textSize = 16f; setPadding(0, dp(8), 0, dp(20)) })
        app.catalog().forEach { course -> app.personalized(course.id, 1).firstOrNull()?.let { r -> root.addView(button("⭐ پیشنهاد بعدی: ${r.lesson.title}") { showLesson(course, r.lesson) }) } }
        nav(root); page(root)
    }

    private fun showHome() {
        setScreen("home")
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(24)); setBackgroundColor(bgColor) }
        root.addView(TextView(this).apply { text = "امروز با ${dog.name} چه کار کنیم؟"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD; setTextColor(inkColor) })
        root.addView(TextView(this).apply { text = "یک قدم مشخص، متناسب با سگ تو."; textSize = 14f; setTextColor(mutedColor); setPadding(0, dp(6), 0, dp(16)) })
        root.addView(menuRow("تمرین امروز") { showCourses() }, LinearLayout.LayoutParams(-1, dp(62)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(menuRow("پروفایل سگ") { showDog() }, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(menuRow("ادامه آموزش") { showCourses() }, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(menuRow("پیشنهاد امروز") { showCourses() }, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(menuRow("پیشرفت آموزش") { showProgress() }, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(TextView(this).apply { text = "Library برای دسترسی به تمام آموزش‌ها در بالای محیط همیشه در دسترس است."; textSize = 13f; setTextColor(mutedColor); setPadding(0, dp(12), 0, 0) })
        page(root)
    }

    private fun showAccountProfile() {
        setScreen("account") { showHome() }
        if (!app.auth.isSignedIn()) { showHome(); return }
        val root = base("حساب کاربری", "هویت حساب توسط سرور Rocky X مدیریت می‌شود.")
        root.addView(TextView(this).apply { text = "User ID: ${app.auth.currentUserId() ?: "-"}"; setPadding(0, dp(8), 0, dp(16)) })
        val display = EditText(this).apply { hint = "نام نمایشی (اختیاری)" }
        root.addView(display)
        root.addView(button("ذخیره پروفایل") {
            billingScope.launch {
                runCatching { app.api.updateAccountProfile(com.rockyx.app.data.network.AccountProfileUpdate(display.text.toString().trim().ifBlank { null }, Globalization.languageTag(this@MainActivity), java.util.TimeZone.getDefault().id)) }
                    .onSuccess { Toast.makeText(this@MainActivity, "پروفایل ذخیره شد.", Toast.LENGTH_SHORT).show(); showHome() }
                    .onFailure { Toast.makeText(this@MainActivity, "ذخیره پروفایل ناموفق بود.", Toast.LENGTH_LONG).show() }
            }
        })
        root.addView(button("خروج از حساب") {
            billingScope.launch { app.sessionAuth.signOut(); showHome() }
        })
        page(root)
        billingScope.launch {
            runCatching { app.api.fetchAccountProfile() }.onSuccess { profile -> display.setText(profile.displayName.orEmpty()) }
        }
    }

    private fun showLanguageSettings() {
        setScreen("language") { showHome() }
        val root = base(s(R.string.language_selector_title), s(R.string.language_selector_subtitle))
        val current = LocaleManager.getLanguage(this)
        val values = arrayOf(LocaleManager.SYSTEM, LocaleManager.ENGLISH, LocaleManager.PERSIAN)
        val labels = arrayOf(s(R.string.language_system), s(R.string.language_english), s(R.string.language_persian))
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels); setSelection(values.indexOf(current).coerceAtLeast(0)) }
        root.addView(spinner)
        root.addView(TextView(this).apply { text = "Locale: ${Globalization.languageTag(this@MainActivity)}"; setPadding(0, dp(18), 0, dp(8)) })
        root.addView(button(s(R.string.apply_language)) {
            LocaleManager.setLanguage(this, values[spinner.selectedItemPosition])
            Toast.makeText(this, s(R.string.language_changed), Toast.LENGTH_SHORT).show()
            recreate()
        })
        page(root)
    }

    private fun showCommerce() {
        setScreen("commerce") { showHome() }
        val root = section("Rocky X PRO", "برای آموزش جدی‌تر، مسیرهای پیشرفته و شخصی‌سازی عمیق‌تر")
        root.addView(TextView(this).apply {
            text = "✓ دوره‌های پیشرفته\n✓ مأموریت‌های تخصصی\n✓ پیشنهادهای شخصی‌سازی‌شده\n✓ تحلیل پیشرفت\n✓ محتوای رسانه‌ای PRO\n✓ مسیرهای بیشتر برای مهارت‌های پیشرفته"
            textSize = 17f; setPadding(0, dp(8), 0, dp(18))
        })
        val activePro = app.commercePlans.firstOrNull { it.tier == Access.PRO && app.entitlement(it.productId)?.isActive() == true }
        if (activePro != null) {
            root.addView(TextView(this).apply { text = "🎉 PRO فعال است"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(8), 0, dp(18)) })
            val proCourse = app.catalog().firstOrNull { it.access == Access.PRO }
            val next = proCourse?.let { app.nextLesson(it.id) }
            if (next != null) root.addView(button("شروع اولین تمرین PRO: ${next.title}") { showLesson(proCourse, next) }, LinearLayout.LayoutParams(-1, dp(60)).apply { setMargins(0, 0, 0, dp(18)) })
        } else {
            root.addView(TextView(this).apply { text = "پلن مناسب خودت را انتخاب کن"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(8), 0, dp(12)) })
            app.commercePlans.filter { it.tier == Access.PRO && it.active }.forEach { plan ->
                val amount = Globalization.currency(this, plan.amountMinor, plan.currency)
                val trial = if (plan.trialDays > 0) " • ${plan.trialDays} روز آزمایشی" else ""
                root.addView(TextView(this).apply { text = "${plan.displayName}\n$amount / ${plan.billingPeriod}$trial"; textSize = 18f; setPadding(dp(8), dp(10), dp(8), dp(6)) })
                root.addView(button(if (BuildConfig.DEBUG) "شروع تست محلی (فقط Debug)" else "ارتقا به PRO") {
                    if (BuildConfig.DEBUG) {
                        app.saveLocalTrial(plan)
                        Toast.makeText(this, "PRO فقط برای تست محلی فعال شد.", Toast.LENGTH_LONG).show()
                        showCommerce()
                    } else {
                        if (!app.auth.isSignedIn()) {
                            Toast.makeText(this, "برای خرید PRO ابتدا وارد حساب شو.", Toast.LENGTH_LONG).show()
                            signInWithGoogle()
                        } else launchPlayPurchase(plan.productId)
                    }
                }, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(12)) })
            }
        }
        root.addView(TextView(this).apply { text = "پرداخت واقعی در نسخه تولیدی فقط از مسیر Google Play و تأیید سرور انجام می‌شود."; setPadding(0, dp(18), 0, dp(12)) })
        if (app.auth.isSignedIn()) root.addView(button("🔄 همگام‌سازی وضعیت اشتراک") {
            billingScope.launch { app.refreshServerEntitlements().onSuccess { showCommerce() }.onFailure { Toast.makeText(this@MainActivity, "همگام‌سازی ناموفق بود.", Toast.LENGTH_LONG).show() } }
        })
        root.addView(button("بازگشت به خانه") { showHome() })
        nav(root)
        page(root)
    }

    private fun launchPlayPurchase(productId: String) {
        val plan = app.commercePlans.firstOrNull { it.productId == productId }
            ?: return Toast.makeText(this, "طرح خرید پیدا نشد.", Toast.LENGTH_LONG).show()
        if (!app.auth.isSignedIn()) {
            Toast.makeText(this, "برای خرید باید وارد حساب شوید.", Toast.LENGTH_LONG).show()
            return
        }
        val client = com.rockyx.app.data.commerce.GooglePlayBillingClient(
            this,
            onPurchases = { purchases ->
                val purchase = purchases.firstOrNull { it.products.contains(productId) }
                if (purchase == null) {
                    Toast.makeText(this, "خرید دریافتی مربوط به این محصول نبود.", Toast.LENGTH_LONG).show()
                } else billingScope.launch {
                    val result = app.billingOrchestrator.process(purchase)
                    if (result.isSuccess) {
                        val sync = app.refreshServerEntitlements()
                        if (sync.isSuccess) {
                            Toast.makeText(this@MainActivity, "خرید تأیید شد و دسترسی شما به‌روزرسانی شد.", Toast.LENGTH_LONG).show()
                            showCommerce()
                        } else {
                            Toast.makeText(this@MainActivity, "خرید توسط سرور تأیید شد؛ همگام‌سازی دسترسی بعداً دوباره انجام می‌شود.", Toast.LENGTH_LONG).show()
                            com.rockyx.app.background.RockyXBackgroundWork.syncNow(this@MainActivity)
                        }
                    } else {
                        Toast.makeText(this@MainActivity, "خرید دریافت شد، اما تا تأیید حساب/سرور دسترسی فعال نمی‌شود.", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onError = { result -> Toast.makeText(this, "Google Play: ${result.debugMessage}", Toast.LENGTH_LONG).show() }
        )
        billingClient?.disconnect()
        billingClient = client
        client.connect()
        client.queryProducts(listOf(productId)) { details ->
            val detail = details.firstOrNull { it.productId == productId }
            if (detail == null) {
                Toast.makeText(this, "این محصول فعلاً در Google Play در دسترس نیست.", Toast.LENGTH_LONG).show()
                return@queryProducts
            }
            val offers = detail.subscriptionOfferDetails.orEmpty()
            val preferred = plan.offerId?.let { wanted -> offers.firstOrNull { it.offerId == wanted } }
            val offer = preferred ?: if (plan.offerId == null) offers.firstOrNull() else null
            if (offer == null) {
                Toast.makeText(this, "Offer منطبق با طرح Rocky X در Google Play پیدا نشد.", Toast.LENGTH_LONG).show()
                return@queryProducts
            }
            client.purchase(this, detail, offer.offerToken)
        }
    }

    private fun showCourse(id: String) {
        setScreen("course") { showCourses() }
        val course = app.getCourse(id) ?: return
        val root = base(course.title, course.description)
        course.chapters.forEach { chapter ->
            root.addView(TextView(this).apply { text = chapter.title; textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(10), 0, dp(8)) })
            chapter.lessons.forEach { lesson ->
                val view = app.lessonState(course.id, lesson.id)
                val icon = when(view.state) { LearningState.COMPLETED -> "✓"; LearningState.IN_PROGRESS -> "▶"; LearningState.LOCKED -> "🔒"; LearningState.MASTERED -> "★"; LearningState.AVAILABLE -> "○" }
                root.addView(button("$icon ${lesson.title} • ${lesson.durationMinutes} دقیقه", view.state != LearningState.LOCKED) { showLesson(course, lesson) }, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, 0, 0, dp(8)) })
                view.reason?.let { if (view.state == LearningState.LOCKED) root.addView(TextView(this).apply { text = it; setPadding(dp(8), 0, 0, dp(8)) }) }
            }
        }
        page(root)
    }
    private fun mediaBadge(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(accentColor)
        setPadding(dp(10), dp(5), dp(10), dp(5))
        background = rounded(accentSoft, 14f)
    }

    private fun mediaCard(ref: MediaRef, lessonTitle: String, onPlay: (PlayerView) -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.WHITE, 24f)
            elevation = dp(3).toFloat()
        }
        val meta = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(mediaBadge(if (ref.type == ContentType.VIDEO) "ویدئوی آموزشی" else "محتوای آموزشی"))
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0, dp(1), 1f))
            addView(TextView(this@MainActivity).apply {
                text = lessonTitle
                textSize = 12f
                setTextColor(mutedColor)
                maxLines = 1
            })
        }
        card.addView(meta, LinearLayout.LayoutParams(-1, dp(36)))

        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(28, 42, 36), 20f)
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(-1, dp(210)).apply { setMargins(0, dp(4), 0, dp(10)) }
        }
        val playerView = PlayerView(this).apply {
            id = View.generateViewId()
            useController = true
            controllerShowTimeoutMs = 2500
            controllerAutoShow = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.rgb(28, 42, 36))
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        frame.addView(playerView)
        val play = TextView(this).apply {
            text = "▶"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(accentColor, 28f)
            elevation = dp(6).toFloat()
            contentDescription = "پخش ویدئوی آموزشی"
            setOnClickListener { onPlay(playerView) }
        }
        frame.addView(play, FrameLayout.LayoutParams(dp(62), dp(62), Gravity.CENTER))
        card.addView(frame)
        card.addView(TextView(this).apply {
            text = "پخش از آخرین نقطه ذخیره‌شده ادامه پیدا می‌کند."
            textSize = 12f
            setTextColor(mutedColor)
            setPadding(dp(2), 0, dp(2), dp(6))
        })
        card.addView(button("▶  شروع / ادامه آموزش") { onPlay(playerView) }, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(6)) })
        if (ref.downloadable) {
            card.addView(button("📥  ذخیره برای تمرین آفلاین") {
                mediaEngine?.download(MediaDescriptor(ref.id, ref.type, ref.uri ?: return@button, true, lessonTitle))
                Toast.makeText(this, s(R.string.download_queued), Toast.LENGTH_SHORT).show()
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        return card
    }

    private fun visualLessonPlaceholder(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(22), dp(28), dp(22), dp(28))
        background = rounded(accentSoft, 24f)
        addView(TextView(this@MainActivity).apply { text = "🐕"; textSize = 46f; gravity = Gravity.CENTER })
        addView(TextView(this@MainActivity).apply {
            text = "آموزش تصویری ${title}"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(inkColor)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(5))
        })
        addView(TextView(this@MainActivity).apply {
            text = "ویدئوی این درس بعد از اتصال محتوای آموزشی نمایش داده می‌شود."
            textSize = 13f
            setTextColor(mutedColor)
            gravity = Gravity.CENTER
        })
    }

    private fun showLesson(course: Course, lesson: Lesson) {
        setScreen("lesson") { showCourse(course.id) }
        app.lessonState(course.id, lesson.id).let { if (it.state == LearningState.LOCKED) { if (lesson.access != Access.FREE) showCommerce() else Toast.makeText(this, it.reason ?: "درس قفل است", Toast.LENGTH_LONG).show(); return } }
        app.startLesson(lesson)
        val root = base(lesson.title, lesson.summary)
        val current = app.state(lesson.id)
        root.addView(TextView(this).apply { text = "یاد بگیر؛ بعد اجرا کن"; textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setTextColor(inkColor); setPadding(0, dp(18), 0, dp(8)) })
        if (lesson.media.isNotEmpty()) {
            lesson.media.forEach { ref ->
                val uri = ref.uri
                if (uri.isNullOrBlank()) return@forEach
                val descriptor = MediaDescriptor(ref.id, ref.type, uri, ref.downloadable, lesson.title)
                val card = mediaCard(ref, lesson.title) { playerView ->
                    mediaEngine?.release()
                    mediaEngine = MediaEngine(this).also {
                        it.attach(playerView)
                        it.play(descriptor)
                    }
                }
                root.addView(card, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 0, 0, dp(16)) })
            }
        } else {
            root.addView(visualLessonPlaceholder(lesson.title), LinearLayout.LayoutParams(-1, dp(190)).apply { setMargins(0, 0, 0, dp(16)) })
        }
        lesson.exercises.forEach { ex ->
            val done = current?.exercises?.get(ex.id)?.completed == true
            root.addView(TextView(this).apply { text = s(R.string.exercise, ex.title, ex.instructions, ex.successCriteria.joinToString("، ")); textSize = 16f; setPadding(0, dp(8), 0, dp(8)) })
            root.addView(button(if(done) s(R.string.exercise_done) else s(R.string.complete_exercise)) { app.completeExercise(course.id, lesson.id, ex.id, true); showLesson(course, lesson) })
        }
        lesson.quiz?.let { quiz ->
            root.addView(TextView(this).apply { text = "آزمون (${quiz.passPercent}% برای قبولی)"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(18), 0, dp(8)) })
            val groups = mutableMapOf<String, RadioGroup>()
            quiz.questions.forEachIndexed { questionIndex, q ->
                root.addView(TextView(this).apply { text = "${questionIndex + 1}. ${q.prompt}"; textSize = 16f; setPadding(0, dp(8), 0, dp(4)) })
                val group = RadioGroup(this)
                q.options.forEachIndexed { index, option -> group.addView(RadioButton(this).apply { text = option; tag = index }) }
                groups[q.id] = group
                root.addView(group)
            }
            root.addView(button("ثبت همه پاسخ‌ها") {
                val unanswered = quiz.questions.indexOfFirst { groups[it.id]?.checkedRadioButtonId == -1 }
                if (unanswered >= 0) {
                    Toast.makeText(this, "پاسخ سؤال ${unanswered + 1} را انتخاب کن", Toast.LENGTH_SHORT).show()
                } else {
                    val answers = groups.mapValues { (_, group) ->
                        group.findViewById<RadioButton>(group.checkedRadioButtonId).tag as Int
                    }
                    val result = app.submitQuiz(course.id, lesson.id, answers)
                    Toast.makeText(this, "امتیاز: ${result.score}% — ${if(result.passed) "قبول" else "نیاز به تکرار"}", Toast.LENGTH_SHORT).show()
                    app.evaluateLesson(course.id, lesson.id)
                    showLesson(course, lesson)
                }
            })
        }
        lesson.missions.forEach { mission ->
            val result = current?.missions?.get(mission.id)?.result ?: MissionResult.NOT_STARTED
            root.addView(TextView(this).apply { text = "مأموریت: ${mission.title}\n${mission.instructions}"; textSize = 16f; setPadding(0, dp(18), 0, dp(8)) })
            root.addView(button(if(result == MissionResult.SUCCESS) "✓ مأموریت موفق" else "ثبت موفقیت مأموریت") { app.updateMission(course.id, lesson.id, mission.id, MissionResult.SUCCESS); app.evaluateLesson(course.id, lesson.id); showLesson(course, lesson) })
            if (mission.requiresSubmission) {
                root.addView(button("🎥 ارسال ویدئوی اجرای مأموریت") { startVideoSubmission(mission.id) })
                app.submissions.forMission(mission.id).firstOrNull()?.let { sub ->
                    root.addView(TextView(this).apply { text = "ویدئوی ثبت‌شده: ${sub.status} • ${sub.visibility}"; setPadding(dp(8), 0, 0, dp(8)) })
                }
            }
        }
        root.addView(button("✓ پایان درس و مشاهده نتیجه") { val p = app.evaluateLesson(course.id, lesson.id); showLessonResult(course, lesson, p) })
        root.addView(button("بازگشت به دوره") { showCourse(course.id) })
        page(root)
    }
    private fun showLessonResult(course: Course, lesson: Lesson, progress: LessonProgress) {
        setScreen("lesson-result") { showLesson(course, lesson) }
        val root = section("نتیجه آموزش", "${lesson.title}")
        val passed = progress.state == LearningState.COMPLETED || progress.state == LearningState.MASTERED
        root.addView(TextView(this).apply { text = if (passed) "🎉 عالی! مهارت ثبت شد." else "💪 هنوز کامل نشده؛ یک دور دیگر تمرین کن."; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(16), 0, dp(18)) })
        root.addView(TextView(this).apply { text = "امتیاز: ${progress.score ?: 0}%\nوضعیت: ${progress.state}"; textSize = 18f; setPadding(0, 0, 0, dp(22)) })
        val next = app.nextLesson(course.id)
        if (next != null && next.id != lesson.id) root.addView(button("➡️ ادامه مسیر: ${next.title}") { showLesson(course, next) }, LinearLayout.LayoutParams(-1, dp(60)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(button("📈 مشاهده پیشرفت") { showProgress() }, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, 0, 0, dp(10)) })
        root.addView(button("خانه") { showHome() })
        page(root)
    }

    private fun startVideoSubmission(missionId: String) {
        setScreen("video-select") { showHome() }
        pendingSubmissionMissionId = missionId
        val root = base(s(R.string.video_select_title), s(R.string.video_select_subtitle))
        root.addView(button(s(R.string.pick_video)) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, pickVideo)
        })
        root.addView(button(s(R.string.capture_video)) {
            val intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            if (intent.resolveActivity(packageManager) != null) startActivityForResult(intent, captureVideo)
            else Toast.makeText(this, s(R.string.camera_unavailable), Toast.LENGTH_LONG).show()
        })
        page(root)
    }

    private fun showSubmissionReview(missionId: String, localPath: String) {
        setScreen("submission-review") { startVideoSubmission(missionId) }
        val root = base(s(R.string.submission_title), s(R.string.submission_subtitle))
        val processing = CheckBox(this).apply { text = s(R.string.processing_consent) }
        val public = CheckBox(this).apply { text = s(R.string.public_consent) }
        val visibility = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("PRIVATE", "UNLISTED", "PUBLIC"))
        }
        root.addView(TextView(this).apply { text = "فایل محلی آماده است. ${File(localPath).length() / 1024 / 1024} MB" })
        root.addView(visibility); root.addView(processing); root.addView(public)
        root.addView(button(s(R.string.save_submission)) {
            val vis = SubmissionVisibility.valueOf(visibility.selectedItem.toString())
            val now = System.currentTimeMillis()
            val userId = app.auth.currentUserId() ?: "local-anonymous"
            val pConsent = Consent(userId, com.rockyx.app.domain.usecase.SubmissionScopes.PROCESSING, processing.isChecked, now)
            val pubConsent = Consent(userId, com.rockyx.app.domain.usecase.SubmissionScopes.PUBLIC_SHARING, public.isChecked, now)
            val sub = Submission(UUID.randomUUID().toString(), missionId, localPath, visibility = vis, processingConsent = pConsent, publicSharingConsent = pubConsent, createdAt = now, updatedAt = now)
            val result = app.saveSubmission(sub)
            if (result.isSuccess) {
                Toast.makeText(this, s(R.string.submission_saved), Toast.LENGTH_LONG).show()
                pendingSubmissionMissionId = null
                showHome()
            } else Toast.makeText(this, result.exceptionOrNull()?.message ?: s(R.string.submission_failed), Toast.LENGTH_LONG).show()
        })
        page(root)
    }

    private fun showDog() {
        setScreen("dog") { showHome() }
        val dog = app.dog.current(); val root = base(s(R.string.dog_profile), "پروفایل واقعی پایه شخصی‌سازی مسیر آموزش است.")
        val name = EditText(this).apply { hint = s(R.string.dog_name_hint); setText(dog.name) }
        val age = EditText(this).apply { hint = s(R.string.age_months_hint); inputType = 2; setText(dog.ageMonths.toString()) }
        val breed = EditText(this).apply { hint = s(R.string.breed_hint); setText(dog.breed) }
        val level = Spinner(this).apply {
            val values = arrayOf("Beginner", "Intermediate", "Advanced")
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, values)
            setSelection(values.indexOf(dog.level).coerceAtLeast(0))
        }
        val goals = EditText(this).apply { hint = s(R.string.goals_hint); setText(dog.goals.joinToString(",")) }
        val behaviors = EditText(this).apply { hint = s(R.string.behaviors_hint); setText(dog.behaviors.joinToString(",")) }
        val temperament = EditText(this).apply { hint = s(R.string.temperament_hint); setText(dog.temperament.joinToString(",")) }
        root.addView(name); root.addView(age); root.addView(breed); root.addView(level); root.addView(goals); root.addView(behaviors); root.addView(temperament)
        root.addView(button(s(R.string.save_profile)) {
            val split = { value: String -> value.split(',').map { it.trim() }.filter { it.isNotBlank() }.distinct() }
            app.dog.save(dog.copy(name = name.text.toString().ifBlank { dog.name }, ageMonths = age.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: dog.ageMonths, breed = breed.text.toString().trim(), level = level.selectedItem.toString(), goals = split(goals.text.toString()), behaviors = split(behaviors.text.toString()), temperament = split(temperament.text.toString()), profileVersion = dog.profileVersion + 1))
            Toast.makeText(this, s(R.string.profile_saved), Toast.LENGTH_SHORT).show()
            showHome()
        })
        page(root)
    }
}

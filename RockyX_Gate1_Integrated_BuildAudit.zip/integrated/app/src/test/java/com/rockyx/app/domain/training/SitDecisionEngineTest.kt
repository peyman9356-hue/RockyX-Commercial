package com.rockyx.app.domain.training

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class SitDecisionEngineTest {
    private fun session() = TrainingSession(
        sessionId = "S1", dogId = "D-ROCKY", skillId = "sit", contextId = "C1",
        attempts = listOf(
            TrainingAttempt("A1", "S1", 1, listOf("E1")),
            TrainingAttempt("A2", "S1", 2, listOf("E2")),
            TrainingAttempt("A3", "S1", 3, listOf("E3"))
        )
    )

    private fun evidence(results: List<SitResult>) = results.mapIndexed { i, result ->
        val n = i + 1
        SitEvidence("E$n", "D-ROCKY", "A$n", "S1", "C1", CueType.VERBAL,
            LureStatus.NOT_REQUIRED, result, ResponseQuality.IMMEDIATE, RewardTiming.IMMEDIATE)
    }

    @Test fun sufficientSuccessAdvances() {
        val evaluation = SitSessionAggregator.evaluate(session(), evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES)))
        val decision = TrainingPolicyEngine.decide("D-ROCKY", "sit", evaluation)
        assertEquals(EvaluationResult.SUCCESS, evaluation.result)
        assertEquals(Sufficiency.SUFFICIENT, evaluation.sufficiency)
        assertEquals(DecisionType.ADVANCE, decision.type)
    }

    @Test fun sufficientFailureRepeatsNotSimplifies() {
        val evaluation = SitSessionAggregator.evaluate(session(), evidence(listOf(SitResult.NO, SitResult.NO, SitResult.NO)))
        val decision = TrainingPolicyEngine.decide("D-ROCKY", "sit", evaluation)
        assertEquals(EvaluationResult.FAIL, evaluation.result)
        assertEquals(DecisionType.REPEAT, decision.type)
    }

    @Test fun insufficientSuccessReviews() {
        val shortSession = session().copy(attempts = listOf(TrainingAttempt("A1", "S1", 1, listOf("E1"))))
        val evaluation = SitSessionAggregator.evaluate(shortSession, listOf(evidence(listOf(SitResult.YES))[0]))
        val decision = TrainingPolicyEngine.decide("D-ROCKY", "sit", evaluation)
        assertEquals(Sufficiency.INSUFFICIENT, evaluation.sufficiency)
        assertEquals(DecisionType.REVIEW, decision.type)
    }

    @Test fun canonicalOrderingUsesClientGeneratedId() {
        val es = evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES)).mapIndexed { i, e ->
            e.copy(clientGeneratedId = listOf("c3", "c1", "c2")[i])
        }
        val active = SitSessionAggregator.activeEvidence(es)
        assertEquals(listOf("c1", "c2", "c3"), active.map { it.clientGeneratedId })
    }

    @Test fun conflictingConcurrentSupersedeIsRejected() {
        val es = listOf(
            evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES))[0],
            evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES))[1].copy(supersedesEvidenceId = "E1"),
            evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES))[2].copy(supersedesEvidenceId = "E1")
        )
        assertThrows(IllegalArgumentException::class.java) { SitSessionAggregator.activeEvidence(es) }
    }

    @Test fun decisionBasisIdsAreSortedAndTraceable() {
        val evaluation = SitSessionAggregator.evaluate(session(), evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES)), evaluationId = "EVAL-9")
        val decision = TrainingPolicyEngine.decide("D-ROCKY", "sit", evaluation)
        assertEquals(listOf("EVAL-9"), decision.basisEvaluationIds)
    }

    @Test fun sameCanonicalInputIsDeterministic() {
        val e1 = SitSessionAggregator.evaluate(session(), evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES)), evaluationId = "EVAL-1")
        val e2 = SitSessionAggregator.evaluate(session(), evidence(listOf(SitResult.YES, SitResult.YES, SitResult.YES)), evaluationId = "EVAL-1")
        assertEquals(e1, e2)
        assertEquals(TrainingPolicyEngine.decide("D-ROCKY", "sit", e1), TrainingPolicyEngine.decide("D-ROCKY", "sit", e2))
    }
}

// Gate 2 policy matrix: all 12 combinations are explicit and independently asserted.
class TrainingPolicyMatrixTest {
    private fun evaluation(sufficiency: Sufficiency, result: EvaluationResult) = Evaluation(
        evaluationId = "E-$sufficiency-$result", sessionId = "S1", attemptIds = emptyList(), evidenceIds = emptyList(),
        result = result, sufficiency = sufficiency, status = if (sufficiency == Sufficiency.SUFFICIENT) EvaluationStatus.VALID else EvaluationStatus.INSUFFICIENT,
        confidenceTier = ConfidenceTier.LOW, ruleVersionId = "SIT_AGGREGATION_V1_PROTOTYPE:1", policyVersionId = "SIT_POLICY:1"
    )

    @Test fun sufficientSuccessAdvance() = assertType(Sufficiency.SUFFICIENT, EvaluationResult.SUCCESS, DecisionType.ADVANCE)
    @Test fun sufficientFailRepeat() = assertType(Sufficiency.SUFFICIENT, EvaluationResult.FAIL, DecisionType.REPEAT)
    @Test fun sufficientPartialRepeat() = assertType(Sufficiency.SUFFICIENT, EvaluationResult.PARTIAL, DecisionType.REPEAT)
    @Test fun sufficientUnknownReview() = assertType(Sufficiency.SUFFICIENT, EvaluationResult.UNKNOWN, DecisionType.REVIEW)
    @Test fun insufficientSuccessReview() = assertType(Sufficiency.INSUFFICIENT, EvaluationResult.SUCCESS, DecisionType.REVIEW)
    @Test fun insufficientFailReview() = assertType(Sufficiency.INSUFFICIENT, EvaluationResult.FAIL, DecisionType.REVIEW)
    @Test fun insufficientPartialReview() = assertType(Sufficiency.INSUFFICIENT, EvaluationResult.PARTIAL, DecisionType.REVIEW)
    @Test fun insufficientUnknownReview() = assertType(Sufficiency.INSUFFICIENT, EvaluationResult.UNKNOWN, DecisionType.REVIEW)
    @Test fun contradictorySuccessReview() = assertType(Sufficiency.CONTRADICTORY, EvaluationResult.SUCCESS, DecisionType.REVIEW)
    @Test fun contradictoryFailReview() = assertType(Sufficiency.CONTRADICTORY, EvaluationResult.FAIL, DecisionType.REVIEW)
    @Test fun contradictoryPartialReview() = assertType(Sufficiency.CONTRADICTORY, EvaluationResult.PARTIAL, DecisionType.REVIEW)
    @Test fun contradictoryUnknownReview() = assertType(Sufficiency.CONTRADICTORY, EvaluationResult.UNKNOWN, DecisionType.REVIEW)

    @Test fun unsupportedPolicyVersionIsRejectedWithoutFallback() {
        val e = evaluation(Sufficiency.SUFFICIENT, EvaluationResult.SUCCESS).copy(policyVersionId = "SIT_POLICY:999")
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            TrainingPolicyEngine.decide("D-ROCKY", "sit", e)
        }
    }

    private fun assertType(s: Sufficiency, r: EvaluationResult, expected: DecisionType) {
        val d = TrainingPolicyEngine.decide("D-ROCKY", "sit", evaluation(s, r))
        org.junit.Assert.assertEquals(expected, d.type)
    }
}

package com.rockyx.app.domain.training

/** Gate 1 PolicyVersion v1: the sole decision matrix authority. */
object TrainingPolicyEngine {
    const val POLICY_ID = "SIT_POLICY"
    const val VERSION = "1"

    fun decide(
        dogId: String,
        skillId: String,
        evaluation: Evaluation,
        decisionId: String = "decision-${evaluation.evaluationId}"
    ): Decision {
        require(evaluation.policyVersionId == "$POLICY_ID:$VERSION") {
            "Unsupported policy version: ${evaluation.policyVersionId}"
        }
        val type = when (evaluation.sufficiency) {
            Sufficiency.SUFFICIENT -> when (evaluation.result) {
                EvaluationResult.SUCCESS -> DecisionType.ADVANCE
                EvaluationResult.FAIL, EvaluationResult.PARTIAL -> DecisionType.REPEAT
                EvaluationResult.UNKNOWN, EvaluationResult.NOT_ASSESSED -> DecisionType.REVIEW
            }
            Sufficiency.INSUFFICIENT, Sufficiency.CONTRADICTORY -> DecisionType.REVIEW
        }
        return Decision(
            decisionId = decisionId,
            dogId = dogId,
            skillId = skillId,
            policyVersionId = evaluation.policyVersionId,
            basisEvaluationIds = listOf(evaluation.evaluationId).sorted(),
            type = type,
            reasonCodes = listOf("POLICY:${evaluation.policyVersionId}", "EVALUATION:${evaluation.evaluationId}")
        )
    }
}

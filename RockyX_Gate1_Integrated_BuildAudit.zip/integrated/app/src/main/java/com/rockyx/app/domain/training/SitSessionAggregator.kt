package com.rockyx.app.domain.training

/** Deterministic V1 evaluation rule. It evaluates evidence; it does not decide next action. */
object SitSessionAggregator {
    const val RULE_VERSION = "SIT_AGGREGATION_V1_PROTOTYPE"

    fun activeEvidence(evidence: List<SitEvidence>): List<SitEvidence> {
        require(TrainingValidation.validateConcurrentSupersede(evidence).isEmpty()) {
            "Conflicting evidence supersedes links."
        }
        val supersededIds = evidence.mapNotNull { it.supersedesEvidenceId }.toSet()
        return evidence
            .filter { it.status == EvidenceStatus.VALID && it.evidenceId !in supersededIds }
            .sortedBy { it.clientGeneratedId }
    }

    fun evaluate(
        session: TrainingSession,
        evidence: List<SitEvidence>,
        evaluationId: String = "eval-${session.sessionId}",
        ruleVersion: RuleVersion = RuleVersion("SIT_AGGREGATION_V1_PROTOTYPE", "1"),
        policyVersion: PolicyVersion = PolicyVersion("SIT_POLICY", "1")
    ): Evaluation {
        require(TrainingValidation.validateSession(session).isEmpty()) { "Invalid training session." }
        require(TrainingValidation.validateEvidence(session, evidence).isEmpty()) { "Invalid training evidence." }

        val valid = activeEvidence(evidence)
        if (valid.isEmpty()) {
            return Evaluation(
                evaluationId = evaluationId,
                sessionId = session.sessionId,
                attemptIds = session.attempts.map { it.attemptId },
                evidenceIds = emptyList(),
                result = EvaluationResult.NOT_ASSESSED,
                sufficiency = Sufficiency.INSUFFICIENT,
                status = EvaluationStatus.INSUFFICIENT,
                confidenceTier = ConfidenceTier.LOW,
                ruleVersionId = "${ruleVersion.ruleId}:${ruleVersion.version}",
                policyVersionId = policyVersion.policyVersionId
            )
        }

        val passes = valid.count { it.sitResult == SitResult.YES }
        val fails = valid.count { it.sitResult == SitResult.NO }
        val result = when {
            valid.size >= 3 && passes == valid.size -> EvaluationResult.SUCCESS
            passes > fails -> EvaluationResult.PARTIAL
            fails > passes -> EvaluationResult.FAIL
            else -> EvaluationResult.PARTIAL
        }
        val sufficiency = if (valid.size >= 3) Sufficiency.SUFFICIENT else Sufficiency.INSUFFICIENT

        return Evaluation(
            evaluationId = evaluationId,
            sessionId = session.sessionId,
            attemptIds = session.attempts.map { it.attemptId },
            evidenceIds = valid.map { it.evidenceId },
            result = result,
            sufficiency = sufficiency,
            status = if (sufficiency == Sufficiency.SUFFICIENT) EvaluationStatus.VALID else EvaluationStatus.INSUFFICIENT,
            confidenceTier = if (valid.size >= 3) ConfidenceTier.MEDIUM else ConfidenceTier.LOW,
            ruleVersionId = "${ruleVersion.ruleId}:${ruleVersion.version}",
            policyVersionId = policyVersion.policyVersionId
        )
    }
}

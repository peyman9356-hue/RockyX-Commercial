# Phase 30 — Identity & Session Security

Version 0.30.0 / versionCode 30.

## Goal
Provide a provider-neutral, production-oriented first-party session layer. External identity providers (Google, Apple, passkeys, enterprise OIDC, etc.) authenticate the person; Rocky X exchanges a verified external identity assertion for a short-lived Rocky X access token and a rotating opaque refresh token.

## Security
- Access JWT: RS256, short-lived, issuer/audience/key-id validated.
- Refresh token: cryptographically random, stored only as SHA-256 hash.
- Refresh rotation: old refresh token is revoked before a new session is issued.
- Logout revokes the refresh session.
- No credentials, private keys, refresh tokens, or identity assertions are stored in source control.
- Production fails closed when session signing configuration is missing.
- Android tokens are stored through Android Keystore-backed AES-GCM storage.
- Provider-specific UI remains an adapter boundary; no fake login is included.

## Endpoints
- POST /api/v1/auth/exchange
- POST /api/v1/auth/refresh
- POST /api/v1/auth/logout

## Important boundary
The external identity verifier is still configuration-driven. A real Google/Apple/passkey/OIDC provider must be configured before production sign-in. The project does not claim a live provider without credentials and console configuration.

## Production activation checklist
1. Configure an approved external OIDC verifier (issuer, audience, HTTPS JWKS).
2. Generate a dedicated RSA key pair for Rocky X session signing; keep the PKCS#8 private key in a secret manager.
3. Set session issuer/audience/key ID and private key environment variables.
4. Run Flyway migration V9.
5. Configure Android with the real API base URL and a real identity adapter.
6. Exercise sign-in, refresh rotation, logout, replayed refresh, expired refresh, and account isolation in staging before production.

# Phase 19 — Notifications + Background Jobs

## Goal
Provide persistent, constraint-aware background execution for sync and future submission/media workflows without inventing success while offline or unauthenticated.

## Android
- WorkManager 2.11.2 stable is used for deferrable persistent work.
- Periodic sync uses a CONNECTED network constraint and a minimum 15-minute interval.
- One-time sync uses unique work and exponential backoff.
- Submission drain is isolated behind the real upload gateway; the current fail-closed gateway cannot fabricate success.
- Notification channels are separated for sync, media, and submission events.

## Reliability rules
- Offline: work waits for CONNECTED network.
- Unauthenticated: sync is not granted access; worker retries rather than bypassing auth.
- Duplicate scheduling: unique work names prevent duplicate periodic/one-time execution.
- Retry: exponential backoff is used for transient failures.
- User-visible success is only emitted by a real completed operation.

## Future
- Foreground user-initiated upload worker for large submissions.
- Media processing completion notifications.
- Server push notifications.
- WorkManager test harness and device integration tests.

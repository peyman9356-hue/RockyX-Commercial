# ROCKY X — GAP & REPAIR PLAN

## Baseline
v0.32.2 is retained as a protected technical foundation, not treated as the final ecosystem architecture.

## Keep
- training engine
- content/CMS
- progress
- media
- offline/resilience
- authentication/session boundary
- server-authoritative billing
- provider-neutral AI boundary
- localization
- observability/security foundations

## Repair now
- promote Dog to a first-class cloud entity
- support multiple dogs per owner
- introduce dog event/history model
- introduce device identity and ownership model
- introduce safety event model
- introduce veterinary access grants
- separate positioning from communications in domain boundaries
- separate AI evidence/inference/recommendation persistence
- expand authorization scopes
- add migration and optimistic versioning for dog profile

## Repair next, after architecture freeze
- cloud sync for Dog Identity and event history
- real AI insight pipeline from trusted backend data
- device telemetry ingestion
- Bluetooth/GNSS/cellular adapters
- safety automation
- vet workspace and controlled access
- store architecture implementation

## Do not build yet
- physical collar prototype
- display hardware
- large hardware catalog
- speculative AI claims
- global distributor infrastructure

## Release gate
No version is production-complete until the real Android build, physical device test, backend deployment, database migration, security review and release/payment tests pass.

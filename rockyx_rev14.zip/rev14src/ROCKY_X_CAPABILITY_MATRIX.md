# Rocky X Capability Matrix

| Capability | V1 | Future architecture | Later/validate |
|---|---|---|---|
| Multi-dog identity | YES | | |
| Lifelong profile | YES | | |
| Training/progress | YES | | |
| Dog event history | YES | | |
| Useful AI recommendations | YES | | |
| Cloud sync | YES | | |
| Smart Module domain | | YES | |
| Smart Collar | | YES | |
| GNSS/GPS | | YES | |
| Cellular/eSIM | | YES | |
| Lost Dog automation | | YES | |
| Vet access | YES foundation | YES full workspace | |
| Store | | YES | |
| Display | | | VALIDATE |
| Smart Brush | | | VALIDATE |
| Smart Feeder | | | VALIDATE |
| Smart Water Station | | | VALIDATE |
| Smart Toys/Bed | | | VALIDATE |

# Rocky X Revision 14 — Changelog

- Hardened learning use-cases against unknown exercise/mission IDs.
- Enforced exact quiz answers, answer-index bounds, and quiz max-attempts.
- Added prerequisite cycle detection and stronger content invariants.
- Made learning-progress corruption explicit and quarantined.
- Made local account-session corruption explicit and quarantined.
- Corrected sync pending-limit semantics.
- Static integration gate remains PASS 9/9.
- Build/runtime status remains NOT VERIFIED until real CI/device execution.

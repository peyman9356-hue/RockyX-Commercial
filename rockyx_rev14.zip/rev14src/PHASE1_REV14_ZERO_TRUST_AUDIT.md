# Rocky X — Revision 14 Zero-Trust Audit & Hardening Report

Date: 2026-09-10
Baseline: v0.32.2
Previous revision: 13
New architecture revision: 14
Status: PHASE1_DOMAIN_INVARIANTS_HARDENED_PRE_REBUILD

## Truth gate

This revision was re-audited from the actual Revision 13 working source, not from prior claims.

- Static integration check: PASS (9/9)
- Archive integrity: to be verified after packaging
- Real Gradle build: NOT EXECUTED (no Gradle executable / wrapper in this environment)
- JVM tests: NOT EXECUTED
- Android APK/AAB build: NOT EXECUTED
- Physical-device runtime: NOT EXECUTED
- Production PostgreSQL/cloud/billing/media pipeline: NOT EXECUTED

## Findings discovered and fixed

### R14-001 — Learning domain allowed unknown exercise IDs
`CompleteExercise` accepted any exercise ID and persisted it. This could pollute progress and inflate lesson score because scoring counted completed stored exercises rather than only content-defined exercises.

Fix: `CompleteExercise` now resolves the lesson and rejects exercise IDs not defined by that lesson.

### R14-002 — Learning domain allowed unknown mission IDs
`UpdateMission` accepted arbitrary mission IDs.

Fix: `UpdateMission` now resolves the lesson and rejects mission IDs not defined by that lesson.

### R14-003 — Quiz accepted incomplete/extra/out-of-range answers
`SubmitQuiz` previously scored whatever answers were supplied. Missing answers could be submitted and answer indices were not validated at the use-case boundary.

Fix:
- exact answer-key set must match quiz question IDs
- every answer index must be within the question's option range
- empty quizzes are rejected
- `maxAttempts` is enforced

### R14-004 — Content validator did not detect prerequisite cycles
Only self-dependencies were detected. Multi-node cycles could remain in content and make lesson unlocking impossible.

Fix: full DFS cycle detection added.

### R14-005 — Content validator accepted weak lesson/quiz metadata
Lesson IDs/titles/duration and quiz question IDs/prompts/options/passPercent/maxAttempts had incomplete invariant checks.

Fix: stronger structural/content invariants added, including duplicate question/exercise/mission IDs and bounds.

### R14-006 — Learning progress store silently normalized corruption
Progress schema/migration and enum parsing could silently fall back to defaults.

Fix: malformed/unsupported progress is quarantined and surfaced through `LocalDataCorruptionException`; enum parsing is strict.

### R14-007 — Local account session store silently reset corruption
Malformed local account-session JSON could become a signed-out default without distinguishing corruption.

Fix: raw data is quarantined and `LocalDataCorruptionException` is raised.

### R14-008 — Sync `pending(0)` returned one item
The previous implementation coerced non-positive limits to 1, violating the caller's requested bound.

Fix: non-negative limits are accepted and applied exactly; negative limits are rejected.

## Existing high-risk findings rechecked

- First-party session remains the only API bearer-token verifier: PASS by source inspection.
- Revoked first-party sessions invalidate existing access JWTs: PASS by source inspection.
- External identity scopes/roles are not copied into server authorization: PASS by source inspection.
- Refresh-token consumption is atomic at repository boundary: PASS by source inspection.
- Uploaded object must match server-owned size/type/SHA-256 before quarantine: PASS by source inspection.
- Production refuses to start with unconfigured media security scanner: PASS by source inspection.
- Public internal metrics endpoint is disabled: PASS by source inspection.
- Cleartext HTTP disabled in Android manifest: PASS by source inspection.
- No obvious committed private-key/token/API-key patterns found in source archive: PASS by static scan.

## Remaining blockers

1. Real Gradle build and tests.
2. Android runtime/device testing.
3. Production media security scanner implementation and wiring.
4. Full media processing/artifact-store production implementation and orchestrator wiring.
5. Durable idempotency needs an atomic claim/transaction model; current GET -> business write -> PUT pattern is not sufficient for exactly-once semantics under concurrent requests.
6. Android CMS/content sync is not yet the production content path.
7. Real AI provider is not configured; local deterministic personalization remains fallback.
8. Payment, Google identity, PostgreSQL, object storage/CDN and backup/restore require real environment tests.

## Important non-claims

Revision 14 is NOT declared flawless, Build-Ready, Production-Ready, or Release-Ready.
The 99.9% confidence target cannot truthfully be awarded until the unverified build/runtime/production gates are completed.

## Next safe gate

Upload this exact revision to the real CI repository, build it with Java 17 + Gradle 8.13, run all JVM tests, build the Android APK, then analyze the complete CI log. Any failure becomes a new evidence-backed correction cycle.

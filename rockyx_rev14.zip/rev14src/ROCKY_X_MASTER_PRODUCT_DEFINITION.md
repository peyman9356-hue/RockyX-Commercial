# ROCKY X — MASTER PRODUCT DEFINITION

Status: PRE-BUILD MASTER DEFINITION
Baseline: v0.32.2 foundation + ecosystem architecture repair

## 1. Product definition
Rocky X is a Smart Dog Ecosystem: a long-lived digital identity for each dog connected to training, useful AI, optional hardware, safety/location, veterinary access and future commerce.

## 2. Primary value
DOG → DATA → AI/INSIGHT → PERSONALIZED ACTION → RESULT → NEW DATA.

Rocky X must improve real outcomes for the dog and owner. Features without measurable user value are not product requirements.

## 3. V1 boundary
Must-have:
- account and secure identity
- multi-dog lifelong profile
- training/content/progress
- behavior observations and dog events
- cloud synchronization boundary
- safe provider-neutral AI recommendation boundary
- privacy/security/authorization
- configurable commerce/billing foundation
- architecture contracts for devices, safety and veterinary access

Future architecture, not forced into V1:
- Smart Module
- Smart Collar/adapters
- GPS/GNSS + communications
- Lost Dog/Safety automation
- Vet workspace
- Store and distribution network
- additional smart products

Later/experimental:
- display
- smart brush/feeder/water/toys/bed and other hardware concepts until validated

## 4. Lifelong Dog Identity
Dog is a first-class cloud entity. The owner may have multiple dogs. Dog data must survive phone, app, device and hardware changes.

## 5. Data semantics
Data, inference and recommendation are separate objects. AI must never present an inference as raw fact or a medical diagnosis without validated clinical capability.

## 6. Hardware model
Smart Module is the intelligence unit. A collar is one host/accessory, not the identity of the platform. The attachment system must support secure mechanical retention, intentional removal and future adapters.

## 7. Safety model
Positioning and communication are separate capabilities. GPS/GNSS determines location; communication transports it. Safety events are their own domain.

## 8. Veterinary model
Owner-controlled, expiring and revocable access grants. Access levels must be explicit. Veterinary access never bypasses owner authorization.

## 9. Commerce
Revenue may come from software subscriptions, hardware, services, store commerce and B2B. Billing remains server-authoritative.

## 10. Global design
Language, country, currency, pricing, payment, infrastructure, legal and distribution rules must not be hardcoded into domain logic.

## 11. Product law
Before a new product is built: market → competitors → weaknesses → real need → Rocky solution → defensible improvement → manufacturability → durability/safety → cost/price → customer value.

## 12. Quality law
No production claim without real build, device test, backend deployment, payment test and release-gate evidence.

## 13. UX-01 — Simple, Fast, Owner-First
Rocky X is designed first from the perspective of the dog owner, not the developer.

Mandatory UX requirements:
- The most important daily actions must be reachable in one or two taps from the primary navigation.
- The owner must not be forced through deep nested menus for routine tasks.
- Home must remain simple, calm, and task-oriented rather than becoming a feature catalog.
- Primary navigation must remain clear and consistently available.
- Advanced capabilities must be progressively disclosed so they do not clutter the everyday experience.
- Every new capability must be reviewed for simplicity, access speed, cognitive load, and real owner value before implementation.
- The acceptance question is: “If I were the dog owner, could I do what I need without extra thought?”

UX is a product requirement, not a visual afterthought. This rule applies to Android, iOS, navigation structure, information architecture, onboarding, training flows, dog profile, safety, veterinary access, AI insights and future hardware workflows.

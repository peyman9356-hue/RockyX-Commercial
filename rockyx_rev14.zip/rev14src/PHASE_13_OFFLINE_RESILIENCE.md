# Phase 13 — Offline-First & Connectivity Resilience

Rocky X must remain useful when international connectivity is unavailable or unstable.

## Rules
- Learning progress, dog profile, consent records, content metadata, and submission intent remain local-first.
- No UI may claim server success while offline.
- Sync is opportunistic and resumes when validated connectivity returns.
- Failed sync operations use bounded exponential backoff.
- Authentication is never bypassed merely because the device is offline.
- Local queues contain operation intent, not passwords or bearer tokens.
- Network state uses Android `NET_CAPABILITY_VALIDATED`, not merely a connected Wi-Fi/mobile transport.

## Boundaries
`ConnectivityRepository` reports network state; `ResilientSync` decides whether queued work is eligible; `SyncTransport` remains the remote boundary.

This phase does not attempt to defeat or bypass a national shutdown. It makes the app resilient to loss of connectivity and avoids data loss while offline.

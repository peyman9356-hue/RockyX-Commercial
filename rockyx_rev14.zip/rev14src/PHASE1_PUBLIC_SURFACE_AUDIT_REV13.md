# Rocky X — Revision 13 Public Surface Audit

Deep pre-CI review found `/api/v1/internal/metrics` was publicly routable despite being documented as development-only.

Revision 13 removes that information exposure by making the public route return 404. Production telemetry must remain behind a deployment-specific observability boundary rather than the application API.

Status: STATICALLY HARDENED / BUILD UNVERIFIED / RUNTIME UNVERIFIED / NOT RELEASE-READY.

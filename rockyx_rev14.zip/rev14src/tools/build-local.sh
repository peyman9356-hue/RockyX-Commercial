#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle is not installed. Use CI or install Gradle 8.13+ in a real Android build environment." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: Android SDK is not configured (ANDROID_HOME/ANDROID_SDK_ROOT)." >&2
  exit 2
fi

gradle --version
gradle test :app:assembleDebug :backend:build
printf '\nBuild completed. APK candidates:\n'
find app/build/outputs/apk -type f -name '*.apk' -print 2>/dev/null || true

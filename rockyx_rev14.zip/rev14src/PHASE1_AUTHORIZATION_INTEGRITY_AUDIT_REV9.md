# Rocky X — Revision 9 Authorization Integrity Audit

Trigger: deep pre-build zero-trust re-audit after repeated CI failures.

Critical finding fixed before next CI run:
- `AuthSessionRecord` had broad default scopes. `SessionManager.issue()` created records without passing the caller's scopes/roles, so refresh rotation could silently widen privileges.

Corrections:
1. Session records now default to empty scopes/roles.
2. `SessionManager.issue()` persists the exact caller-supplied scopes and roles.
3. Account profile mutation requires `account:write` rather than `account:read`.
4. Default auth exchange scope set includes `account:write` and `entitlement:write`; it removes `ai:write` because no public AI write route exists.
5. Added regression tests proving issue/rotate preserve exact scopes/roles and empty scope sets stay empty.

Static verification:
- Integration gate: PASS expected via local script.
- No Gradle wrapper / Gradle executable available locally; Kotlin/Android dependency-resolved compilation remains UNVERIFIED.
- This audit intentionally does not claim build success.

Release status: NOT VERIFIED FOR RELEASE.

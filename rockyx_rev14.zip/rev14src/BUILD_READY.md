# Rocky X — Build-Ready Integrated Release 0.32.2

This release is the canonical integrated source tree for Rocky X after Phases 1–31.
It is a **build-ready source release**, not a claim that an APK/AAB has already been built in this environment.

## What was hardened
- Version bumped to `0.32.2` / versionCode `34` without overwriting `0.32.0`.
- CI provisions Gradle 8.13 and Java 17, then runs static checks, JVM tests, Android debug build, and backend build.
- CI uploads the generated debug APK as a workflow artifact when the Android build succeeds.
- Added a deterministic local build helper that fails clearly when Android SDK/Gradle are unavailable.
- Added repository hygiene rules to prevent committing build outputs, signing material, local secrets, and environment files.
- Added manifest/security consistency checks to the integration gate.

## Production gates still required
1. Successful CI build.
2. Physical-device installation and smoke test.
3. Fix all compile/runtime/device defects found in testing.
4. Production identity, database, object storage/CDN, media processing, Google Play Billing and RTDN configuration.
5. Play signing configuration outside source control.
6. Closed testing with real testers.
7. Release AAB and Play Console production review.

## Truth rule
No APK, AAB, cloud upload, payment, identity provider, media processing worker, or production deployment is considered complete until its real runtime path has been executed and verified.

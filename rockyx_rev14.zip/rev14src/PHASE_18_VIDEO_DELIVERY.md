# PHASE 18 — VIDEO DELIVERY / ADAPTIVE STREAMING + CDN FOUNDATION

Version 0.18.0 / versionCode 18.

## Goals
- Prefer adaptive HLS for online playback.
- Keep playback authorization separate from storage metadata.
- Use short-lived server-issued playback grants.
- Never persist long-lived signed URLs as durable user entitlements.
- Preserve Media3 offline playback already established in earlier phases.
- Keep CDN/object-storage providers replaceable.

## Flow
`Authenticated API -> PlaybackGrant -> CDN/Object Storage -> HLS Manifest -> Media3`

For offline media:
`DownloadManager -> App-private cache -> Media3`

## Security rules
- Backend remains authoritative for authorization.
- Expired playback grants are rejected client-side as a usability guard; the server remains authoritative.
- Original uploads are never exposed directly to clients.
- CDN URLs are short-lived and scoped to authorized media.
- HLS and progressive MP4 are delivery formats, not ownership/entitlement records.

## Not falsely claimed
A CDN provider, production domain, DRM system, and real playback-token issuer are not configured in this source package. `PlaybackGrantProvider` is the boundary for those integrations.

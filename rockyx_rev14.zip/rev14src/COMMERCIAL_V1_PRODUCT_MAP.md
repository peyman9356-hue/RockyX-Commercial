# Rocky X — Commercial V1 Product Map

Version: 0.32.2

## Core user journey
INSTALL → WELCOME → LANGUAGE → DOG PROFILE → GOALS → TRAINING PLAN → HOME → COURSE → LESSON → EXERCISE → MISSION → RESULT → PRO VALUE → PRO PAYWALL → GOOGLE PLAY → SERVER VERIFICATION → PRO ACTIVE → FIRST PRO LESSON.

## Implemented Android surfaces
- Welcome / first-run onboarding with dog profile and goals.
- Home dashboard with daily next lesson, personalized recommendation, progress, courses and PRO entry.
- Courses catalog with FREE/PRO access handling.
- Course detail with prerequisite state.
- Lesson with media, exercises, quiz, missions and completion evaluation.
- Lesson result with next-step recommendation.
- Progress dashboard.
- Dog profile editing.
- PRO paywall/plan selection and production purchase boundary.
- Account/profile and language settings.
- Offline-oriented local progress and background sync foundations.

## Commercial invariants
1. FREE content remains genuinely useful.
2. PRO access is entitlement-driven.
3. Production purchase must be verified server-side before entitlement is granted.
4. Debug local trial is never a production entitlement path.
5. Pricing remains configuration-driven.
6. No payment secrets or purchase tokens are stored in the app.
7. Every core screen has a recoverable next action or back path.

## Release gate still required
- Real Gradle/Android SDK build.
- APK install on a physical device.
- Smoke test of the full journey.
- Google Play test purchase with backend verification.
- Security/performance/accessibility review.
- Release AAB and Closed Testing.

# ROCKY X — VISUAL PRODUCT & UX MASTER REFERENCE

Status: GOVERNING REFERENCE — Revision 14 / v0.32.2

## 1. Product identity
Rocky X is a professional global digital dog coach, not a demo, toy, classic course catalog, or generic chatbot.

Core principles:
- علم پیچیده → تجربه ساده
- کمترین کلیک، بیشترین دسترسی
- پیچیدگی پشت صحنه؛ سادگی جلوی کاربر
- کوچک شروع می‌کنیم؛ کوچک فکر نمی‌کنیم
- خشت اول را با اندازه ساختمان نهایی می‌چینیم

## 2. Fixed shell — ChatGPT-inspired mental model
The application is one continuous environment, inspired by the fixed conversation shell of ChatGPT, but warmer, more visual, dog-centered and educational.

```text
AppShell
├── Left Menu ⋯
├── Active Content Surface
├── Right Rail: Library / Settings
└── Bottom Composer
```

There is one active primary content surface. Moving from lesson A to lesson B does not destroy A. Returning restores session, progress, media position and relevant state.

The old permanent five-button navigation (Home / Courses / Progress / Dog / PRO) is not the target shell.

## 3. Global visual language
Palette:
- background #F7F5F0
- primary ink #1F2623
- muted text #636A65
- Rocky X green #235B43
- soft green #E1EEE7

Shape:
- mobile-first
- RTL-first, LTR-ready
- rounded cards and controls
- clean spacing
- strong hierarchy
- comfortable touch targets
- no amateur Android default-button appearance
- no decorative visual noise

Typography:
- readable Persian typography
- clear title/subtitle/body hierarchy
- short text blocks
- important actions visually obvious

Educational visuals may use controlled supporting colors (including green/purple motion arrows and dark maroon knowledge sections) when they communicate meaning.

## 4. Shell behavior
### Left menu ⋯
Contextual actions: pin, favorite, private offline download, archive, share with explicit consent, information.

### Right rail
Library is always reachable. Settings is always reachable. Settings opens as a focused panel with a clear back action; it must not feel like a separate unrelated application.

### Bottom Composer
Accepts text, photo, video, file and voice. Future context can include Dog Profile, current lesson, training history, Smart Collar data and authorized vet/support context.

## 5. Home
Home answers: «امروز با سگم چه کار کنم؟»

Information hierarchy:
1. greeting
2. dog context
3. Today's Training
4. Continue Training
5. current problem/recommendation
6. suggested topics
7. Library/Search
8. AI Coach

Common tasks should normally take no more than two meaningful taps from Home.

## 6. Navigation graph
```text
HOME
├── Library
│   ├── Search
│   ├── Category
│   └── Lesson
├── Today's Training → Lesson
├── Continue Training → Lesson
├── AI Coach → Lesson / Recommendation
└── Dog Profile
```

Progress, Account, Commerce and Settings remain available through the shell/contextual surfaces without becoming a classic five-tab app.

## 7. Library
Library is the product access heart.

Required categories:
- مقدمه / آشنایی جذاب با سگ‌ها
- نژاد سگ‌ها
- بیماری‌های سگ
- واکسن پت خانگی
- آموزش مبتدی
- آموزش متوسط — PRO
- آموزش پیشرفته — PRO
- آموزش عالی حرفه‌ای — PRO

Library contains search, categories, personalized cards, lesson cards and future CMS content.

## 8. Semantic Search
```text
Query → Normalize → Title/Content/Tags/Behavior/Goal/Category/Breed/Level → Ranking → Best lessons
```

Natural-language problems must retrieve semantically relevant lessons even when exact title words are absent.

Example: «سگم وقتی مهمان میاد می‌پره روش» should reach greeting/jumping/impulse-control lessons.

## 9. Lesson — core product surface
```text
Lesson
├── identity
├── title
├── summary
├── level
├── duration
├── goals
├── behaviors
├── Video[]
├── Explanation
├── InstructionImages[]
├── CommonMistakes[]
├── CorrectExecution[]
├── Exercise[]
├── Quiz
├── Mission
├── Progress
└── NextStep
```

Visual sequence:
```text
Hero / Title
→ Professional Video
→ Short Explanation
→ Swipeable / Expandable Instruction Images
→ Common Mistake
→ Correct Execution
→ Exercise
→ Assessment / Quiz
→ Feedback
→ Next Step
```

Educational pages must be visual and guided, not a stack of TextViews and Buttons.

Preferred educational components:
- real dog photography
- visual diagrams
- behavior sequences
- rounded information cards
- colored section headers
- arrows / motion lines
- icons
- mistake vs correct comparison
- important-note boxes
- progress/step indicators
- Persian typography

## 10. Media
```text
Lesson → Hero Video / Instruction Images / Exercise Media / Supporting Media
Remote Media → Secure Grant → Player → Progress → Download → Private Offline Storage
```

Media is remote, versioned and multi-item capable. Offline downloads remain private to the app. Media position is session/progress state. Multi-media lifecycle must be tested.

## 11. Exercise / Quiz / Mission
```text
SEE → UNDERSTAND → DO → RECORD → EVALUATE → FEEDBACK → NEXT ACTION
```

Quiz:
```text
all questions render
→ all answers required
→ Submit
→ Evaluate
→ Score
→ Feedback
→ Retry / Continue
```

No early score from a single answer. Where objective assessment is required, mission completion cannot depend only on a generic success button.

## 12. Progress
Progress is not merely completed lesson count.

```text
Behavior → Training → Attempts → Performance → Improvement
```

Show current goal, training stage, attempts/performance and next recommended action.

## 13. Dog Profile
Dog Profile is a Context Engine, not merely settings.

Context:
- identity, breed, age, level
- goals and current problems
- training history and progress
- preferences and important events
- AI context
- future device/health data

Profile context drives Home, Search, Lesson recommendations, AI Coach and future Smart Collar/Vet flows.

## 14. AI Coach
Architecture:
```text
Rocky X → AI Coach Layer → Swappable Provider
```

Allowed:
- dog training/behavior only
- short/direct answer
- maximum one follow-up question
- Rocky X lesson connection
- optional next action

Forbidden:
- general open ChatGPT replacement
- long answers
- diagnosis
- invented science
- sending the whole Library to the model
- uncontrolled API usage
- making AI mandatory for core training

Decision flow:
```text
Question → Intent
→ Exact Lesson Match? yes → Lesson Card
→ no → Semantic Retrieval
→ relevant content? yes → short grounded answer + lesson
→ no → AI Provider → short answer + optional lesson/action
```

## 15. Session model
```text
Session {
  id,
  dogId,
  topic,
  currentLesson,
  messages,
  progress,
  attachments,
  state
}
```

Session state must survive navigation and restore correctly.

## 16. Architecture direction
```text
MainActivity
  ↓
AppShell
  ↓
Navigation / Session
  ↓
Feature Modules
```

Target:
```text
ui/shell/
  AppShell
  AppShellState
  ShellController
  AppDestination
  SessionSnapshot
  SessionStore
feature/
  home / library / lesson / dog / coach
domain/
data/
```

MainActivity becomes thin. Do not simply move the current AppController God Object; separate application state from domain state deliberately.

## 17. Smart Collar / Vet / ecosystem
Smart Collar is architecture-first for now:
```text
DeviceIdentity → Capabilities → Telemetry → Dog → Events → AI / Progress
```

Future detachable sensor/display module should work across collars.

Vet boundary:
```text
Owner → Access Grant → Vet → Scoped Dog Data
```

Lifetime dog record includes vaccines, medications, illness history, diet, weight, training history and important events.

Do not currently build unrelated hardware ecosystem features, a full social network, or decorative Store features ahead of the core training experience.

## 18. Monetization
```text
Free → useful experience → PRO → Premium
```

Pricing is configurable. No first-screen paywall. Billing/entitlements remain server-verification oriented.

## 19. Global
RTL/LTR, localization, accessibility, global date/time/units and dynamic text lengths are architecture requirements, not afterthoughts.

## 20. Social / sharing
Optional and consent-based: training progress, photos, videos, achievements. Rocky X identity/watermark may be used when appropriate and consented. Social never outranks training.

## 21. Content platform
```text
CMS → Catalog API → Android → Cache → Offline
CMS → Publish → Index → Semantic Search → AI Retrieval
```

The current embedded catalog is a production integration gap and must eventually be replaced by the verified content lifecycle.

## 22. Implementation order — locked
### Phase 0 — Reference / architecture lock
- preserve Revision 14
- register this reference
- audit current source
- map KEEP / MOVE / SPLIT / DEPRECATE / DO NOT TOUCH
- register Architecture Debt/Gates

### Phase 1 — AppShell + Session Navigation
- thin MainActivity
- AppShell
- ShellController
- fixed shell
- left menu
- Library rail
- Settings rail
- bottom composer
- active content surface
- session restoration
- retire five-button navigation as primary shell

### Phase 2 — Home
Greeting → dog context → Today's Training → Continue Training → recommendation → topics → Library/Search → AI Coach.

### Phase 3 — Library + Search
Visual Library → categories → lesson cards → search → semantic retrieval → ranking → personalization.

### Phase 4 — Lesson
Hero → video → explanation → instruction images → mistake/correct → exercise → quiz → feedback → next.

### Phase 5 — Media / Offline
Multi-media → versions → secure grants → download → private storage → playback progress → updates → lifecycle tests.

### Phase 6 — Exercise / Quiz
All questions → answer state → submit all → evaluation → score → feedback → retry/continue → objective mission evidence.

### Phase 7 — Progress
Behavior → attempts → performance → improvement → next action.

### Phase 8 — Dog Profile
Visual profile + context engine + history/goals/problems/progress.

### Phase 9 — AI Coach
Provider boundary → intent → exact lesson → semantic retrieval → grounded short answer → controlled fallback → quota/kill switch.

### Phase 10 — CMS → Android
Production content contract, catalog API, versioning, indexing, cache, offline, AI retrieval.

### Phase 11 — Production Media Backend
Storage/CDN/grants/versioning/processing + Android verification.

### Phase 12 — Smart Collar / Vet / Ecosystem
Device identity, telemetry, dog events, behavior interpretation, vet grants, lifetime record.

### Phase 13 — PRO/Premium
Entitlements, gates, billing, server verification, restore/failure UX.

### Phase 14 — Security / Accessibility / Global
Regression, accessibility, RTL/LTR, localization, data integrity.

### Phase 15 — Release Candidate
CI build → physical device → runtime UX → media/offline → auth → billing → backend → security → content pipeline → release evidence.

## 23. Architecture gates
Tracked gates include:
- Dog Cloud Unification
- Atomic Idempotency
- Modularization
- Production Media Pipeline
- Production Integration & Concurrency
- Reverse Proxy/TLS
- Cross-owner DB invariants
- Build Reproducibility
- AGP/Kotlin compatibility
- Nested Workflow cleanup
- Quiz/Assessment runtime proof
- Training UX product-grade proof
- CMS → Android production path
- Multi-media runtime lifecycle
- Authenticated offline sync

No gate becomes CLOSED without evidence.

## 24. Change-control law
Every UI change must identify the reference section it implements, preserve the fixed shell/session model, preserve the visual language, reduce owner effort, keep complexity behind the scenes, preserve offline independence from AI, and include build/test/runtime/regression evidence.

The governing cycle is:
```text
REFERENCE → AUDIT CURRENT CODE → MAP → IMPLEMENT ONE PHASE → BUILD → TEST → DEVICE VERIFY → RECORD → NEXT PHASE
```

The current phone UI is a legacy technical skeleton, not the visual target. The next implementation work is Phase 1: AppShell + Session Navigation, followed in order by the phases above.

package com.rockyx.app

import com.rockyx.app.reliability.FailureRecoveryPolicy
import com.rockyx.app.reliability.QualityGate
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class QualityGateTest {
    @Test fun errorCodesAreBoundedAndSanitized() {
        assertEquals("ERR-01_OK", QualityGate.safeErrorCode("ERR-01_OK/../../token"))
        assertEquals("UNKNOWN_ERROR", QualityGate.safeErrorCode("!!!"))
        assertEquals(64, QualityGate.safeErrorCode("x".repeat(200)).length)
    }

    @Test fun retryPolicyHasHardLimit() {
        assertTrue(FailureRecoveryPolicy.canRetry(0))
        assertTrue(FailureRecoveryPolicy.canRetry(4))
        assertFalse(FailureRecoveryPolicy.canRetry(5))
        assertEquals(60_000L, FailureRecoveryPolicy.nextDelayMs(5))
    }

    @Test fun sensitiveTelemetryKeysAreRejected() {
        assertFalse(QualityGate.isSafeTelemetryTag("Authorization"))
        assertFalse(QualityGate.isSafeTelemetryTag("raw_video"))
        assertTrue(QualityGate.isSafeTelemetryTag("screen"))
    }
}

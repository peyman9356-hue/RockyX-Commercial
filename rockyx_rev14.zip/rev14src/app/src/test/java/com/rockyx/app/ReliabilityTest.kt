package com.rockyx.app

import com.rockyx.app.reliability.*
import kotlin.test.Test
import kotlin.test.assertEquals

class ReliabilityTest {
    @Test fun authFailureRequiresReauth() {
        val e = FailureEvent("AUTH_REQUIRED", FailureCategory.AUTH, false, 1L)
        assertEquals(RecoveryAction.REAUTH, FailureRecoveryPolicy.action(e, online = true, authenticated = false))
    }

    @Test fun offlineSyncWaitsForNetwork() {
        val e = FailureEvent("SYNC_FAILED", FailureCategory.SYNC, true, 1L, 0)
        assertEquals(RecoveryAction.WAIT_FOR_NETWORK, FailureRecoveryPolicy.action(e, online = false, authenticated = true))
    }

    @Test fun retryBudgetIsFinite() {
        val e = FailureEvent("SYNC_FAILED", FailureCategory.SYNC, true, 1L, 5)
        assertEquals(RecoveryAction.NONE, FailureRecoveryPolicy.action(e, online = true, authenticated = true))
    }
}

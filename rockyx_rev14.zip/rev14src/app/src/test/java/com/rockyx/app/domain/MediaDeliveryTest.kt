package com.rockyx.app.domain

import com.rockyx.app.media.ContentDeliveryType
import com.rockyx.app.media.MediaItemFactory
import com.rockyx.app.media.PlaybackGrant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class MediaDeliveryTest {
    @Test fun hlsGrantBuildsM3u8MediaItem() {
        val grant = PlaybackGrant("m1", "https://cdn.example.invalid/v/master.m3u8", System.currentTimeMillis() + 60_000, System.currentTimeMillis(), ContentDeliveryType.HLS)
        val item = MediaItemFactory.fromGrant(grant)
        assertEquals("m1", item.mediaId)
        assertEquals("https://cdn.example.invalid/v/master.m3u8", item.localConfiguration?.uri.toString())
        assertTrue(grant.isUsable())
    }

    @Test(expected = IllegalArgumentException::class)
    fun expiredGrantIsRejected() {
        val grant = PlaybackGrant("m1", "https://cdn.example.invalid/v/master.m3u8", System.currentTimeMillis() - 1, System.currentTimeMillis() - 10, ContentDeliveryType.HLS)
        MediaItemFactory.fromGrant(grant)
    }
}

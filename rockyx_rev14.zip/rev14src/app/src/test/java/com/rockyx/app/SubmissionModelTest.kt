package com.rockyx.app

import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.SubmissionRepository
import com.rockyx.app.domain.usecase.SaveSubmission
import org.junit.Assert.*
import org.junit.Test

class SubmissionModelTest {
    private class MemoryRepo : SubmissionRepository {
        private val data = mutableMapOf<String, Submission>()
        override fun all() = data.values.toList()
        override fun forMission(missionId: String) = all().filter { it.missionId == missionId }
        override fun get(id: String) = data[id]
        override fun save(submission: Submission) { data[submission.id] = submission }
        override fun delete(id: String) { data.remove(id) }
    }

    @Test fun publicSubmissionRequiresSeparateConsent() {
        val repo = MemoryRepo(); val useCase = SaveSubmission(repo)
        val processing = Consent("u", "submission_processing", true, 1L)
        val sub = Submission("s", "m", "/tmp/a.mp4", visibility = SubmissionVisibility.PUBLIC, processingConsent = processing)
        assertTrue(useCase(sub).isFailure)
    }

    @Test fun privateSubmissionCanBeSavedWithProcessingConsent() {
        val repo = MemoryRepo(); val useCase = SaveSubmission(repo)
        val processing = Consent("u", "submission_processing", true, 1L)
        val sub = Submission("s", "m", "/tmp/a.mp4", processingConsent = processing)
        val result = useCase(sub)
        assertTrue(result.isSuccess)
        assertEquals(SubmissionStatus.READY, result.getOrThrow().status)
    }
}

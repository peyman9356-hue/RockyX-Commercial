package com.rockyx.app.domain

import com.rockyx.app.domain.account.AccountSession
import com.rockyx.app.domain.account.AccountState
import com.rockyx.app.domain.sync.*
import org.junit.Assert.*
import org.junit.Test

class AccountSyncTest {
    @Test fun signedOutSessionIsNotAuthenticated() {
        assertFalse(AccountSession().isAuthenticated())
    }

    @Test fun expiredSessionIsNotAuthenticated() {
        val s = AccountSession(AccountState.SIGNED_IN, "u1", 1L, 10L, "test")
        assertFalse(s.isAuthenticated(10L))
    }

    @Test fun syncOperationCarriesStableIdentityAndVersion() {
        val op = SyncOperation("op1", SyncOperationType.UPSERT_DOG, "dog1", payloadVersion = 2)
        assertEquals("op1", op.id)
        assertEquals(2, op.payloadVersion)
    }
}

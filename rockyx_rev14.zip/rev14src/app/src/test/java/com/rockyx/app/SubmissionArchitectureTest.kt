package com.rockyx.app

import com.rockyx.app.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class SubmissionArchitectureTest {
    @Test fun defaultSubmissionIsPrivateAndHasNoRemoteIdentity() {
        val s = Submission(
            id = "s1", missionId = "m1", localUri = "/private/a.mp4",
            processingConsent = Consent("u1", "submission_processing", true, 1L)
        )
        assertEquals(SubmissionVisibility.PRIVATE, s.visibility)
        assertNull(s.remoteId)
        assertEquals(RemoteSubmissionState.NOT_CREATED, s.remoteState)
    }

    @Test fun publicSubmissionRequiresSeparateConsent() {
        val s = Submission(
            id = "s1", missionId = "m1", localUri = "/private/a.mp4",
            visibility = SubmissionVisibility.PUBLIC,
            processingConsent = Consent("u1", "submission_processing", true, 1L),
            publicSharingConsent = Consent("u1", "submission_public_sharing", false, 2L)
        )
        assertFalse(s.publicSharingConsent?.granted == true)
    }
}

package com.rockyx.app.ui.shell

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class SessionStoreTest {
    @Test
    fun lessonSessionIsRestoredByStableDestinationKey() {
        val store = SessionStore()
        val lesson = AppDestination.Lesson("course-1", "lesson-7")

        store.activate(SessionSnapshot(lesson, scrollAnchor = "exercise", mediaPositionMs = 4200))

        assertEquals("exercise", store.get(lesson)?.scrollAnchor)
        assertEquals(4200, store.get(lesson)?.mediaPositionMs)
        assertEquals(lesson, store.active()?.destination)
    }

    @Test
    fun clearingActiveSessionRemovesOnlyThatSession() {
        val store = SessionStore()
        val first = AppDestination.Lesson("course-1", "lesson-1")
        val second = AppDestination.Lesson("course-1", "lesson-2")
        store.activate(SessionSnapshot(first))
        store.activate(SessionSnapshot(second))

        store.clear(first)

        assertNull(store.get(first))
        assertEquals(second, store.active()?.destination)
    }

    @Test
    fun destinationKeysAreStableAndCollisionFreeForLessons() {
        val a = AppDestination.Lesson("course-1", "lesson-2")
        val b = AppDestination.Lesson("course-1", "lesson-20")
        assertEquals("lesson:course-1:lesson-2", a.key())
        assertEquals("lesson:course-1:lesson-20", b.key())
    }
}

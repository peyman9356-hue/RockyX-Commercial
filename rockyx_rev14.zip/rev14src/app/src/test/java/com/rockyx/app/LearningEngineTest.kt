package com.rockyx.app

import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.ContentRepository
import com.rockyx.app.domain.repository.ProgressRepository
import com.rockyx.app.domain.usecase.*
import org.junit.Assert.*
import org.junit.Test

private class MemoryProgress : ProgressRepository {
    var data = mutableMapOf<String, LessonProgress>()
    override fun snapshot() = ProgressSnapshot(2, data.toMap())
    override fun markExercise(lessonId: String, exerciseId: String, completed: Boolean) { val p=data[lessonId]?:LessonProgress(lessonId); data[lessonId]=p.copy(state=LearningState.IN_PROGRESS, exercises=p.exercises + (exerciseId to ExerciseProgress(exerciseId, completed))) }
    override fun recordQuizAttempt(lessonId: String, attempt: QuizAttempt) { val p=data[lessonId]?:LessonProgress(lessonId); data[lessonId]=p.copy(state=LearningState.IN_PROGRESS, quizAttempts=p.quizAttempts+attempt) }
    override fun updateMission(lessonId: String, missionId: String, result: MissionResult) { val p=data[lessonId]?:LessonProgress(lessonId); data[lessonId]=p.copy(state=LearningState.IN_PROGRESS, missions=p.missions+(missionId to MissionProgress(missionId,result))) }
    override fun setLessonProgress(progress: LessonProgress) { data[progress.lessonId]=progress }
    override fun migrateIfNeeded() = Unit
}

private object LearningFixture {
    private val name = Lesson(
        id = "name",
        title = "Name",
        summary = "Teach the dog its name.",
        access = Access.FREE,
        durationMinutes = 5,
        exercises = listOf(Exercise("name-ex", "Name response", "Say the dog's name and reward eye contact.")),
        quiz = QuizConfig(listOf(QuizQuestion("name-q1", "Which action should be rewarded?", listOf("Eye contact", "Ignoring"), 0))),
        missions = emptyList()
    )
    private val sit = Lesson(
        id = "sit",
        title = "Sit",
        summary = "Teach sit.",
        access = Access.FREE,
        durationMinutes = 5,
        prerequisiteLessonIds = listOf("name")
    )
    private val stay = Lesson(
        id = "stay",
        title = "Stay",
        summary = "Teach stay.",
        access = Access.FREE,
        durationMinutes = 5,
        prerequisiteLessonIds = listOf("sit")
    )
    val repository: ContentRepository = object : ContentRepository {
        private val course = Course(
            id = "beginner",
            title = "Beginner",
            description = "JVM test fixture for Learning Engine behavior.",
            access = Access.FREE,
            daily = false,
            chapters = listOf(Chapter("beginner-ch1", "Basics", listOf(name, sit, stay)))
        )
        override fun courses(): List<Course> = listOf(course)
        override fun course(id: String): Course? = courses().firstOrNull { it.id == id }
    }
}

class LearningEngineTest {
    private val content: ContentRepository = LearningFixture.repository

    @Test fun catalogHasStructuredLearningAndPrerequisites() {
        val c=content.course("beginner")!!
        assertEquals(3,c.chapters.first().lessons.size)
        assertTrue(c.chapters.first().lessons[1].prerequisiteLessonIds.contains("name"))
        assertNotNull(c.chapters.first().lessons[0].quiz)
    }
    @Test fun lessonUnlocksOnlyAfterPrerequisite() {
        val r=MemoryProgress(); val engine=GetLessonState(content,r)
        assertEquals(LearningState.LOCKED,engine("beginner","sit").state)
        r.data["name"]=LessonProgress("name",LearningState.COMPLETED)
        assertEquals(LearningState.AVAILABLE,engine("beginner","sit").state)
    }
    @Test fun quizCalculatesScoreAndPasses() {
        val r=MemoryProgress(); val submit=SubmitQuiz(content,r)
        val result=submit("beginner","name",mapOf("name-q1" to 0))
        assertEquals(100,result.score); assertTrue(result.passed); assertEquals(1,result.correct)
    }
    @Test fun lessonCompletesOnlyWhenRequirementsAreMet() {
        val r=MemoryProgress(); val complete=EvaluateLesson(content,r)
        r.data["name"]=LessonProgress("name",LearningState.IN_PROGRESS, exercises=mapOf("name-ex" to ExerciseProgress("name-ex",true)), quizAttempts=listOf(QuizAttempt("a","name",mapOf("name-q1" to 0),100,true,1)))
        val p=complete("beginner","name")
        assertEquals(LearningState.COMPLETED,p.state); assertEquals(100,p.score)
    }
    @Test fun courseProgressUsesRealCompletionState() {
        val r=MemoryProgress(); r.data["name"]=LessonProgress("name",LearningState.COMPLETED)
        val p=GetCourseProgress(content,r)("beginner")
        assertEquals(33,p.percent)
    }
    @Test fun nextLessonFollowsSequence() {
        val r=MemoryProgress(); val next=GetNextLesson(content,r)
        assertEquals("name",next("beginner")?.id)
        r.data["name"]=LessonProgress("name",LearningState.COMPLETED)
        assertEquals("sit",next("beginner")?.id)
    }

    @Test(expected = IllegalArgumentException::class)
    fun quizRejectsMissingAnswers() {
        val r=MemoryProgress(); val submit=SubmitQuiz(content,r)
        submit("beginner","name", emptyMap())
    }

    @Test(expected = IllegalArgumentException::class)
    fun quizRejectsOutOfRangeAnswer() {
        val r=MemoryProgress(); val submit=SubmitQuiz(content,r)
        submit("beginner","name", mapOf("name-q1" to 99))
    }

    @Test(expected = IllegalArgumentException::class)
    fun exerciseRejectsUnknownExerciseId() {
        val r=MemoryProgress(); val complete=CompleteExercise(content,r)
        complete("beginner","name","not-a-real-exercise",true)
    }

    @Test(expected = IllegalArgumentException::class)
    fun missionRejectsUnknownMissionId() {
        val r=MemoryProgress(); val update=UpdateMission(content,r)
        update("beginner","name","not-a-real-mission",MissionResult.SUCCESS)
    }
}

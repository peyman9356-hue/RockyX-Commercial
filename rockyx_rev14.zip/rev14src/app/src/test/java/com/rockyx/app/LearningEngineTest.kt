package com.rockyx.app

import com.rockyx.app.data.content.LocalContentRepository
import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.ProgressRepository
import com.rockyx.app.domain.usecase.*
import org.junit.Assert.*
import org.junit.Test

private class MemoryProgress : ProgressRepository {
    var data = mutableMapOf<String, LessonProgress>()
    override fun snapshot() = ProgressSnapshot(2, data.toMap())
    override fun markExercise(lessonId: String, exerciseId: String, completed: Boolean) { val p=data[lessonId]?:LessonProgress(lessonId); data[lessonId]=p.copy(state=LearningState.IN_PROGRESS, exercises=p.exercises + (exerciseId to ExerciseProgress(exerciseId, completed))) }
    override fun recordQuizAttempt(lessonId: String, attempt: QuizAttempt) { val p=data[lessonId]?:LessonProgress(lessonId); data[lessonId]=p.copy(state=LearningState.IN_PROGRESS, quizAttempts=p.quizAttempts+attempt) }
    override fun updateMission(lessonId: String, missionId: String, result: MissionResult) { val p=data[lessonId]?:LessonProgress(lessonId); data[lessonId]=p.copy(state=LearningState.IN_PROGRESS, missions=p.missions+(missionId to MissionProgress(missionId,result))) }
    override fun setLessonProgress(progress: LessonProgress) { data[progress.lessonId]=progress }
    override fun migrateIfNeeded() = Unit
}

class LearningEngineTest {
    @Test fun catalogHasStructuredLearningAndPrerequisites() {
        val c=LocalContentRepository().course("beginner")!!
        assertEquals(3,c.chapters.first().lessons.size)
        assertTrue(c.chapters.first().lessons[1].prerequisiteLessonIds.contains("name"))
        assertNotNull(c.chapters.first().lessons[0].quiz)
    }
    @Test fun lessonUnlocksOnlyAfterPrerequisite() {
        val r=MemoryProgress(); val engine=GetLessonState(LocalContentRepository(),r)
        assertEquals(LearningState.LOCKED,engine("beginner","sit").state)
        r.data["name"]=LessonProgress("name",LearningState.COMPLETED)
        assertEquals(LearningState.AVAILABLE,engine("beginner","sit").state)
    }
    @Test fun quizCalculatesScoreAndPasses() {
        val r=MemoryProgress(); val submit=SubmitQuiz(LocalContentRepository(),r)
        val result=submit("beginner","name",mapOf("name-q1" to 0))
        assertEquals(100,result.score); assertTrue(result.passed); assertEquals(1,result.correct)
    }
    @Test fun lessonCompletesOnlyWhenRequirementsAreMet() {
        val r=MemoryProgress(); val content=LocalContentRepository(); val complete=EvaluateLesson(content,r)
        r.data["name"]=LessonProgress("name",LearningState.IN_PROGRESS, exercises=mapOf("name-ex" to ExerciseProgress("name-ex",true)), quizAttempts=listOf(QuizAttempt("a","name",mapOf("name-q1" to 0),100,true,1)))
        val p=complete("beginner","name")
        assertEquals(LearningState.COMPLETED,p.state); assertEquals(100,p.score)
    }
    @Test fun courseProgressUsesRealCompletionState() {
        val r=MemoryProgress(); r.data["name"]=LessonProgress("name",LearningState.COMPLETED)
        val p=GetCourseProgress(LocalContentRepository(),r)("beginner")
        assertEquals(33,p.percent)
    }
    @Test fun nextLessonFollowsSequence() {
        val r=MemoryProgress(); val next=GetNextLesson(LocalContentRepository(),r)
        assertEquals("name",next("beginner")?.id)
        r.data["name"]=LessonProgress("name",LearningState.COMPLETED)
        assertEquals("sit",next("beginner")?.id)
    }
    @Test(expected = IllegalArgumentException::class)
    fun quizRejectsMissingAnswers() {
        val r=MemoryProgress(); val submit=SubmitQuiz(LocalContentRepository(),r)
        submit("beginner","name", emptyMap())
    }

    @Test(expected = IllegalArgumentException::class)
    fun quizRejectsOutOfRangeAnswer() {
        val r=MemoryProgress(); val submit=SubmitQuiz(LocalContentRepository(),r)
        submit("beginner","name", mapOf("name-q1" to 99))
    }

    @Test(expected = IllegalArgumentException::class)
    fun exerciseRejectsUnknownExerciseId() {
        val r=MemoryProgress(); val complete=CompleteExercise(LocalContentRepository(),r)
        complete("beginner","name","not-a-real-exercise",true)
    }

    @Test(expected = IllegalArgumentException::class)
    fun missionRejectsUnknownMissionId() {
        val r=MemoryProgress(); val update=UpdateMission(LocalContentRepository(),r)
        update("beginner","name","not-a-real-mission",MissionResult.SUCCESS)
    }

}

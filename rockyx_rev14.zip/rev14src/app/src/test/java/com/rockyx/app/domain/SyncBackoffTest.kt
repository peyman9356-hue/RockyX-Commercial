package com.rockyx.app.domain

import com.rockyx.app.domain.sync.SyncBackoff
import com.rockyx.app.domain.sync.SyncOperation
import com.rockyx.app.domain.sync.SyncOperationType
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class SyncBackoffTest {
    @Test fun recentFailureWaitsBeforeRetry() {
        val now = 1_000_000L
        val op = SyncOperation("1", SyncOperationType.UPSERT_DOG, "dog", createdAt = now - 1_000, attemptCount = 2)
        assertFalse(SyncBackoff.eligible(op, now))
    }

    @Test fun oldOperationBecomesEligible() {
        val now = 1_000_000L
        val op = SyncOperation("1", SyncOperationType.UPSERT_DOG, "dog", createdAt = now - 120_000, attemptCount = 1)
        assertTrue(SyncBackoff.eligible(op, now))
    }
}

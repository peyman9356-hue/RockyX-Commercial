package com.rockyx.app.domain

import com.rockyx.app.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class CommerceModelTest {
    @Test fun activeEntitlementExpires() {
        val now = System.currentTimeMillis()
        val e = Entitlement("rockyx_pro", Access.PRO, EntitlementState.ACTIVE, now - 1000, now + 60_000)
        assertTrue(e.isActive(now))
        assertFalse(e.isActive(now + 61_000))
    }

    @Test fun premiumIsDistinctTier() {
        assertNotEquals(Access.PRO, Access.PREMIUM)
    }
}

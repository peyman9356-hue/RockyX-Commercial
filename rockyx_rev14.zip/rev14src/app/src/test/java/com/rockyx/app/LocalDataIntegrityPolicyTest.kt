package com.rockyx.app

import com.rockyx.app.data.LocalDataCorruptionException
import kotlin.test.Test
import kotlin.test.assertEquals

class LocalDataIntegrityPolicyTest {
    @Test fun corruptionExceptionPreservesStoreIdentity() {
        val cause = IllegalArgumentException("bad json")
        val e = LocalDataCorruptionException("sync_queue", cause)
        assertEquals("sync_queue", e.storeName)
        assertEquals(cause, e.cause)
    }
}

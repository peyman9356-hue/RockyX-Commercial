package com.rockyx.app

import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.*
import com.rockyx.app.domain.usecase.GetPersonalizedLessons
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalizationTest {
    private val lesson = Lesson("come", "Come", "", Access.FREE, 8, goalTags=listOf("recall"), behaviorTags=listOf("roaming"), recommendedLevels=listOf("Beginner"))
    private val course = Course("c", "C", "", Access.FREE, false, listOf(Chapter("ch", "CH", listOf(lesson))))
    private val content = object: ContentRepository { override fun courses()=listOf(course); override fun course(id:String)=course.takeIf{it.id==id} }
    private val progress = object: ProgressRepository {
        override fun snapshot()=ProgressSnapshot(2, emptyMap()); override fun markExercise(l:String,e:String,c:Boolean){}; override fun recordQuizAttempt(l:String,a:QuizAttempt){}; override fun updateMission(l:String,m:String,r:MissionResult){}; override fun setLessonProgress(p:LessonProgress){}; override fun migrateIfNeeded(){}
    }
    private val dog = object: DogRepository { var p=DogProfile("d","R",24,"Beginner",listOf("recall"),listOf("roaming")); override fun current()=p; override fun save(profile:DogProfile){p=profile} }
    @Test fun matchingGoalsAndBehaviorsRankLesson() { val result=GetPersonalizedLessons(content,progress,dog)("c",1); assertEquals(1,result.size); assertTrue(result.first().score>0); assertTrue(result.first().reasons.size>=2) }
}

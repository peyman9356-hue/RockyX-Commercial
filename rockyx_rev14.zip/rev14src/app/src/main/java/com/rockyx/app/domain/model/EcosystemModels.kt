package com.rockyx.app.domain.model

/** Device-neutral models used by the app; concrete Bluetooth/GNSS/cellular implementations stay in platform/data layers. */
data class DeviceIdentity(
    val deviceId: String,
    val dogId: String?,
    val deviceType: String,
    val hardwareRevision: String? = null,
    val firmwareVersion: String? = null,
    val batteryPercent: Int? = null,
    val status: String = "ACTIVE"
)

data class DogEventRecord(
    val eventId: String,
    val dogId: String,
    val eventType: String,
    val payloadJson: String,
    val occurredAtEpochMs: Long
)

data class LocationRecord(
    val latitudeE6: Int,
    val longitudeE6: Int,
    val accuracyMeters: Int?,
    val recordedAtEpochMs: Long
)

data class SafetyEventRecord(
    val safetyEventId: String,
    val dogId: String,
    val eventType: String,
    val status: String,
    val location: LocationRecord?,
    val occurredAtEpochMs: Long
)

data class AiInsightRecord(
    val insightId: String,
    val dogId: String,
    val kind: String,
    val evidenceJson: String,
    val inferenceJson: String,
    val recommendationJson: String,
    val confidence: Int,
    val createdAtEpochMs: Long
)

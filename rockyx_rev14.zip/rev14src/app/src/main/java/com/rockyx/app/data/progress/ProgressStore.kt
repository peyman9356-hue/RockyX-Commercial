package com.rockyx.app.data.progress

import android.content.Context
import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.ProgressRepository
import org.json.JSONArray
import org.json.JSONObject

class ProgressStore(context: Context) : ProgressRepository {
    companion object { const val CURRENT_SCHEMA = 2 }
    private val prefs = context.getSharedPreferences("rockyx_progress", Context.MODE_PRIVATE)

    override fun snapshot(): ProgressSnapshot {
        migrateIfNeeded()
        val root = JSONObject(prefs.getString("snapshot", emptySnapshot()) ?: emptySnapshot())
        val lessonsJson = root.optJSONObject("lessons") ?: JSONObject()
        val map = mutableMapOf<String, LessonProgress>()
        lessonsJson.keys().forEach { id -> map[id] = decodeLesson(id, lessonsJson.getJSONObject(id)) }
        return ProgressSnapshot(root.optInt("schemaVersion", CURRENT_SCHEMA), map)
    }

    override fun markExercise(lessonId: String, exerciseId: String, completed: Boolean) {
        val current = getLesson(lessonId)
        val exercises = current.exercises.toMutableMap()
        exercises[exerciseId] = ExerciseProgress(exerciseId, completed, if (completed) System.currentTimeMillis() else null)
        setLessonProgress(current.copy(state = LearningState.IN_PROGRESS, exercises = exercises))
    }

    override fun recordQuizAttempt(lessonId: String, attempt: QuizAttempt) {
        val current = getLesson(lessonId)
        setLessonProgress(current.copy(state = LearningState.IN_PROGRESS, quizAttempts = current.quizAttempts + attempt))
    }

    override fun updateMission(lessonId: String, missionId: String, result: MissionResult) {
        val current = getLesson(lessonId)
        val missions = current.missions.toMutableMap()
        missions[missionId] = MissionProgress(missionId, result, System.currentTimeMillis())
        setLessonProgress(current.copy(state = LearningState.IN_PROGRESS, missions = missions))
    }

    override fun setLessonProgress(progress: LessonProgress) {
        val root = JSONObject()
        root.put("schemaVersion", CURRENT_SCHEMA)
        val lessons = JSONObject()
        snapshotRaw().lessons.values.forEach { p -> lessons.put(p.lessonId, encodeLesson(p)) }
        lessons.put(progress.lessonId, encodeLesson(progress))
        root.put("lessons", lessons)
        prefs.edit().putString("snapshot", root.toString()).apply()
    }

    override fun migrateIfNeeded() {
        val raw = prefs.getString("snapshot", null) ?: return
        try {
            val old = JSONObject(raw)
            val version = old.optInt("schemaVersion", 1)
            require(version in 1..CURRENT_SCHEMA) { "Unsupported progress schema: $version" }
            val lessons = old.optJSONObject("lessons") ?: throw IllegalArgumentException("Missing progress lessons")
            if (version < CURRENT_SCHEMA) {
                val root = JSONObject().put("schemaVersion", CURRENT_SCHEMA).put("lessons", lessons)
                prefs.edit().putString("snapshot", root.toString()).apply()
            }
        } catch (t: Throwable) {
            prefs.edit().putString("snapshot.corrupt.${System.currentTimeMillis()}", raw).remove("snapshot").apply()
            throw com.rockyx.app.data.LocalDataCorruptionException("learning_progress", t)
        }
    }

    private fun snapshotRaw(): ProgressSnapshot {
        val root = JSONObject(prefs.getString("snapshot", emptySnapshot()) ?: emptySnapshot())
        val lessons = root.optJSONObject("lessons") ?: JSONObject()
        val map = mutableMapOf<String, LessonProgress>()
        lessons.keys().forEach { id -> map[id] = decodeLesson(id, lessons.getJSONObject(id)) }
        return ProgressSnapshot(root.optInt("schemaVersion", CURRENT_SCHEMA), map)
    }
    private fun getLesson(id: String) = snapshotRaw().lessons[id] ?: LessonProgress(id)
    private fun encodeLesson(p: LessonProgress): JSONObject = JSONObject().apply {
        put("state", p.state.name); p.completedAt?.let { put("completedAt", it) }; p.score?.let { put("score", it) }
        put("exercises", JSONObject().apply { p.exercises.values.forEach { e -> put(e.exerciseId, JSONObject().apply { put("completed", e.completed); e.completedAt?.let { put("completedAt", it) } }) } })
        put("quizAttempts", JSONArray().apply { p.quizAttempts.forEach { a -> put(JSONObject().apply { put("attemptId", a.attemptId); put("lessonId", a.lessonId); put("score", a.score); put("passed", a.passed); put("attemptedAt", a.attemptedAt); put("answers", JSONObject().apply { a.answers.forEach { (k,v) -> put(k,v) } }) }) } })
        put("missions", JSONObject().apply { p.missions.values.forEach { m -> put(m.missionId, JSONObject().apply { put("result", m.result.name); m.updatedAt?.let { put("updatedAt", it) } }) } })
    }
    private fun decodeLesson(id: String, o: JSONObject): LessonProgress {
        val exercises = mutableMapOf<String, ExerciseProgress>(); val ej = o.optJSONObject("exercises") ?: JSONObject()
        ej.keys().forEach { eid -> val x = ej.getJSONObject(eid); exercises[eid] = ExerciseProgress(eid, x.optBoolean("completed"), x.optLong("completedAt").takeIf { it > 0 }) }
        val attempts = mutableListOf<QuizAttempt>(); val qa = o.optJSONArray("quizAttempts") ?: JSONArray()
        for (i in 0 until qa.length()) { val a=qa.getJSONObject(i); val ans=mutableMapOf<String,Int>(); val aj=a.optJSONObject("answers") ?: JSONObject(); aj.keys().forEach { k -> ans[k]=aj.optInt(k) }; attempts += QuizAttempt(a.optString("attemptId"), a.optString("lessonId", id), ans, a.optInt("score"), a.optBoolean("passed"), a.optLong("attemptedAt")) }
        val missions=mutableMapOf<String,MissionProgress>(); val mj=o.optJSONObject("missions") ?: JSONObject(); mj.keys().forEach { mid -> val m=mj.getJSONObject(mid); missions[mid]=MissionProgress(mid, MissionResult.valueOf(m.optString("result")), m.optLong("updatedAt").takeIf { it>0 }) }
        val state=runCatching { LearningState.valueOf(o.optString("state", LearningState.AVAILABLE.name)) }.getOrDefault(LearningState.AVAILABLE)
        return LessonProgress(id, state, o.optLong("completedAt").takeIf { it>0 }, o.optInt("score").takeIf { o.has("score") }, exercises, attempts, missions)
    }
    private fun emptySnapshot() = JSONObject().put("schemaVersion", CURRENT_SCHEMA).put("lessons", JSONObject()).toString()
}

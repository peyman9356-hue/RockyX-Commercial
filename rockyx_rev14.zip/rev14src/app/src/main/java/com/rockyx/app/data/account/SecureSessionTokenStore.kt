package com.rockyx.app.data.account

import android.content.Context
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Android Keystore-backed token storage. Raw refresh tokens never enter ordinary SharedPreferences. */
class SecureSessionTokenStore(context: Context) {
    private val prefs = context.getSharedPreferences("rockyx_secure_session_v1", Context.MODE_PRIVATE)
    private val alias = "rockyx.session.aes.v1"
    private val key: SecretKey
        get() {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val existing = ks.getKey(alias, null)
            if (existing is SecretKey) return existing
            val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
            generator.init(android.security.keystore.KeyGenParameterSpec.Builder(alias, android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(false).build())
            return generator.generateKey()
        }

    fun save(accessToken: String, refreshToken: String, expiresAt: Long, userId: String, provider: String) {
        prefs.edit().putString("access", encrypt(accessToken)).putString("refresh", encrypt(refreshToken))
            .putLong("expiresAt", expiresAt).putString("userId", userId).putString("provider", provider).apply()
    }
    fun accessToken(): String? = prefs.getString("access", null)?.let { runCatching { decrypt(it) }.getOrNull() }
    fun refreshToken(): String? = prefs.getString("refresh", null)?.let { runCatching { decrypt(it) }.getOrNull() }
    fun expiresAt(): Long? = prefs.getLong("expiresAt", Long.MIN_VALUE).takeIf { it != Long.MIN_VALUE }
    fun clear() { prefs.edit().clear().apply() }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key) }
        return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String {
        val bytes = Base64.decode(value, Base64.NO_WRAP); require(bytes.size > 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, bytes.copyOfRange(0, 12))) }
        return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), StandardCharsets.UTF_8)
    }
}

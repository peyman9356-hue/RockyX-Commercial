package com.rockyx.app.data.account

import android.app.Activity
import android.content.Context
import androidx.credentials.CreatePublicKeyCredentialRequest
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetPublicKeyCredentialOption
import androidx.credentials.PublicKeyCredential
import androidx.credentials.CreatePublicKeyCredentialResponse

/** Provider-neutral passkey transport. Server-generated WebAuthn JSON is mandatory; no local credential authority. */
class PasskeyCredentialManagerAdapter(context: Context) {
    private val credentialManager = CredentialManager.create(context)

    suspend fun signIn(activity: Activity, requestJson: String): Result<String> = runCatching {
        require(requestJson.length in 64..64_000)
        val option = GetPublicKeyCredentialOption(requestJson)
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = credentialManager.getCredential(activity, request)
        val credential = result.credential as? PublicKeyCredential ?: error("Credential provider returned a non-passkey credential")
        credential.authenticationResponseJson
    }

    suspend fun create(activity: Activity, creationJson: String): Result<String> = runCatching {
        require(creationJson.length in 64..64_000)
        val request = CreatePublicKeyCredentialRequest(creationJson)
        val result = credentialManager.createCredential(activity, request)
        val response = result as? CreatePublicKeyCredentialResponse ?: error("Credential provider returned a non-passkey registration response")
        response.registrationResponseJson
    }
}

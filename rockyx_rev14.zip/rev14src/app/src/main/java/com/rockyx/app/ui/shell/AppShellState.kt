package com.rockyx.app.ui.shell

/** UI-only state for the fixed Rocky X shell. */
class AppShellState {
    var destination: AppDestination = AppDestination.Home
        private set

    var leftMenuOpen: Boolean = false
        private set

    var rightPanel: RightPanel? = null
        private set

    fun navigateTo(destination: AppDestination) {
        this.destination = destination
        leftMenuOpen = false
        rightPanel = null
    }

    fun toggleLeftMenu() {
        leftMenuOpen = !leftMenuOpen
        if (leftMenuOpen) rightPanel = null
    }

    fun openRightPanel(panel: RightPanel) {
        rightPanel = panel
        leftMenuOpen = false
    }

    fun closePanels() {
        leftMenuOpen = false
        rightPanel = null
    }

    enum class RightPanel { LIBRARY, SETTINGS }
}

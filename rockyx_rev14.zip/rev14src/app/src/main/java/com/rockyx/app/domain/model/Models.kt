package com.rockyx.app.domain.model

enum class Access { FREE, PRO, PREMIUM }
enum class ContentType { TEXT, IMAGE, AUDIO, VIDEO, EXERCISE, QUIZ, MISSION, ASSESSMENT }
enum class LearningState { LOCKED, AVAILABLE, IN_PROGRESS, COMPLETED, MASTERED }
enum class MissionResult { NOT_STARTED, IN_PROGRESS, SUCCESS, FAILED }

data class MediaRef(val id: String, val type: ContentType, val uri: String? = null, val downloadable: Boolean = false, val thumbnailUri: String? = null)
data class Exercise(val id: String, val title: String, val instructions: String, val successCriteria: List<String> = emptyList(), val media: List<MediaRef> = emptyList())
data class QuizQuestion(val id: String, val prompt: String, val options: List<String>, val correctIndex: Int)
data class QuizConfig(val questions: List<QuizQuestion>, val passPercent: Int = 70, val maxAttempts: Int? = null)
data class Mission(val id: String, val title: String, val instructions: String, val requiresSubmission: Boolean = false)
data class Lesson(
    val id: String, val title: String, val summary: String, val access: Access,
    val durationMinutes: Int, val exercises: List<Exercise> = emptyList(),
    val quiz: QuizConfig? = null, val missions: List<Mission> = emptyList(),
    val media: List<MediaRef> = emptyList(), val prerequisiteLessonIds: List<String> = emptyList(),
    val goalTags: List<String> = emptyList(), val behaviorTags: List<String> = emptyList(),
    val recommendedLevels: List<String> = emptyList()
)
data class Chapter(val id: String, val title: String, val lessons: List<Lesson>)
data class Course(
    val id: String, val title: String, val description: String, val access: Access,
    val daily: Boolean, val chapters: List<Chapter>
)
data class DogProfile(
    val id: String, val name: String, val ageMonths: Int, val level: String,
    val goals: List<String>, val behaviors: List<String> = emptyList(),
    val breed: String = "", val temperament: List<String> = emptyList(),
    val skills: Map<String, LearningState> = emptyMap(), val profileVersion: Int = 1,
    val dateOfBirthEpochMs: Long? = null, val sex: String? = null,
    val weightGrams: Int? = null, val activityBaseline: Int? = null,
    val notes: List<String> = emptyList()
)
data class ExerciseProgress(val exerciseId: String, val completed: Boolean = false, val completedAt: Long? = null)
data class QuizAttempt(val attemptId: String, val lessonId: String, val answers: Map<String, Int>, val score: Int, val passed: Boolean, val attemptedAt: Long)
data class MissionProgress(val missionId: String, val result: MissionResult = MissionResult.NOT_STARTED, val updatedAt: Long? = null)
data class LessonProgress(
    val lessonId: String, val state: LearningState = LearningState.AVAILABLE,
    val completedAt: Long? = null, val score: Int? = null,
    val exercises: Map<String, ExerciseProgress> = emptyMap(),
    val quizAttempts: List<QuizAttempt> = emptyList(),
    val missions: Map<String, MissionProgress> = emptyMap()
)
data class CourseProgress(val courseId: String, val completedLessons: Int, val totalLessons: Int, val percent: Int)
data class ProgressSnapshot(val schemaVersion: Int, val lessons: Map<String, LessonProgress>)
data class LessonStateView(val lessonId: String, val state: LearningState, val score: Int?, val reason: String? = null)
data class QuizResult(val score: Int, val passed: Boolean, val correct: Int, val total: Int, val attemptId: String)
enum class EntitlementState { ACTIVE, EXPIRED, REVOKED, PENDING }

data class Entitlement(
    val productId: String,
    val tier: Access,
    val state: EntitlementState,
    val startsAt: Long? = null,
    val expiresAt: Long? = null,
    val source: String = "local"
) {
    fun isActive(now: Long = System.currentTimeMillis()): Boolean =
        state == EntitlementState.ACTIVE && (expiresAt == null || expiresAt > now) && (startsAt == null || startsAt <= now)
}

data class PricingPlan(
    val id: String,
    val productId: String,
    val displayName: String,
    val tier: Access,
    val billingPeriod: String,
    val currency: String,
    val amountMinor: Long,
    val region: String,
    val trialDays: Int = 0,
    val discountPercent: Int = 0,
    val offerId: String? = null,
    val active: Boolean = true
)
data class Consent(val userId: String, val scope: String, val granted: Boolean, val timestamp: Long?)
enum class SubmissionStatus { DRAFT, READY, QUEUED, UPLOADING, PENDING_REVIEW, APPROVED, REJECTED, FAILED }
enum class SubmissionVisibility { PRIVATE, UNLISTED, PUBLIC }

enum class RemoteSubmissionState { NOT_CREATED, CREATED, UPLOADING, PENDING_REVIEW, APPROVED, REJECTED, DELETED }

data class Submission(
    val id: String,
    val missionId: String,
    val localUri: String,
    val status: SubmissionStatus = SubmissionStatus.DRAFT,
    val visibility: SubmissionVisibility = SubmissionVisibility.PRIVATE,
    val processingConsent: Consent? = null,
    val publicSharingConsent: Consent? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val uploadId: String? = null,
    val remoteId: String? = null,
    val remoteState: RemoteSubmissionState = RemoteSubmissionState.NOT_CREATED,
    val failureReason: String? = null
)

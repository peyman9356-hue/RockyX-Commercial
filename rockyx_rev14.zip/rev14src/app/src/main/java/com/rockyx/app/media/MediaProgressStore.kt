package com.rockyx.app.media

import android.content.Context
import org.json.JSONObject

/** Small durable store for resume positions. It can later be replaced by Room/cloud sync without changing UI. */
class MediaProgressStore(context: Context) {
    private val prefs = context.getSharedPreferences("rockyx_media_progress_v1", Context.MODE_PRIVATE)

    fun get(mediaId: String): MediaProgress? {
        val raw = prefs.getString(mediaId, null) ?: return null
        val j = JSONObject(raw)
        return MediaProgress(mediaId, j.optLong("positionMs"), j.optLong("durationMs"), j.optLong("updatedAt"))
    }

    fun save(progress: MediaProgress) {
        prefs.edit().putString(progress.mediaId, JSONObject().apply {
            put("positionMs", progress.positionMs)
            put("durationMs", progress.durationMs)
            put("updatedAt", progress.updatedAt)
        }.toString()).apply()
    }

    fun clear(mediaId: String) = prefs.edit().remove(mediaId).apply()
}

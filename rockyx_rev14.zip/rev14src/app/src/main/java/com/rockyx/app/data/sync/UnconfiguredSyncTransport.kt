package com.rockyx.app.data.sync

import com.rockyx.app.domain.repository.SyncTransport
import com.rockyx.app.domain.sync.SyncOperation

/** Fail-closed until an authenticated backend API is configured. */
class UnconfiguredSyncTransport : SyncTransport {
    override fun push(operations: List<SyncOperation>): Result<Unit> =
        Result.failure(IllegalStateException("Sync backend is not configured"))
}

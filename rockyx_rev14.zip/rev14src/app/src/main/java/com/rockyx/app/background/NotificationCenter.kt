package com.rockyx.app.background

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationCenter {
    const val CHANNEL_SYNC = "rockyx_sync"
    const val CHANNEL_MEDIA = "rockyx_media"
    const val CHANNEL_SUBMISSION = "rockyx_submission"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannels(listOf(
            NotificationChannel(CHANNEL_SYNC, "همگام‌سازی", NotificationManager.IMPORTANCE_LOW),
            NotificationChannel(CHANNEL_MEDIA, "رسانه", NotificationManager.IMPORTANCE_LOW),
            NotificationChannel(CHANNEL_SUBMISSION, "ارسال ویدئو", NotificationManager.IMPORTANCE_DEFAULT)
        ))
    }

    fun show(context: Context, channelId: String, id: Int, title: String, body: String) {
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id, notification)
    }
}

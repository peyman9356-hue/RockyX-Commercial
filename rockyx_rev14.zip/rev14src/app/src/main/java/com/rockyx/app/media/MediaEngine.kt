package com.rockyx.app.media

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.util.UUID

@UnstableApi
class MediaEngine(private val context: Context) {
    private val progress = MediaProgressStore(context)
    private val player = ExoPlayer.Builder(context)
        .setMediaSourceFactory(DefaultMediaSourceFactory(MediaDownloadRepository.dataSourceFactory(context)))
        .build()
    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) { persist() }
        override fun onIsPlayingChanged(isPlaying: Boolean) { if (!isPlaying) persist() }
    }

    init { player.addListener(listener) }

    fun attach(view: PlayerView) { view.player = player }

    fun play(media: MediaDescriptor) {
        val item = MediaItem.Builder().setMediaId(media.id).setUri(media.uri).build()
        player.setMediaItem(item)
        val saved = progress.get(media.id)?.positionMs ?: 0L
        player.prepare()
        if (saved > 0) player.seekTo(saved)
        player.playWhenReady = true
    }

    fun playAuthorized(grant: PlaybackGrant) {
        val item = MediaItemFactory.fromGrant(grant)
        player.setMediaItem(item)
        val saved = progress.get(grant.mediaId)?.positionMs ?: 0L
        player.prepare()
        if (saved > 0) player.seekTo(saved)
        player.playWhenReady = true
    }

    fun pause() { player.pause(); persist() }
    fun release() { persist(); player.removeListener(listener); player.release() }

    fun positionMs(): Long = player.currentPosition
    fun durationMs(): Long = player.duration.coerceAtLeast(0L)

    fun persist() {
        val id = player.currentMediaItem?.mediaId ?: return
        progress.save(MediaProgress(id, positionMs(), durationMs(), System.currentTimeMillis()))
    }

    fun download(media: MediaDescriptor) {
        require(media.downloadable) { "Media is not marked downloadable" }
        val request = DownloadRequest.Builder(media.id, android.net.Uri.parse(media.uri)).build()
        androidx.media3.exoplayer.offline.DownloadService.sendAddDownload(
            context, RockyXDownloadService::class.java, request, true
        )
    }

    fun removeDownload(mediaId: String) {
        androidx.media3.exoplayer.offline.DownloadService.sendRemoveDownload(
            context, RockyXDownloadService::class.java, mediaId, true
        )
    }
}

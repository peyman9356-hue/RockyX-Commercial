package com.rockyx.app.data.consent

import android.content.Context
import com.rockyx.app.domain.model.Consent
import com.rockyx.app.domain.repository.ConsentRepository
import org.json.JSONObject

class ConsentStore(context: Context) : ConsentRepository {
    private val p = context.getSharedPreferences("rockyx_consent_v1", Context.MODE_PRIVATE)
    override fun get(userId: String, scope: String): Consent? = p.getString("$userId:$scope", null)?.let { j -> val x = JSONObject(j); Consent(userId, scope, x.getBoolean("granted"), x.optLong("timestamp").takeIf { it > 0 }) }
    override fun save(consent: Consent) { p.edit().putString("${consent.userId}:${consent.scope}", JSONObject().apply { put("granted", consent.granted); consent.timestamp?.let { put("timestamp", it) } }.toString()).apply() }
}

package com.rockyx.app

import android.app.Application
import com.rockyx.app.reliability.CrashRecovery

class RockyXApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashRecovery.install(this)
    }
}

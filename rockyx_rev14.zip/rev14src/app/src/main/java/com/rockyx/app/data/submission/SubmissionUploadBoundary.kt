package com.rockyx.app.data.submission

import com.rockyx.app.domain.model.Submission
import com.rockyx.app.domain.model.RemoteSubmissionState
import com.rockyx.app.domain.repository.SubmissionUploadGateway
import com.rockyx.app.domain.repository.SubmissionUploadReceipt

/** Intentionally unavailable until an authenticated production backend is connected. */
class UnconfiguredSubmissionUploadGateway : SubmissionUploadGateway {
    override fun available() = false
    override fun enqueue(submission: Submission): Result<SubmissionUploadReceipt> =
        Result.failure(IllegalStateException("authenticated backend upload is not configured"))
    override fun cancel(uploadId: String): Result<Unit> =
        Result.failure(IllegalStateException("authenticated backend upload is not configured"))
    override fun deleteRemote(remoteId: String): Result<Unit> =
        Result.failure(IllegalStateException("authenticated backend deletion is not configured"))
}

package com.rockyx.app.ui.shell

/**
 * Visual contract for the fixed Rocky X shell.
 * The actual Android view implementation lives in MainActivity during the
 * incremental migration; this type keeps the shell concept explicit and
 * testable without coupling it to domain logic.
 */
data class AppShell(
    val destination: AppDestination = AppDestination.Home,
    val leftMenuOpen: Boolean = false,
    val rightPanel: AppShellState.RightPanel? = null,
    val composerEnabled: Boolean = true
)

package com.rockyx.app.media

import com.rockyx.app.domain.model.ContentType

/** A normalized media descriptor used by playback and offline layers. */
data class MediaDescriptor(
    val id: String,
    val type: ContentType,
    val uri: String,
    val downloadable: Boolean,
    val title: String? = null
)

enum class MediaAvailability { STREAMING, DOWNLOADED, UNAVAILABLE }

data class MediaProgress(val mediaId: String, val positionMs: Long, val durationMs: Long, val updatedAt: Long)

package com.rockyx.app.domain.usecase

import com.rockyx.app.domain.account.AccountState
import com.rockyx.app.domain.repository.AccountRepository
import com.rockyx.app.domain.repository.AuthProvider
import com.rockyx.app.domain.repository.SyncRepository
import com.rockyx.app.domain.repository.SyncTransport
import com.rockyx.app.domain.sync.SyncSnapshot

class GetAccountSession(private val accounts: AccountRepository) { operator fun invoke() = accounts.session() }

class SignIn(private val accounts: AccountRepository, private val provider: AuthProvider) {
    operator fun invoke() = provider.signIn().onSuccess { session ->
        require(session.state == AccountState.SIGNED_IN && !session.userId.isNullOrBlank())
        accounts.saveSession(session)
    }
}

class SignOut(private val accounts: AccountRepository, private val provider: AuthProvider) {
    operator fun invoke() = provider.signOut().onSuccess { accounts.clearSession() }
}

class SyncPendingChanges(
    private val accounts: AccountRepository,
    private val sync: SyncRepository,
    private val transport: SyncTransport
) {
    operator fun invoke(): Result<SyncSnapshot> {
        if (!accounts.session().isAuthenticated()) return Result.success(sync.snapshot().copy(state = com.rockyx.app.domain.sync.SyncState.BLOCKED_AUTH))
        val batch = sync.pending()
        if (batch.isEmpty()) return Result.success(sync.snapshot())
        return transport.push(batch).map {
            batch.forEach { sync.markSucceeded(it.id) }
            sync.snapshot()
        }.onFailure { error -> batch.forEach { sync.markFailed(it.id, error.message ?: "sync failed") } }
    }
}

package com.rockyx.app.media

import android.content.Context
import java.io.File

class MediaPolicy(private val context: Context) {
    fun privateMediaDir(): File = File(context.filesDir, "media").also { it.mkdirs() }
    fun fileFor(mediaId: String, extension: String): File = File(privateMediaDir(), "$mediaId.$extension")
}

package com.rockyx.app.domain.connectivity

enum class ConnectivityState { OFFLINE, ONLINE, UNKNOWN }

data class ConnectivitySnapshot(
    val state: ConnectivityState,
    val checkedAt: Long = System.currentTimeMillis()
) {
    val isOnline: Boolean get() = state == ConnectivityState.ONLINE
}

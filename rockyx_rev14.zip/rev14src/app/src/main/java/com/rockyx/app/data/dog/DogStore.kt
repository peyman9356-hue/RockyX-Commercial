package com.rockyx.app.data.dog

import android.content.Context
import com.rockyx.app.domain.model.DogProfile
import com.rockyx.app.domain.repository.DogRepository
import org.json.JSONArray
import org.json.JSONObject

/** Local, versioned dog-profile persistence. Backend sync can replace this repository later. */
class DogStore(context: Context) : DogRepository {
    private val p = context.getSharedPreferences("rockyx_dog_v2", Context.MODE_PRIVATE)
    override fun current(): DogProfile {
        val raw = p.getString("dog", null) ?: return DogProfile("default", "Rocky", 24, "Beginner", emptyList())
        return try {
            fromJson(JSONObject(raw))
        } catch (t: Throwable) {
            throw com.rockyx.app.data.LocalDataCorruptionException("dog_profile", t)
        }
    }
    override fun save(profile: DogProfile) {
        p.edit().putString("dog", toJson(profile).toString()).apply()
    }
    private fun fromJson(j: JSONObject): DogProfile = DogProfile(
        id = j.optString("id", "default"), name = j.optString("name", "Rocky"),
        ageMonths = j.optInt("ageMonths", 24).coerceAtLeast(0), level = j.optString("level", "Beginner"),
        goals = strings(j.optJSONArray("goals")), behaviors = strings(j.optJSONArray("behaviors")),
        breed = j.optString("breed", ""), temperament = strings(j.optJSONArray("temperament")),
        profileVersion = j.optInt("profileVersion", 1),
        dateOfBirthEpochMs = if (j.has("dateOfBirthEpochMs") && !j.isNull("dateOfBirthEpochMs")) j.optLong("dateOfBirthEpochMs") else null,
        sex = j.optString("sex", "").takeIf { it.isNotBlank() },
        weightGrams = if (j.has("weightGrams") && !j.isNull("weightGrams")) j.optInt("weightGrams") else null,
        activityBaseline = if (j.has("activityBaseline") && !j.isNull("activityBaseline")) j.optInt("activityBaseline") else null,
        notes = strings(j.optJSONArray("notes"))
    )
    private fun toJson(pf: DogProfile) = JSONObject().apply {
        put("id", pf.id); put("name", pf.name); put("ageMonths", pf.ageMonths); put("level", pf.level)
        put("goals", JSONArray(pf.goals)); put("behaviors", JSONArray(pf.behaviors)); put("breed", pf.breed)
        put("temperament", JSONArray(pf.temperament)); put("profileVersion", pf.profileVersion)
        if (pf.dateOfBirthEpochMs != null) put("dateOfBirthEpochMs", pf.dateOfBirthEpochMs) else put("dateOfBirthEpochMs", JSONObject.NULL)
        if (pf.sex != null) put("sex", pf.sex) else put("sex", JSONObject.NULL)
        if (pf.weightGrams != null) put("weightGrams", pf.weightGrams) else put("weightGrams", JSONObject.NULL)
        if (pf.activityBaseline != null) put("activityBaseline", pf.activityBaseline) else put("activityBaseline", JSONObject.NULL)
        put("notes", JSONArray(pf.notes))
    }
    private fun strings(a: JSONArray?): List<String> = buildList { if (a != null) for (i in 0 until a.length()) add(a.optString(i)) }
}

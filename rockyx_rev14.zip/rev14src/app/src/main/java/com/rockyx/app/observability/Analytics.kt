package com.rockyx.app.observability

/** Product analytics boundary. Events are intentionally privacy-minimal and contain no raw user content. */
data class AnalyticsEvent(
    val name: String,
    val occurredAtEpochMs: Long,
    val properties: Map<String, String> = emptyMap()
)

interface AnalyticsRepository {
    fun record(event: AnalyticsEvent)
    fun pending(): List<AnalyticsEvent>
    fun clear()
}

class InMemoryAnalyticsRepository : AnalyticsRepository {
    private val events = mutableListOf<AnalyticsEvent>()
    override fun record(event: AnalyticsEvent) { synchronized(events) { events += event.copy(properties = redact(event.properties)) } }
    override fun pending(): List<AnalyticsEvent> = synchronized(events) { events.toList() }
    override fun clear() = synchronized(events) { events.clear() }

    private fun redact(properties: Map<String, String>) = properties.filterKeys {
        it.lowercase() !in setOf("email", "phone", "token", "authorization", "address", "raw_video", "payload")
    }
}

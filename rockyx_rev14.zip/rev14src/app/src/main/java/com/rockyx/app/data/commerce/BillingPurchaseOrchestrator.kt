package com.rockyx.app.data.commerce

import com.android.billingclient.api.Purchase
import com.rockyx.app.data.network.RockyXApiClient
import com.rockyx.app.domain.model.Access

interface PurchaseVerificationGateway {
    suspend fun verify(productId: String, purchaseToken: String): Result<VerifiedPurchase>
}

data class VerifiedPurchase(
    val productId: String,
    val tier: Access,
    val active: Boolean,
    val expiresAtEpochMs: Long?,
    val acknowledged: Boolean
)

class ApiPurchaseVerificationGateway(private val api: RockyXApiClient) : PurchaseVerificationGateway {
    override suspend fun verify(productId: String, purchaseToken: String): Result<VerifiedPurchase> = runCatching {
        val remote = api.verifyGooglePlayPurchase(productId, purchaseToken)
        VerifiedPurchase(remote.productId, remote.tier, remote.state == "ACTIVE", remote.expiresAtEpochMs, remote.acknowledged)
    }
}

class UnconfiguredPurchaseVerificationGateway : PurchaseVerificationGateway {
    override suspend fun verify(productId: String, purchaseToken: String): Result<VerifiedPurchase> =
        Result.failure(IllegalStateException("Billing backend verification is not configured"))
}

class BillingPurchaseOrchestrator(private val verifier: PurchaseVerificationGateway) {
    suspend fun process(purchase: Purchase): Result<VerifiedPurchase> {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) {
            return Result.failure(IllegalStateException("Purchase is not completed"))
        }
        val productId = purchase.products.singleOrNull()
            ?: return Result.failure(IllegalArgumentException("A subscription purchase must contain exactly one product"))
        if (purchase.purchaseToken.length !in 20..4096) {
            return Result.failure(IllegalArgumentException("Invalid purchase token"))
        }
        return verifier.verify(productId, purchase.purchaseToken)
    }
}

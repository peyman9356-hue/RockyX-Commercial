package com.rockyx.app.data.account

interface AuthTokenProvider {
    suspend fun currentAccessToken(): String?
    suspend fun refreshAccessToken(): String? = null
}

class UnconfiguredAuthTokenProvider : AuthTokenProvider {
    override suspend fun currentAccessToken(): String? = null
}


/** Token provider backed by the Keystore-protected session store. */
class SessionStoreAuthTokenProvider(private val store: SecureSessionTokenStore) : AuthTokenProvider {
    @Volatile var refreshHandler: (suspend () -> String?)? = null
    override suspend fun currentAccessToken(): String? = store.accessToken()?.takeIf { (store.expiresAt() ?: 0L) > System.currentTimeMillis() + 30_000 }
    override suspend fun refreshAccessToken(): String? = refreshHandler?.invoke()
}

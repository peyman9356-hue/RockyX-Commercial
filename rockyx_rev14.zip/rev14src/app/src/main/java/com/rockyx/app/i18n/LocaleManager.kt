package com.rockyx.app.i18n

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Central per-app locale preference. Provider-neutral and safe to expand with more locales. */
object LocaleManager {
    private const val PREFS = "rockyx_locale"
    private const val KEY_LANGUAGE = "language"
    const val SYSTEM = "system"
    const val ENGLISH = "en"
    const val PERSIAN = "fa"

    fun getLanguage(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, SYSTEM) ?: SYSTEM

    fun setLanguage(context: Context, language: String) {
        require(language == SYSTEM || language == ENGLISH || language == PERSIAN)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, language).apply()
    }

    fun wrap(context: Context): Context {
        val language = getLanguage(context)
        if (language == SYSTEM) return context
        val locale = Locale.forLanguageTag(language)
        Locale.setDefault(locale)
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(locale)
        configuration.setLayoutDirection(locale)
        return context.createConfigurationContext(configuration)
    }
}

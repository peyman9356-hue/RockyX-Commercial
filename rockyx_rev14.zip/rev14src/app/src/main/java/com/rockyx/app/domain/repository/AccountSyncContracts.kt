package com.rockyx.app.domain.repository

import com.rockyx.app.domain.account.AccountSession
import com.rockyx.app.domain.sync.SyncOperation
import com.rockyx.app.domain.sync.SyncSnapshot

interface AccountRepository {
    fun session(): AccountSession
    fun saveSession(session: AccountSession)
    fun clearSession()
}

interface SyncRepository {
    fun snapshot(): SyncSnapshot
    fun enqueue(operation: SyncOperation)
    fun pending(limit: Int = 50): List<SyncOperation>
    fun markSucceeded(operationId: String)
    fun markFailed(operationId: String, error: String)
}

interface AuthProvider {
    fun signIn(): Result<AccountSession>
    fun signOut(): Result<Unit>
    fun refresh(): Result<AccountSession>
}

interface SyncTransport {
    fun push(operations: List<SyncOperation>): Result<Unit>
}

package com.rockyx.app.data.content

import android.content.Context
import com.rockyx.app.domain.model.Course

/** Compatibility entry point. Content now lives in versioned assets, not UI/core code. */
object Catalog {
    fun courses(context: Context): List<Course> = AssetContentRepository(context).courses()
}

class LocalContentRepository(context: Context) : com.rockyx.app.domain.repository.ContentRepository by AssetContentRepository(context)

package com.rockyx.app.ui.shell

/**
 * In-process session registry for the first shell migration.
 *
 * It deliberately does not replace ProgressStore or MediaProgressStore. Those
 * remain the durable sources of truth. This registry only remembers which
 * content surface was active and lightweight UI anchors while navigating.
 */
class SessionStore {
    private val sessions = linkedMapOf<String, SessionSnapshot>()
    private var activeKey: String? = null

    fun activate(snapshot: SessionSnapshot): SessionSnapshot {
        sessions[snapshot.key()] = snapshot
        activeKey = snapshot.key()
        return snapshot
    }

    fun active(): SessionSnapshot? = activeKey?.let(sessions::get)

    fun get(destination: AppDestination): SessionSnapshot? = sessions[destination.key()]

    fun update(destination: AppDestination, scrollAnchor: String? = null, mediaPositionMs: Long? = null): SessionSnapshot {
        val current = sessions[destination.key()] ?: SessionSnapshot(destination)
        return activate(current.copy(
            scrollAnchor = scrollAnchor ?: current.scrollAnchor,
            mediaPositionMs = mediaPositionMs ?: current.mediaPositionMs
        ))
    }

    fun clear(destination: AppDestination) {
        sessions.remove(destination.key())
        if (activeKey == destination.key()) activeKey = null
    }

    private fun SessionSnapshot.key(): String = destination.key()
}

fun AppDestination.key(): String = when (this) {
    AppDestination.Home -> "home"
    AppDestination.Library -> "library"
    AppDestination.Settings -> "settings"
    AppDestination.Progress -> "progress"
    AppDestination.Dog -> "dog"
    AppDestination.Commerce -> "commerce"
    AppDestination.Account -> "account"
    is AppDestination.Course -> "course:$courseId"
    is AppDestination.Lesson -> "lesson:$courseId:$lessonId"
}

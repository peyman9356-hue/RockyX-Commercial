package com.rockyx.app.data.connectivity

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.rockyx.app.domain.connectivity.*

class AndroidConnectivityRepository(context: Context) : ConnectivityRepository {
    private val appContext = context.applicationContext
    override fun snapshot(): ConnectivitySnapshot {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return ConnectivitySnapshot(ConnectivityState.OFFLINE)
        val caps = cm.getNetworkCapabilities(network) ?: return ConnectivitySnapshot(ConnectivityState.OFFLINE)
        val usable = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return ConnectivitySnapshot(if (usable) ConnectivityState.ONLINE else ConnectivityState.OFFLINE)
    }
}

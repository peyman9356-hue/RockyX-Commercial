package com.rockyx.app.observability

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent, offline-first analytics buffer. It stores only redacted product events. */
class LocalAnalyticsStore(context: Context) : AnalyticsRepository {
    private val prefs = context.getSharedPreferences("rockyx_analytics_v1", Context.MODE_PRIVATE)
    private val key = "pending_events"

    override fun record(event: AnalyticsEvent) {
        val safe = event.copy(properties = redact(event.properties))
        val array = JSONArray(prefs.getString(key, "[]"))
        array.put(JSONObject().apply {
            put("name", safe.name)
            put("occurredAtEpochMs", safe.occurredAtEpochMs)
            put("properties", JSONObject(safe.properties))
        })
        // Bound the local queue to protect storage on prolonged outages.
        while (array.length() > 500) array.remove(0)
        prefs.edit().putString(key, array.toString()).apply()
    }

    override fun pending(): List<AnalyticsEvent> {
        val array = JSONArray(prefs.getString(key, "[]"))
        return buildList(array.length()) {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val props = item.optJSONObject("properties") ?: JSONObject()
                val map = mutableMapOf<String, String>()
                props.keys().forEach { k -> map[k] = props.optString(k) }
                add(AnalyticsEvent(item.optString("name"), item.optLong("occurredAtEpochMs"), map))
            }
        }
    }

    override fun clear() = prefs.edit().remove(key).apply()

    private fun redact(properties: Map<String, String>) = properties.filterKeys {
        it.lowercase() !in setOf("email", "phone", "token", "authorization", "address", "raw_video", "payload")
    }
}

package com.rockyx.app.media

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes

/** Server-issued, short-lived playback authorization. No long-lived storage URL is persisted. */
data class PlaybackGrant(
    val mediaId: String,
    val uri: String,
    val expiresAtEpochMs: Long,
    val issuedAtEpochMs: Long,
    val contentType: ContentDeliveryType
) {
    fun isUsable(nowEpochMs: Long = System.currentTimeMillis()): Boolean = expiresAtEpochMs > nowEpochMs
}

enum class ContentDeliveryType { HLS, PROGRESSIVE_MP4, OFFLINE }

interface PlaybackGrantProvider {
    fun grant(mediaId: String): Result<PlaybackGrant>
}

/**
 * Converts a server-authorized grant into a Media3 item.
 * HLS is preferred for streaming because the server can provide multiple renditions.
 */
object MediaItemFactory {
    fun fromGrant(grant: PlaybackGrant): MediaItem {
        require(grant.isUsable()) { "Playback grant expired" }
        val builder = MediaItem.Builder()
            .setMediaId(grant.mediaId)
            .setUri(Uri.parse(grant.uri))
        if (grant.contentType == ContentDeliveryType.HLS) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        return builder.build()
    }
}

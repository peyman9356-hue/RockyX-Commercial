package com.rockyx.app.domain.repository

import com.rockyx.app.domain.model.*

interface DogEcosystemRepository {
    fun listDogs(): List<DogProfile>
    fun recordEvent(event: DogEventRecord)
    fun listEvents(dogId: String, limit: Int = 100): List<DogEventRecord>
}

interface DeviceRepository {
    fun listDevices(dogId: String? = null): List<DeviceIdentity>
}

interface SafetyRepository {
    fun record(event: SafetyEventRecord)
    fun list(dogId: String, limit: Int = 100): List<SafetyEventRecord>
}

interface AiInsightRepository {
    fun list(dogId: String, limit: Int = 50): List<AiInsightRecord>
}

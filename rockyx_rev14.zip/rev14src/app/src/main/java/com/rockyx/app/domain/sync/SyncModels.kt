package com.rockyx.app.domain.sync

enum class SyncState { IDLE, QUEUED, SYNCING, SUCCEEDED, FAILED, BLOCKED_AUTH }

enum class SyncOperationType { UPSERT_DOG, UPSERT_PROGRESS, UPSERT_CONSENT, UPSERT_SUBMISSION, DELETE_SUBMISSION }

data class SyncOperation(
    val id: String,
    val type: SyncOperationType,
    val entityId: String,
    val payloadVersion: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val attemptCount: Int = 0,
    val lastError: String? = null
)

data class SyncSnapshot(
    val state: SyncState = SyncState.IDLE,
    val lastSuccessfulSyncAt: Long? = null,
    val pendingCount: Int = 0,
    val schemaVersion: Int = 1
)

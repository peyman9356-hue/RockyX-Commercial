package com.rockyx.app.reliability

/** Pure, dependency-free guards used by QA and recovery code. */
object QualityGate {
    fun safeErrorCode(value: String?): String = value.orEmpty()
        .takeWhile { it.isLetterOrDigit() || it == '_' || it == '-' }
        .take(64)
        .ifBlank { "UNKNOWN_ERROR" }

    fun validAttemptCount(value: Int): Int = value.coerceIn(0, 5)

    fun isSafeTelemetryTag(key: String): Boolean = key.lowercase() !in setOf(
        "email", "phone", "name", "token", "authorization", "payload", "address", "raw_video", "ip"
    )
}

package com.rockyx.app.data.account

import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import java.security.SecureRandom
import android.util.Base64

/** Real Google identity adapter. It returns only a Google OIDC ID token; account creation remains server-authoritative. */
class GoogleCredentialManagerIdentityProvider(
    context: Context,
    private val webClientId: String
) {
    private val credentialManager = CredentialManager.create(context)

    suspend fun signIn(activity: Activity): Result<String> = runCatching {
        require(webClientId.isNotBlank()) { "Google Web Client ID is not configured" }
        val nonceBytes = ByteArray(32).also(SecureRandom()::nextBytes)
        val nonce = Base64.encodeToString(nonceBytes, Base64.NO_WRAP or Base64.URL_SAFE)
        val option = GetGoogleIdOption.Builder()
            .setServerClientId(webClientId)
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .setNonce(nonce)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = credentialManager.getCredential(activity, request)
        val credential = GoogleIdTokenCredential.createFrom(result.credential.data)
        credential.idToken
    }
}

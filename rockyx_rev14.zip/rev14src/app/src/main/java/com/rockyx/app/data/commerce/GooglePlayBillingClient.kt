package com.rockyx.app.data.commerce

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

/**
 * Thin Google Play Billing 9.1.0 adapter. It never grants entitlement locally.
 * The purchase token is handed to the authenticated Rocky X backend for verification.
 */
class GooglePlayBillingClient(
    context: Context,
    private val onPurchases: (List<Purchase>) -> Unit = {},
    private val onError: (BillingResult) -> Unit = {}
) : BillingClientStateListener, PurchasesUpdatedListener {
    private val client = BillingClient.newBuilder(context.applicationContext)
        .setListener(this)
        .enableAutoServiceReconnection()
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().enablePrepaidPlans().build())
        .build()

    fun connect() {
        if (!client.isReady) client.startConnection(this)
        else queryActiveSubscriptions()
    }

    fun disconnect() { client.endConnection() }

    fun queryProducts(productIds: List<String>, callback: (List<ProductDetails>) -> Unit) {
        if (!client.isReady) { onError(BillingResult.newBuilder().setResponseCode(BillingClient.BillingResponseCode.SERVICE_DISCONNECTED).build()); return }
        val products = productIds.distinct().map { id -> QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(BillingClient.ProductType.SUBS).build() }
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(products).build()) { result, details ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) callback(details.productDetailsList) else onError(result)
        }
    }

    fun purchase(activity: Activity, details: ProductDetails, offerToken: String) {
        require(offerToken.isNotBlank()) { "A subscription offer token is required" }
        val product = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).setOfferToken(offerToken).build()
        val result = client.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(product)).build())
        if (result.responseCode != BillingClient.BillingResponseCode.OK) onError(result)
    }

    fun queryActiveSubscriptions() {
        if (!client.isReady) return
        val params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).includeSuspendedSubscriptions(true).build()
        client.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) onPurchases(purchases) else onError(result)
        }
    }

    override fun onBillingSetupFinished(result: BillingResult) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK) queryActiveSubscriptions() else onError(result)
    }

    override fun onBillingServiceDisconnected() {
        onError(BillingResult.newBuilder().setResponseCode(BillingClient.BillingResponseCode.SERVICE_DISCONNECTED).build())
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) onPurchases(purchases)
        else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) onError(result)
    }
}

package com.rockyx.app.ui.shell

/** Lightweight UI session state; domain state remains owned by existing stores/use cases. */
data class SessionSnapshot(
    val destination: AppDestination,
    val scrollAnchor: String? = null,
    val mediaPositionMs: Long? = null
)

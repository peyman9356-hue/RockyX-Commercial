package com.rockyx.app.background

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.rockyx.app.domain.model.SubmissionStatus
import com.rockyx.app.reliability.FailureCategory
import com.rockyx.app.reliability.FailureEvent
import com.rockyx.app.ui.AppController

class SubmissionDrainWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val app = AppController(applicationContext)
        if (!app.auth.isSignedIn()) {
            app.reliability.recordFailure(FailureEvent("AUTH_REQUIRED", FailureCategory.AUTH, retryable = false, System.currentTimeMillis(), runAttemptCount))
            return Result.failure()
        }
        val pending = app.submissions.all().filter { it.status == SubmissionStatus.QUEUED }
        if (pending.isEmpty()) return Result.success()
        // No configured remote gateway: never claim success. Bound retries to avoid a retry storm.
        app.reliability.recordFailure(FailureEvent("SUBMISSION_UPLOAD_UNAVAILABLE", FailureCategory.SUBMISSION, retryable = runAttemptCount < 5, System.currentTimeMillis(), runAttemptCount))
        return if (runAttemptCount < 5) Result.retry() else Result.failure()
    }
}

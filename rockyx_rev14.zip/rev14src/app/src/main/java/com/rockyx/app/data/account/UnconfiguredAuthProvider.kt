package com.rockyx.app.data.account

import com.rockyx.app.domain.account.AccountSession
import com.rockyx.app.domain.repository.AuthProvider

/** Fail-closed until a real identity provider is configured. */
class UnconfiguredAuthProvider : AuthProvider {
    override fun signIn(): Result<AccountSession> = Result.failure(IllegalStateException("Authentication provider is not configured"))
    override fun signOut(): Result<Unit> = Result.success(Unit)
    override fun refresh(): Result<AccountSession> = Result.failure(IllegalStateException("Authentication provider is not configured"))
}

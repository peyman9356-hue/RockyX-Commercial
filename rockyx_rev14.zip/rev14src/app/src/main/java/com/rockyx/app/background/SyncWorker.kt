package com.rockyx.app.background

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.rockyx.app.reliability.FailureCategory
import com.rockyx.app.reliability.FailureEvent
import com.rockyx.app.ui.AppController

class SyncWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val app = AppController(applicationContext)
        val result = app.resilientSync()
        if (result.isSuccess) return Result.success()
        val attempt = runAttemptCount
        app.reliability.recordFailure(FailureEvent("SYNC_FAILED", FailureCategory.SYNC, retryable = attempt < 5, System.currentTimeMillis(), attempt))
        return if (attempt < 5) Result.retry() else Result.failure()
    }
}

package com.rockyx.app.platform

interface ApiPort
interface AuthPort
interface AnalyticsPort { fun event(name: String, properties: Map<String, String> = emptyMap()) }
interface SupportPort { fun openHelp() }

package com.rockyx.app.data.account

import android.content.Context
import com.rockyx.app.domain.account.AccountSession
import com.rockyx.app.domain.account.AccountState
import com.rockyx.app.domain.repository.AccountRepository
import org.json.JSONObject

/**
 * Local session state only. It deliberately cannot create a durable user identity.
 * A real provider must establish the user ID and authenticated session.
 */
class LocalAccountStore(context: Context) : AccountRepository {
    private val prefs = context.getSharedPreferences("rockyx_account_v1", Context.MODE_PRIVATE)

    override fun session(): AccountSession {
        val raw = prefs.getString("session", null) ?: return AccountSession()
        return try {
            fromJson(JSONObject(raw))
        } catch (t: Throwable) {
            prefs.edit().putString("session.corrupt.${System.currentTimeMillis()}", raw).remove("session").apply()
            throw com.rockyx.app.data.LocalDataCorruptionException("account_session", t)
        }
    }

    override fun saveSession(session: AccountSession) {
        prefs.edit().putString("session", toJson(session).toString()).apply()
    }

    override fun clearSession() {
        prefs.edit().remove("session").apply()
    }

    private fun fromJson(j: JSONObject) = AccountSession(
        state = AccountState.valueOf(j.optString("state", "SIGNED_OUT")),
        userId = j.optString("userId", "").ifBlank { null },
        issuedAt = if (j.has("issuedAt") && !j.isNull("issuedAt")) j.optLong("issuedAt") else null,
        expiresAt = if (j.has("expiresAt") && !j.isNull("expiresAt")) j.optLong("expiresAt") else null,
        provider = j.optString("provider", "").ifBlank { null },
        schemaVersion = j.optInt("schemaVersion", 1)
    )

    private fun toJson(s: AccountSession) = JSONObject().apply {
        put("state", s.state.name)
        put("userId", s.userId)
        put("issuedAt", s.issuedAt)
        put("expiresAt", s.expiresAt)
        put("provider", s.provider)
        put("schemaVersion", s.schemaVersion)
    }
}

package com.rockyx.app.data.commerce

import android.content.Context
import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.EntitlementRepository
import org.json.JSONArray
import org.json.JSONObject

/** Data-driven commerce catalog. Prices are configuration, not application logic. */
object ProductCatalog {
    fun plans(context: Context, region: String = "GLOBAL", currency: String? = null): List<PricingPlan> {
        val raw = context.assets.open("commerce/catalog_v1.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        val result = mutableListOf<PricingPlan>()
        val array = root.getJSONArray("plans")
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            val planRegion = o.optString("region", "GLOBAL")
            val planCurrency = o.optString("currency", "USD")
            if (!o.optBoolean("active", true)) continue
            if (planRegion != "GLOBAL" && !planRegion.equals(region, true)) continue
            if (currency != null && !planCurrency.equals(currency, true)) continue
            result += PricingPlan(
                id = o.getString("id"), productId = o.getString("productId"),
                displayName = o.getString("displayName"), tier = Access.valueOf(o.getString("tier")),
                billingPeriod = o.getString("billingPeriod"), currency = planCurrency,
                amountMinor = o.getLong("amountMinor"), region = planRegion,
                trialDays = o.optInt("trialDays", 0), discountPercent = o.optInt("discountPercent", 0),
                offerId = o.optString("offerId").ifBlank { null }, active = true
            )
        }
        return result.sortedWith(compareBy<PricingPlan> { it.tier.ordinal }.thenBy { it.amountMinor })
    }
}

class EntitlementStore(context: Context) : EntitlementRepository {
    private val p = context.getSharedPreferences("rockyx_entitlements_v2", Context.MODE_PRIVATE)

    override fun active(productId: String): Boolean = get(productId)?.isActive() == true

    override fun activeTier(tier: Access): Boolean = p.all.keys
        .filter { it.startsWith("entitlement_") }
        .mapNotNull { key -> get(key.removePrefix("entitlement_")) }
        .any { it.tier == tier && it.isActive() }

    override fun get(productId: String): Entitlement? {
        val raw = p.getString("entitlement_$productId", null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            Entitlement(
                productId = o.getString("productId"),
                tier = Access.valueOf(o.getString("tier")),
                state = EntitlementState.valueOf(o.getString("state")),
                startsAt = if (o.has("startsAt") && !o.isNull("startsAt")) o.getLong("startsAt") else null,
                expiresAt = if (o.has("expiresAt") && !o.isNull("expiresAt")) o.getLong("expiresAt") else null,
                source = o.optString("source", "local")
            )
        }.getOrNull()
    }

    /** Atomically replaces local paid-access snapshot after a successful authenticated server read. */
    fun replaceFromServer(values: List<Entitlement>) {
        val editor = p.edit()
        p.all.keys.filter { it.startsWith("entitlement_") }.forEach(editor::remove)
        values.forEach { entitlement ->
            val o = JSONObject().apply {
                put("productId", entitlement.productId)
                put("tier", entitlement.tier.name)
                put("state", entitlement.state.name)
                if (entitlement.startsAt == null) put("startsAt", JSONObject.NULL) else put("startsAt", entitlement.startsAt)
                if (entitlement.expiresAt == null) put("expiresAt", JSONObject.NULL) else put("expiresAt", entitlement.expiresAt)
                put("source", entitlement.source)
            }
            editor.putString("entitlement_${entitlement.productId}", o.toString())
        }
        check(editor.commit()) { "Failed to persist entitlement snapshot" }
    }

    override fun save(entitlement: Entitlement) {
        val o = JSONObject().apply {
            put("productId", entitlement.productId)
            put("tier", entitlement.tier.name)
            put("state", entitlement.state.name)
            if (entitlement.startsAt == null) put("startsAt", JSONObject.NULL) else put("startsAt", entitlement.startsAt)
            if (entitlement.expiresAt == null) put("expiresAt", JSONObject.NULL) else put("expiresAt", entitlement.expiresAt)
            put("source", entitlement.source)
        }
        p.edit().putString("entitlement_${entitlement.productId}", o.toString()).apply()
    }
}

package com.rockyx.app.data.account

import com.rockyx.app.data.network.RockyXApiClient
import com.rockyx.app.data.network.AuthTokenResponse
import com.rockyx.app.domain.account.AccountSession
import com.rockyx.app.domain.account.AccountState
import com.rockyx.app.domain.repository.AccountRepository
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Provider-neutral session lifecycle. Credential Manager/Google/Apple/passkey adapters supply the external ID token. */
class SessionAuthCoordinator(
    private val api: RockyXApiClient,
    private val tokens: SecureSessionTokenStore,
    private val accounts: AccountRepository
) : AuthTokenProvider {
    private val refreshMutex = Mutex()
    suspend fun signIn(provider: String, externalIdToken: String): Result<AccountSession> = runCatching {
        val response = api.exchangeIdentity(provider, externalIdToken)
        persist(response, provider)
    }

    suspend fun refresh(): Result<AccountSession> = refreshMutex.withLock { runCatching {
        val refresh = tokens.refreshToken() ?: error("No refresh token")
        val response = api.refreshSession(refresh)
        persist(response, accounts.session().provider ?: "oidc")
    } }

    suspend fun signOut() {
        val refresh = tokens.refreshToken()
        runCatching { if (refresh != null) api.logoutSession(refresh) }
        tokens.clear(); accounts.clearSession()
    }

    override suspend fun currentAccessToken(): String? = tokens.accessToken()?.takeIf { (tokens.expiresAt() ?: 0L) > System.currentTimeMillis() + 30_000 }
    override suspend fun refreshAccessToken(): String? = refresh().getOrNull()?.let { tokens.accessToken() }

    private fun persist(r: AuthTokenResponse, provider: String): AccountSession {
        tokens.save(r.accessToken, r.refreshToken, r.expiresAtEpochMs, r.userId, provider)
        val session=AccountSession(AccountState.SIGNED_IN, r.userId, System.currentTimeMillis(), r.expiresAtEpochMs, provider, 2)
        accounts.saveSession(session); return session
    }
}

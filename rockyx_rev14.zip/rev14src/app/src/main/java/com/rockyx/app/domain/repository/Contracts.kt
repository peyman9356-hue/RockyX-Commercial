package com.rockyx.app.domain.repository

import com.rockyx.app.domain.model.*

interface ContentRepository { fun courses(): List<Course>; fun course(id: String): Course? }
interface ProgressRepository {
    fun snapshot(): ProgressSnapshot
    fun markExercise(lessonId: String, exerciseId: String, completed: Boolean)
    fun recordQuizAttempt(lessonId: String, attempt: QuizAttempt)
    fun updateMission(lessonId: String, missionId: String, result: MissionResult)
    fun setLessonProgress(progress: LessonProgress)
    fun migrateIfNeeded()
}
interface DogRepository { fun current(): DogProfile; fun save(profile: DogProfile) }
interface EntitlementRepository {
    fun active(productId: String): Boolean
    fun activeTier(tier: Access): Boolean
    fun get(productId: String): Entitlement?
    fun save(entitlement: Entitlement)
}
interface ConsentRepository { fun get(userId: String, scope: String): Consent?; fun save(consent: Consent) }
interface SubmissionRepository {
    fun all(): List<Submission>
    fun forMission(missionId: String): List<Submission>
    fun get(id: String): Submission?
    fun save(submission: Submission)
    fun delete(id: String)
}
interface SubmissionUploadGateway {
    fun available(): Boolean
    fun enqueue(submission: Submission): Result<SubmissionUploadReceipt>
    fun cancel(uploadId: String): Result<Unit>
    fun deleteRemote(remoteId: String): Result<Unit>
}

data class SubmissionUploadReceipt(
    val remoteId: String,
    val uploadId: String,
    val state: RemoteSubmissionState
)

interface BillingGateway { fun available(): Boolean; fun purchase(productId: String): Result<Unit> }
interface AnalyticsPort { fun event(name: String, properties: Map<String, String> = emptyMap()) }
interface ApiPort
interface AuthPort {
    fun isSignedIn(): Boolean
    fun currentUserId(): String?
}
interface SupportPort { fun openHelp() }

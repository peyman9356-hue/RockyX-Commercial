package com.rockyx.app.domain.account

enum class AccountState { SIGNED_OUT, SIGNED_IN, SESSION_EXPIRED }

data class AccountSession(
    val state: AccountState = AccountState.SIGNED_OUT,
    val userId: String? = null,
    val issuedAt: Long? = null,
    val expiresAt: Long? = null,
    val provider: String? = null,
    val schemaVersion: Int = 1
) {
    fun isAuthenticated(now: Long = System.currentTimeMillis()): Boolean =
        state == AccountState.SIGNED_IN &&
            !userId.isNullOrBlank() &&
            (expiresAt == null || expiresAt > now)
}

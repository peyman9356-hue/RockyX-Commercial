package com.rockyx.app.domain.sync

import kotlin.math.min

object SyncBackoff {
    private const val BASE_MS = 15_000L
    private const val MAX_MS = 6L * 60L * 60L * 1000L

    fun delayMs(attemptCount: Int): Long {
        val safeAttempt = attemptCount.coerceIn(0, 20)
        val exponential = BASE_MS * (1L shl safeAttempt.coerceAtMost(8))
        return min(exponential, MAX_MS)
    }

    fun eligible(operation: SyncOperation, now: Long = System.currentTimeMillis()): Boolean =
        now - operation.createdAt >= delayMs(operation.attemptCount)
}

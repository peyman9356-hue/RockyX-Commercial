package com.rockyx.app.data

/** Raised when persisted local JSON cannot be trusted. Callers must surface recovery rather than silently reset state. */
class LocalDataCorruptionException(
    val storeName: String,
    cause: Throwable
) : IllegalStateException("Corrupted local data in $storeName; data was quarantined and must not be silently reset", cause)

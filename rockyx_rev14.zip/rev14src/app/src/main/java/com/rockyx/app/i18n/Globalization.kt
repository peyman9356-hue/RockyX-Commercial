package com.rockyx.app.i18n

import android.content.Context
import java.text.NumberFormat
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.Currency

/** Locale-aware formatting kept outside business logic. */
object Globalization {
    fun locale(context: Context): Locale = context.resources.configuration.locales[0]

    fun number(context: Context, value: Number): String =
        NumberFormat.getNumberInstance(locale(context)).format(value)

    fun currency(context: Context, amountMinor: Long, currencyCode: String): String {
        val formatter = NumberFormat.getCurrencyInstance(locale(context))
        formatter.currency = Currency.getInstance(currencyCode)
        return formatter.format(amountMinor / 100.0)
    }

    fun dateTime(context: Context, epochMillis: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale(context)).format(Date(epochMillis))

    fun languageTag(context: Context): String = locale(context).toLanguageTag()
}

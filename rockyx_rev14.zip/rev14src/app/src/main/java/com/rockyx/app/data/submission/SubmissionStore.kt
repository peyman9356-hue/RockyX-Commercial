package com.rockyx.app.data.submission

import android.content.Context
import com.rockyx.app.data.LocalDataCorruptionException
import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.SubmissionRepository
import org.json.JSONArray
import org.json.JSONObject

class SubmissionStore(context: Context) : SubmissionRepository {
    private val prefs = context.getSharedPreferences("rockyx_submissions_v1", Context.MODE_PRIVATE)
    private val key = "items"

    override fun all(): List<Submission> = read().sortedByDescending { it.updatedAt }
    override fun forMission(missionId: String): List<Submission> = all().filter { it.missionId == missionId }
    override fun get(id: String): Submission? = all().firstOrNull { it.id == id }
    override fun save(submission: Submission) {
        val items = all().filterNot { it.id == submission.id } + submission
        prefs.edit().putString(key, JSONArray(items.map { encode(it).toString() }).toString()).apply()
    }
    override fun delete(id: String) {
        val items = all().filterNot { it.id == id }
        prefs.edit().putString(key, JSONArray(items.map { encode(it).toString() }).toString()).apply()
    }
    private fun read(): List<Submission> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            buildList { for (i in 0 until a.length()) add(decode(JSONObject(a.getString(i)))) }
        } catch (t: Throwable) {
            quarantineCorruptRaw(raw)
            throw LocalDataCorruptionException("submissions", t)
        }
    }

    private fun quarantineCorruptRaw(raw: String) {
        val quarantineKey = "${key}.corrupt.${System.currentTimeMillis()}"
        prefs.edit().putString(quarantineKey, raw).remove(key).apply()
    }

    private fun encode(s: Submission) = JSONObject().apply {
        put("id", s.id); put("missionId", s.missionId); put("localUri", s.localUri)
        put("status", s.status.name); put("visibility", s.visibility.name)
        put("createdAt", s.createdAt); put("updatedAt", s.updatedAt)
        s.uploadId?.let { put("uploadId", it) }; s.remoteId?.let { put("remoteId", it) }; put("remoteState", s.remoteState.name); s.failureReason?.let { put("failureReason", it) }
        s.processingConsent?.let { put("processingConsent", consent(it)) }
        s.publicSharingConsent?.let { put("publicSharingConsent", consent(it)) }
    }
    private fun consent(c: Consent) = JSONObject().apply { put("userId", c.userId); put("scope", c.scope); put("granted", c.granted); c.timestamp?.let { put("timestamp", it) } }
    private fun decode(o: JSONObject): Submission {
        fun readConsent(k: String): Consent? = o.optJSONObject(k)?.let { c -> Consent(c.getString("userId"), c.getString("scope"), c.getBoolean("granted"), c.optLong("timestamp").takeIf { it > 0 }) }
        return Submission(
            id = o.getString("id"), missionId = o.getString("missionId"), localUri = o.getString("localUri"),
            status = SubmissionStatus.valueOf(o.optString("status", SubmissionStatus.DRAFT.name)),
            visibility = SubmissionVisibility.valueOf(o.optString("visibility", SubmissionVisibility.PRIVATE.name)),
            processingConsent = readConsent("processingConsent"), publicSharingConsent = readConsent("publicSharingConsent"),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()), updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
            uploadId = o.optString("uploadId").takeIf { it.isNotBlank() }, remoteId = o.optString("remoteId").takeIf { it.isNotBlank() }, remoteState = RemoteSubmissionState.valueOf(o.optString("remoteState", RemoteSubmissionState.NOT_CREATED.name)), failureReason = o.optString("failureReason").takeIf { it.isNotBlank() }
        )
    }
}

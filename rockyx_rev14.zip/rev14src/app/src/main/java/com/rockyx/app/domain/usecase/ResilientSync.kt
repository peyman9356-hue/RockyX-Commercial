package com.rockyx.app.domain.usecase

import com.rockyx.app.domain.connectivity.ConnectivityRepository
import com.rockyx.app.domain.repository.AccountRepository
import com.rockyx.app.domain.repository.SyncRepository
import com.rockyx.app.domain.repository.SyncTransport
import com.rockyx.app.domain.sync.*

class ResilientSync(
    private val accounts: AccountRepository,
    private val connectivity: ConnectivityRepository,
    private val sync: SyncRepository,
    private val transport: SyncTransport
) {
    operator fun invoke(now: Long = System.currentTimeMillis()): Result<SyncSnapshot> {
        if (!connectivity.snapshot().isOnline) return Result.success(sync.snapshot().copy(state = SyncState.QUEUED))
        if (!accounts.session().isAuthenticated()) return Result.success(sync.snapshot().copy(state = SyncState.BLOCKED_AUTH))
        val batch = sync.pending(50).filter { SyncBackoff.eligible(it, now) }
        if (batch.isEmpty()) return Result.success(sync.snapshot())
        return transport.push(batch).map {
            batch.forEach { sync.markSucceeded(it.id) }
            sync.snapshot().copy(state = SyncState.SUCCEEDED)
        }.onFailure { error -> batch.forEach { sync.markFailed(it.id, error.message ?: "sync failed") } }
    }
}

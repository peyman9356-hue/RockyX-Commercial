package com.rockyx.app.background

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object RockyXBackgroundWork {
    private const val PERIODIC_SYNC = "rockyx_periodic_sync_v1"
    private const val SYNC_NOW = "rockyx_sync_now_v1"
    private const val SUBMISSION_DRAIN = "rockyx_submission_drain_v1"

    private val networkConstraint = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun schedule(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConstraint)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("sync")
            .build()
        wm.enqueueUniquePeriodicWork(PERIODIC_SYNC, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    fun syncNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(networkConstraint)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("sync")
            .build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(SYNC_NOW, ExistingWorkPolicy.KEEP, request)
    }

    fun drainSubmissions(context: Context) {
        val request = OneTimeWorkRequestBuilder<SubmissionDrainWorker>()
            .setConstraints(networkConstraint)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("submission")
            .build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(SUBMISSION_DRAIN, ExistingWorkPolicy.KEEP, request)
    }
}

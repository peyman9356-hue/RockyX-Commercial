package com.rockyx.app.domain.connectivity

interface ConnectivityRepository {
    fun snapshot(): ConnectivitySnapshot
}

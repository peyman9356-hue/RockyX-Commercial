package com.rockyx.app.domain.usecase

import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.*
import java.util.UUID

class GetLearningCatalog(private val content: ContentRepository) { operator fun invoke() = content.courses() }
class GetCourse(private val content: ContentRepository) { operator fun invoke(id: String) = content.course(id) }

class GetLessonState(
    private val content: ContentRepository,
    private val progress: ProgressRepository,
    private val access: (Access) -> Boolean = { it == Access.FREE }
) {
    operator fun invoke(courseId: String, lessonId: String): LessonStateView {
        val course = content.course(courseId) ?: return LessonStateView(lessonId, LearningState.LOCKED, null, "دوره پیدا نشد")
        val lesson = course.chapters.flatMap { it.lessons }.firstOrNull { it.id == lessonId }
            ?: return LessonStateView(lessonId, LearningState.LOCKED, null, "درس پیدا نشد")
        if (!access(lesson.access)) return LessonStateView(lessonId, LearningState.LOCKED, null, "دسترسی PRO لازم است")
        val snapshot = progress.snapshot()
        val p = snapshot.lessons[lessonId]
        val prerequisitesMet = lesson.prerequisiteLessonIds.all { snapshot.lessons[it]?.state == LearningState.COMPLETED || snapshot.lessons[it]?.state == LearningState.MASTERED }
        if (!prerequisitesMet) return LessonStateView(lessonId, LearningState.LOCKED, p?.score, "پیش‌نیازهای درس کامل نشده‌اند")
        return LessonStateView(lessonId, p?.state ?: LearningState.AVAILABLE, p?.score)
    }
}

class StartLesson(private val progress: ProgressRepository) {
    operator fun invoke(lesson: Lesson): LessonProgress {
        val current = progress.snapshot().lessons[lesson.id] ?: LessonProgress(lesson.id)
        if (current.state == LearningState.AVAILABLE) {
            val updated = current.copy(state = LearningState.IN_PROGRESS)
            progress.setLessonProgress(updated)
            return updated
        }
        return current
    }
}

class CompleteExercise(private val content: ContentRepository, private val progress: ProgressRepository) {
    operator fun invoke(courseId: String, lessonId: String, exerciseId: String, completed: Boolean = true) {
        val lesson = content.course(courseId)?.chapters?.flatMap { it.lessons }?.firstOrNull { it.id == lessonId }
            ?: throw IllegalArgumentException("Lesson not found")
        require(lesson.exercises.any { it.id == exerciseId }) { "Exercise not found" }
        progress.markExercise(lessonId, exerciseId, completed)
    }
}

class SubmitQuiz(private val content: ContentRepository, private val progress: ProgressRepository) {
    operator fun invoke(courseId: String, lessonId: String, answers: Map<String, Int>): QuizResult {
        val lesson = content.course(courseId)?.chapters?.flatMap { it.lessons }?.firstOrNull { it.id == lessonId }
            ?: error("Lesson not found")
        val quiz = lesson.quiz ?: error("Lesson has no quiz")
        require(quiz.questions.isNotEmpty()) { "Quiz has no questions" }
        val questionIds = quiz.questions.map { it.id }.toSet()
        require(answers.keys == questionIds) { "All quiz questions must be answered exactly once" }
        quiz.questions.forEach { question ->
            val answer = answers[question.id] ?: error("Missing quiz answer")
            require(answer in question.options.indices) { "Invalid answer for ${question.id}" }
        }
        val previousAttempts = progress.snapshot().lessons[lessonId]?.quizAttempts.orEmpty()
        quiz.maxAttempts?.let { require(previousAttempts.size < it) { "Maximum quiz attempts reached" } }
        val correct = quiz.questions.count { q -> answers[q.id] == q.correctIndex }
        val score = correct * 100 / quiz.questions.size
        val attempt = QuizAttempt(UUID.randomUUID().toString(), lessonId, answers.toMap(), score, score >= quiz.passPercent, System.currentTimeMillis())
        progress.recordQuizAttempt(lessonId, attempt)
        return QuizResult(score, attempt.passed, correct, quiz.questions.size, attempt.attemptId)
    }
}

class UpdateMission(private val content: ContentRepository, private val progress: ProgressRepository) {
    operator fun invoke(courseId: String, lessonId: String, missionId: String, result: MissionResult) {
        val lesson = content.course(courseId)?.chapters?.flatMap { it.lessons }?.firstOrNull { it.id == lessonId }
            ?: throw IllegalArgumentException("Lesson not found")
        require(lesson.missions.any { it.id == missionId }) { "Mission not found" }
        progress.updateMission(lessonId, missionId, result)
    }
}

class EvaluateLesson(private val content: ContentRepository, private val progress: ProgressRepository) {
    operator fun invoke(courseId: String, lessonId: String): LessonProgress {
        val lesson = content.course(courseId)?.chapters?.flatMap { it.lessons }?.firstOrNull { it.id == lessonId } ?: error("Lesson not found")
        val current = progress.snapshot().lessons[lessonId] ?: LessonProgress(lessonId)
        val exercisesDone = lesson.exercises.all { current.exercises[it.id]?.completed == true }
        val quizPassed = lesson.quiz?.let { current.quizAttempts.any { attempt -> attempt.passed } } ?: true
        val missionsDone = lesson.missions.all { current.missions[it.id]?.result == MissionResult.SUCCESS }
        val complete = exercisesDone && quizPassed && missionsDone
        val state = if (complete) LearningState.COMPLETED else LearningState.IN_PROGRESS
        val score = calculateScore(lesson, current)
        val updated = current.copy(state = state, score = score, completedAt = if (complete) (current.completedAt ?: System.currentTimeMillis()) else null)
        progress.setLessonProgress(updated)
        return updated
    }
    private fun calculateScore(lesson: Lesson, p: LessonProgress): Int {
        val parts = mutableListOf<Int>()
        if (lesson.exercises.isNotEmpty()) parts += p.exercises.values.count { it.completed } * 100 / lesson.exercises.size
        lesson.quiz?.let { parts += (p.quizAttempts.maxByOrNull { a -> a.attemptedAt }?.score ?: 0) }
        if (lesson.missions.isNotEmpty()) parts += p.missions.values.count { it.result == MissionResult.SUCCESS } * 100 / lesson.missions.size
        return if (parts.isEmpty()) 0 else parts.average().toInt()
    }
}

class GetCourseProgress(private val content: ContentRepository, private val progress: ProgressRepository) {
    operator fun invoke(courseId: String): CourseProgress {
        val course = content.course(courseId) ?: return CourseProgress(courseId, 0, 0, 0)
        val lessons = course.chapters.flatMap { it.lessons }
        val done = lessons.count { val s = progress.snapshot().lessons[it.id]?.state; s == LearningState.COMPLETED || s == LearningState.MASTERED }
        return CourseProgress(courseId, done, lessons.size, if (lessons.isEmpty()) 0 else done * 100 / lessons.size)
    }
}

class GetNextLesson(private val content: ContentRepository, private val progress: ProgressRepository) {
    operator fun invoke(courseId: String): Lesson? {
        val course = content.course(courseId) ?: return null
        val snapshot = progress.snapshot()
        return course.chapters.flatMap { it.lessons }.firstOrNull { lesson ->
            val state = snapshot.lessons[lesson.id]?.state ?: LearningState.AVAILABLE
            state != LearningState.COMPLETED && state != LearningState.MASTERED && lesson.prerequisiteLessonIds.all { snapshot.lessons[it]?.state == LearningState.COMPLETED || snapshot.lessons[it]?.state == LearningState.MASTERED }
        }
    }
}

class CanAccess(private val entitlements: EntitlementRepository) {
    operator fun invoke(access: Access): Boolean = when (access) {
        Access.FREE -> true
        Access.PRO -> entitlements.activeTier(Access.PRO) || entitlements.activeTier(Access.PREMIUM)
        Access.PREMIUM -> entitlements.activeTier(Access.PREMIUM)
    }
}


data class PersonalizedLesson(val lesson: Lesson, val score: Int, val reasons: List<String>, val confidence: Int = 0, val safetyNotes: List<String> = emptyList())

/** AI-ready orchestration: validates inputs, uses a provider boundary, and falls back locally/offline. */
class GetPersonalizedLessons(
    private val content: ContentRepository,
    private val progress: ProgressRepository,
    private val dog: DogRepository,
    private val provider: com.rockyx.app.ai.PersonalizationProvider = com.rockyx.app.ai.LocalPersonalizationProvider()
) {
    operator fun invoke(courseId: String, limit: Int = 3): List<PersonalizedLesson> {
        val course = content.course(courseId) ?: return emptyList()
        val input = com.rockyx.app.ai.PersonalizationInput(dog.current(), course.chapters.flatMap { it.lessons }, progress.snapshot(), limit)
        com.rockyx.app.ai.PersonalizationSafetyPolicy.validate(input)
        val recommendations = provider.recommend(input)
        val byId = input.lessons.associateBy { it.id }
        return recommendations.mapNotNull { r -> byId[r.lessonId]?.let { PersonalizedLesson(it, r.score, r.reasons, r.confidence, r.safetyNotes) } }
    }
}

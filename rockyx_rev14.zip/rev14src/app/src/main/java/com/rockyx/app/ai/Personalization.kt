package com.rockyx.app.ai

import com.rockyx.app.domain.model.*

/** Provider-neutral AI boundary. No vendor SDK is allowed in the domain layer. */
interface PersonalizationProvider {
    fun recommend(input: PersonalizationInput): List<PersonalizedRecommendation>
}

data class PersonalizationInput(
    val profile: DogProfile,
    val lessons: List<Lesson>,
    val progress: ProgressSnapshot,
    val limit: Int = 3
)

data class PersonalizedRecommendation(
    val lessonId: String,
    val score: Int,
    val confidence: Int,
    val reasons: List<String>,
    val safetyNotes: List<String> = emptyList()
)

/** Safe, deterministic fallback. It remains usable offline and when no AI provider is configured. */
class LocalPersonalizationProvider : PersonalizationProvider {
    override fun recommend(input: PersonalizationInput): List<PersonalizedRecommendation> {
        require(input.limit in 1..20)
        val goals = input.profile.goals.map { it.trim().lowercase() }.filter { it.isNotBlank() }.toSet()
        val behaviors = input.profile.behaviors.map { it.trim().lowercase() }.filter { it.isNotBlank() }.toSet()
        return input.lessons.mapNotNull { lesson ->
            val state = input.progress.lessons[lesson.id]?.state ?: LearningState.AVAILABLE
            if (state == LearningState.COMPLETED || state == LearningState.MASTERED) return@mapNotNull null
            if (lesson.prerequisiteLessonIds.any { prerequisite ->
                    input.progress.lessons[prerequisite]?.state !in setOf(LearningState.COMPLETED, LearningState.MASTERED)
                }) return@mapNotNull null
            var score = 0
            val reasons = mutableListOf<String>()
            val goalHits = lesson.goalTags.count { it.trim().lowercase() in goals }
            val behaviorHits = lesson.behaviorTags.count { it.trim().lowercase() in behaviors }
            if (goalHits > 0) { score += (goalHits * 35).coerceAtMost(70); reasons += "هدف سگ هم‌راستا است" }
            if (behaviorHits > 0) { score += (behaviorHits * 25).coerceAtMost(50); reasons += "رفتار ثبت‌شده مرتبط است" }
            if (lesson.recommendedLevels.any { it.equals(input.profile.level, true) }) { score += 25; reasons += "مناسب سطح فعلی است" }
            if (state == LearningState.IN_PROGRESS) { score += 40; reasons += "ادامه مسیر نیمه‌تمام است" }
            score += (20 - lesson.durationMinutes.coerceAtMost(20)).coerceAtLeast(0)
            val evidence = listOf(goalHits > 0, behaviorHits > 0, lesson.recommendedLevels.any { it.equals(input.profile.level, true) }, state == LearningState.IN_PROGRESS).count { it }
            val confidence = (35 + evidence * 15).coerceAtMost(95)
            PersonalizedRecommendation(lesson.id, score, confidence, reasons.ifEmpty { listOf("گام بعدی عمومی و قابل انجام") })
        }.sortedWith(compareByDescending<PersonalizedRecommendation> { it.score }.thenByDescending { it.confidence }.thenBy { it.lessonId }).take(input.limit)
    }
}

/** Safety gate for any future remote/model provider. */
object PersonalizationSafetyPolicy {
    fun validate(input: PersonalizationInput) {
        require(input.profile.id.length in 1..128)
        require(input.profile.name.length <= 120)
        require(input.profile.goals.size <= 50 && input.profile.behaviors.size <= 50)
        require(input.lessons.size <= 5000)
        require(input.limit in 1..20)
    }
}

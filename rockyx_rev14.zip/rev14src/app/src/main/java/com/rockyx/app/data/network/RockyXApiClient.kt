package com.rockyx.app.data.network

import com.rockyx.app.data.account.AuthTokenProvider
import com.rockyx.app.domain.model.Access
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.auth.Auth
import io.ktor.client.plugins.auth.providers.BearerTokens
import io.ktor.client.plugins.auth.providers.bearer
import io.ktor.client.request.accept
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.put
import io.ktor.client.request.get
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class AccountProfile(val userId: String, val displayName: String?, val locale: String?, val timeZone: String?, val onboardingVersion: Int, val profileVersion: Int)
data class AccountProfileUpdate(val displayName: String?, val locale: String?, val timeZone: String?, val onboardingVersion: Int = 2)

class ApiException(val statusCode: Int, val code: String, override val message: String, val retryable: Boolean) : RuntimeException(message)

class RockyXApiClient(
    baseUrl: String,
    private val tokenProvider: AuthTokenProvider,
    private val httpClient: HttpClient = buildClient(tokenProvider)
) {
    private val base = normalizeBaseUrl(baseUrl)

    init {
        if (base.isNotBlank()) require(base.startsWith("https://")) { "Rocky X API must use HTTPS" }
    }

    suspend fun exchangeIdentity(provider: String, idToken: String): AuthTokenResponse = withContext(Dispatchers.IO) {
        require(base.isNotBlank())
        require(provider.length in 2..64 && idToken.length in 32..16384)
        val response = httpClient.post("$base/api/v1/auth/exchange") {
            header("Content-Type", ContentType.Application.Json.toString()); accept(ContentType.Application.Json)
            setBody(JSONObject().put("provider", provider).put("idToken", idToken).toString())
        }
        val body = response.bodyAsText(); require(body.length <= MAX_RESPONSE_BYTES)
        if (!response.status.isSuccess()) throw apiException(response.status, body)
        val o=JSONObject(body); AuthTokenResponse(o.getString("accessToken"),o.getString("refreshToken"),o.getLong("expiresAtEpochMs"),o.getString("userId"))
    }

    suspend fun refreshSession(refreshToken: String): AuthTokenResponse = withContext(Dispatchers.IO) {
        require(base.isNotBlank()); require(refreshToken.length in 32..512)
        val response = httpClient.post("$base/api/v1/auth/refresh") {
            header("Content-Type", ContentType.Application.Json.toString()); accept(ContentType.Application.Json)
            setBody(JSONObject().put("refreshToken", refreshToken).toString())
        }
        val body=response.bodyAsText(); require(body.length <= MAX_RESPONSE_BYTES)
        if (!response.status.isSuccess()) throw apiException(response.status, body)
        val o=JSONObject(body); AuthTokenResponse(o.getString("accessToken"),o.getString("refreshToken"),o.getLong("expiresAtEpochMs"),o.getString("userId"))
    }

    suspend fun logoutSession(refreshToken: String) = withContext(Dispatchers.IO) {
        require(base.isNotBlank()); require(refreshToken.length in 32..512)
        httpClient.post("$base/api/v1/auth/logout") { header("Content-Type", ContentType.Application.Json.toString()); accept(ContentType.Application.Json); setBody(JSONObject().put("refreshToken", refreshToken).toString()) }
    }


    suspend fun fetchAccountProfile(): AccountProfile = withContext(Dispatchers.IO) {
        require(base.isNotBlank())
        val response = httpClient.get("$base/api/v1/account/profile") { accept(ContentType.Application.Json) }
        val body = response.bodyAsText(); require(body.length <= MAX_RESPONSE_BYTES)
        if (!response.status.isSuccess()) throw apiException(response.status, body)
        val o = JSONObject(body)
        AccountProfile(o.getString("userId"), o.optString("displayName").ifBlank { null }, o.optString("locale").ifBlank { null }, o.optString("timeZone").ifBlank { null }, o.optInt("onboardingVersion", 1), o.optInt("profileVersion", 1))
    }

    suspend fun updateAccountProfile(profile: AccountProfileUpdate): AccountProfile = withContext(Dispatchers.IO) {
        require(base.isNotBlank())
        require((profile.displayName?.length ?: 0) <= 80 && (profile.locale?.length ?: 0) <= 32 && (profile.timeZone?.length ?: 0) <= 64)
        val response = httpClient.put("$base/api/v1/account/profile") {
            header("Content-Type", ContentType.Application.Json.toString()); accept(ContentType.Application.Json)
            setBody(JSONObject().put("displayName", profile.displayName).put("locale", profile.locale).put("timeZone", profile.timeZone).put("onboardingVersion", profile.onboardingVersion).toString())
        }
        val body = response.bodyAsText(); require(body.length <= MAX_RESPONSE_BYTES)
        if (!response.status.isSuccess()) throw apiException(response.status, body)
        val o = JSONObject(body)
        AccountProfile(o.getString("userId"), o.optString("displayName").ifBlank { null }, o.optString("locale").ifBlank { null }, o.optString("timeZone").ifBlank { null }, o.optInt("onboardingVersion", 1), o.optInt("profileVersion", 1))
    }

    suspend fun verifyGooglePlayPurchase(productId: String, purchaseToken: String): RemoteVerifiedPurchase = withContext(Dispatchers.IO) {
        require(base.isNotBlank()) { "Rocky X API base URL is not configured" }
        require(productId.length in 1..200) { "Invalid productId" }
        require(purchaseToken.length in 20..4096) { "Invalid purchase token" }
        val idem = UUID.nameUUIDFromBytes((productId + ":" + purchaseToken).toByteArray()).toString()
        val response = httpClient.post("$base/api/v1/billing/google-play/subscriptions/verify") {
            header("Content-Type", ContentType.Application.Json.toString())
            accept(ContentType.Application.Json)
            header("Idempotency-Key", idem)
            setBody(JSONObject().put("productId", productId).put("purchaseToken", purchaseToken).toString())
        }
        val body = response.bodyAsText()
        require(body.length <= MAX_RESPONSE_BYTES) { "API response is too large" }
        if (!response.status.isSuccess()) throw apiException(response.status, body)
        val o = JSONObject(body)
        RemoteVerifiedPurchase(
            productId = o.getString("productId"),
            tier = Access.valueOf(o.getString("tier")),
            state = o.getString("state"),
            expiresAtEpochMs = if (o.isNull("expiresAtEpochMs")) null else o.getLong("expiresAtEpochMs"),
            acknowledged = o.getBoolean("acknowledged")
        )
    }

    suspend fun fetchEntitlements(): List<RemoteEntitlement> = withContext(Dispatchers.IO) {
        require(base.isNotBlank()) { "Rocky X API base URL is not configured" }
        val response = httpClient.get("$base/api/v1/entitlements") { accept(ContentType.Application.Json) }
        val body = response.bodyAsText()
        require(body.length <= MAX_RESPONSE_BYTES) { "API response is too large" }
        if (!response.status.isSuccess()) throw apiException(response.status, body)
        val array = JSONArray(body)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(RemoteEntitlement(
                    productId = o.getString("productId"),
                    tier = Access.valueOf(o.getString("tier")),
                    state = o.getString("state"),
                    expiresAtEpochMs = if (o.isNull("expiresAtEpochMs")) null else o.getLong("expiresAtEpochMs")
                ))
            }
        }
    }

    fun close() { httpClient.close() }

    companion object {
        private const val MAX_RESPONSE_BYTES = 256 * 1024
        private fun normalizeBaseUrl(value: String): String = value.trim().trimEnd('/')
        private fun buildClient(tokens: AuthTokenProvider): HttpClient = HttpClient(OkHttp) {
            expectSuccess = false
            install(HttpTimeout) {
                requestTimeoutMillis = 15_000
                connectTimeoutMillis = 10_000
                socketTimeoutMillis = 15_000
            }
            install(Auth) {
                bearer {
                    cacheTokens = false
                    loadTokens { tokens.currentAccessToken()?.let { BearerTokens(it, "") } }
                    refreshTokens { tokens.refreshAccessToken()?.let { BearerTokens(it, "") } }
                    sendWithoutRequest { request -> request.url.protocol.name == "https" }
                }
            }
        }
        private fun apiException(status: HttpStatusCode, body: String): ApiException {
            val parsed = runCatching { JSONObject(body) }.getOrNull()
            val code = parsed?.optString("code")?.ifBlank { null } ?: "HTTP_${status.value}"
            val message = parsed?.optString("message")?.ifBlank { null } ?: "Rocky X API request failed"
            val retryable = parsed?.optBoolean("retryable", status.value >= 500) ?: (status.value >= 500)
            return ApiException(status.value, code, message, retryable)
        }
    }
}

data class RemoteVerifiedPurchase(
    val productId: String,
    val tier: Access,
    val state: String,
    val expiresAtEpochMs: Long?,
    val acknowledged: Boolean
)

data class RemoteEntitlement(
    val productId: String,
    val tier: Access,
    val state: String,
    val expiresAtEpochMs: Long?
)


data class AuthTokenResponse(val accessToken: String, val refreshToken: String, val expiresAtEpochMs: Long, val userId: String)

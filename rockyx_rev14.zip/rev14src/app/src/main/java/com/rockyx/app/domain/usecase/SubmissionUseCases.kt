package com.rockyx.app.domain.usecase

import com.rockyx.app.domain.model.*
import com.rockyx.app.domain.repository.SubmissionRepository

object SubmissionScopes {
    const val PROCESSING = "submission_processing"
    const val PUBLIC_SHARING = "submission_public_sharing"
}

class SaveSubmission(private val repository: SubmissionRepository) {
    operator fun invoke(submission: Submission): Result<Submission> {
        if (submission.localUri.isBlank()) return Result.failure(IllegalArgumentException("localUri is required"))
        if (submission.missionId.isBlank()) return Result.failure(IllegalArgumentException("missionId is required"))
        if (submission.processingConsent?.granted != true) return Result.failure(IllegalStateException("processing consent required"))
        if (submission.visibility == SubmissionVisibility.PUBLIC && submission.publicSharingConsent?.granted != true) return Result.failure(IllegalStateException("public sharing consent required"))
        val saved = submission.copy(status = SubmissionStatus.READY, updatedAt = System.currentTimeMillis())
        repository.save(saved)
        return Result.success(saved)
    }
}

class QueueSubmission(private val repository: SubmissionRepository, private val uploader: com.rockyx.app.domain.repository.SubmissionUploadGateway) {
    operator fun invoke(id: String): Result<Submission> {
        val s = repository.get(id) ?: return Result.failure(NoSuchElementException("submission not found"))
        if (s.processingConsent?.granted != true) return Result.failure(IllegalStateException("processing consent required"))
        if (!uploader.available()) return Result.failure(IllegalStateException("upload service unavailable"))
        repository.save(s.copy(status = SubmissionStatus.QUEUED, updatedAt = System.currentTimeMillis()))
        return uploader.enqueue(s).fold(
            onSuccess = { receipt ->
                val updated = s.copy(
                    status = SubmissionStatus.PENDING_REVIEW,
                    uploadId = receipt.uploadId,
                    remoteId = receipt.remoteId,
                    remoteState = receipt.state,
                    updatedAt = System.currentTimeMillis()
                )
                repository.save(updated); Result.success(updated)
            },
            onFailure = { error ->
                val updated = s.copy(status = SubmissionStatus.FAILED, failureReason = error.message, updatedAt = System.currentTimeMillis())
                repository.save(updated); Result.failure(error)
            }
        )
    }
}

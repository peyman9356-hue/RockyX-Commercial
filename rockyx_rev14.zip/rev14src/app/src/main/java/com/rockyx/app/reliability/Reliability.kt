package com.rockyx.app.reliability

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

/** Safe failure taxonomy shared by UI/background recovery decisions. */
enum class FailureCategory { NETWORK, AUTH, SYNC, MEDIA, SUBMISSION, STORAGE, BILLING, CONTENT, UNKNOWN }
enum class RecoveryAction { RETRY, WAIT_FOR_NETWORK, REAUTH, RESTORE_LOCAL, CONTACT_SUPPORT, NONE }

data class FailureEvent(
    val errorCode: String,
    val category: FailureCategory,
    val retryable: Boolean,
    val occurredAtEpochMs: Long,
    val attemptCount: Int = 0
)

interface ReliabilityRepository {
    fun recordFailure(event: FailureEvent)
    fun pendingFailures(): List<FailureEvent>
    fun markHandled(errorCode: String, occurredAtEpochMs: Long)
    fun hasPreviousCrash(): Boolean
    fun consumePreviousCrash(): Boolean
}

/** Small, synchronous, privacy-safe queue. It stores codes/categories only, never stack traces or payloads. */
class LocalReliabilityRepository(context: Context) : ReliabilityRepository {
    private val prefs = context.applicationContext.getSharedPreferences("rockyx_reliability_v1", Context.MODE_PRIVATE)
    private val lock = Any()
    private val maxEvents = 50

    override fun recordFailure(event: FailureEvent) { synchronized(lock) {
        val safeCode = event.errorCode.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64).ifBlank { "UNKNOWN_ERROR" }
        val line = listOf(safeCode, event.category.name, event.retryable, event.occurredAtEpochMs, event.attemptCount.coerceIn(0, 20)).joinToString("|")
        val existing = prefs.getStringSet("failures", emptySet()).orEmpty().toMutableSet()
        existing += line
        while (existing.size > maxEvents) existing.remove(existing.minByOrNull { it.split('|').getOrNull(3)?.toLongOrNull() ?: Long.MAX_VALUE } ?: break)
        prefs.edit().putStringSet("failures", existing).commit()
    } }

    override fun pendingFailures(): List<FailureEvent> = synchronized(lock) {
        prefs.getStringSet("failures", emptySet()).orEmpty().mapNotNull { parse(it) }.sortedByDescending { it.occurredAtEpochMs }
    }

    override fun markHandled(errorCode: String, occurredAtEpochMs: Long) { synchronized(lock) {
        val kept = prefs.getStringSet("failures", emptySet()).orEmpty().filterNot { line ->
            val p = line.split('|'); p.size == 5 && p[0] == errorCode && p[3].toLongOrNull() == occurredAtEpochMs
        }.toSet()
        prefs.edit().putStringSet("failures", kept).commit()
    } }

    fun markCrashPending() = prefs.edit().putBoolean("previous_crash", true).commit()

    override fun hasPreviousCrash(): Boolean = prefs.getBoolean("previous_crash", false)

    override fun consumePreviousCrash(): Boolean = synchronized(lock) {
        val value = prefs.getBoolean("previous_crash", false)
        if (value) prefs.edit().putBoolean("previous_crash", false).commit()
        value
    }

    private fun parse(line: String): FailureEvent? = runCatching {
        val p = line.split('|'); require(p.size == 5)
        FailureEvent(p[0], FailureCategory.valueOf(p[1]), p[2].toBooleanStrict(), p[3].toLong(), p[4].toInt())
    }.getOrNull()
}

object FailureRecoveryPolicy {
    private const val MAX_ATTEMPTS = 5

    fun action(event: FailureEvent, online: Boolean, authenticated: Boolean): RecoveryAction = when {
        event.category == FailureCategory.AUTH && !authenticated -> RecoveryAction.REAUTH
        (event.category == FailureCategory.NETWORK || event.category == FailureCategory.SYNC) && !online -> RecoveryAction.WAIT_FOR_NETWORK
        event.retryable && event.attemptCount < MAX_ATTEMPTS -> RecoveryAction.RETRY
        event.category == FailureCategory.STORAGE -> RecoveryAction.RESTORE_LOCAL
        event.category == FailureCategory.UNKNOWN -> RecoveryAction.CONTACT_SUPPORT
        else -> RecoveryAction.NONE
    }

    fun nextDelayMs(attempt: Int): Long {
        if (attempt >= MAX_ATTEMPTS) return 60_000L
        val safeAttempt = attempt.coerceAtLeast(0)
        return (1_000L * (1L shl safeAttempt)).coerceAtMost(60_000L)
    }

    fun canRetry(attempt: Int): Boolean = attempt in 0 until MAX_ATTEMPTS
}

/** Install once from Application.onCreate; preserves Android's default crash handling. */
object CrashRecovery {
    private val installed = AtomicBoolean(false)

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        val repository = LocalReliabilityRepository(context)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            repository.markCrashPending()
            previous?.uncaughtException(thread, throwable)
        }
    }
}

package com.rockyx.app.ui.shell

/**
 * Stable top-level destinations for the Rocky X single-shell experience.
 *
 * This is intentionally independent from Android views so navigation can be
 * tested without a device and the shell can evolve without moving domain logic.
 */
sealed interface AppDestination {
    data object Home : AppDestination
    data object Library : AppDestination
    data object Settings : AppDestination
    data object Progress : AppDestination
    data object Dog : AppDestination
    data object Commerce : AppDestination
    data object Account : AppDestination
    data class Course(val courseId: String) : AppDestination
    data class Lesson(val courseId: String, val lessonId: String) : AppDestination
}

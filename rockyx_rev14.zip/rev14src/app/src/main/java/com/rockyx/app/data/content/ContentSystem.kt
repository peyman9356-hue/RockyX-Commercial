package com.rockyx.app.data.content

import android.content.Context
import com.rockyx.app.domain.model.*
import org.json.JSONArray
import org.json.JSONObject

/** Versioned, asset-backed content source. The JSON contract is intentionally backend/CMS-shaped. */
data class ContentManifest(val schemaVersion: Int, val contentVersion: String, val locale: String)

class ContentValidationException(message: String) : IllegalArgumentException(message)

object ContentValidator {
    fun validate(manifest: ContentManifest, courses: List<Course>) {
        require(manifest.schemaVersion >= 1) { "Unsupported content schema" }
        require(manifest.contentVersion.isNotBlank()) { "Missing content version" }
        val courseIds = mutableSetOf<String>()
        val lessonIds = mutableSetOf<String>()
        courses.forEach { course ->
            if (course.id.isBlank() || !courseIds.add(course.id)) throw ContentValidationException("Invalid or duplicate course id: ${course.id}")
            if (course.chapters.isEmpty()) throw ContentValidationException("Course has no chapters: ${course.id}")
            course.chapters.forEach { chapter ->
                if (chapter.id.isBlank()) throw ContentValidationException("Blank chapter id in ${course.id}")
                if (chapter.lessons.isEmpty()) throw ContentValidationException("Chapter has no lessons: ${chapter.id}")
                chapter.lessons.forEach { lesson ->
                    if (lesson.id.isBlank() || !lessonIds.add(lesson.id)) throw ContentValidationException("Invalid or duplicate lesson id: ${lesson.id}")
                    if (lesson.title.isBlank() || lesson.durationMinutes !in 1..1440) throw ContentValidationException("Invalid lesson metadata: ${lesson.id}")
                    lesson.prerequisiteLessonIds.forEach { prerequisite ->
                        if (prerequisite == lesson.id) throw ContentValidationException("Lesson cannot depend on itself: ${lesson.id}")
                    }
                    lesson.quiz?.let { quiz ->
                        if (quiz.questions.isEmpty()) throw ContentValidationException("Quiz has no questions: ${lesson.id}")
                        if (quiz.passPercent !in 0..100) throw ContentValidationException("Invalid quiz passPercent: ${lesson.id}")
                        quiz.maxAttempts?.let { if (it !in 1..100) throw ContentValidationException("Invalid quiz maxAttempts: ${lesson.id}") }
                        val questionIds = mutableSetOf<String>()
                        quiz.questions.forEach { q ->
                            if (q.id.isBlank() || !questionIds.add(q.id) || q.prompt.isBlank() || q.options.isEmpty() || q.options.any { it.isBlank() } || q.correctIndex !in q.options.indices)
                                throw ContentValidationException("Invalid quiz question: ${q.id}")
                        }
                    }
                    val exerciseIds = mutableSetOf<String>()
                    lesson.exercises.forEach { e ->
                        if (e.id.isBlank() || !exerciseIds.add(e.id) || e.title.isBlank()) throw ContentValidationException("Invalid exercise: ${e.id}")
                    }
                    val missionIds = mutableSetOf<String>()
                    lesson.missions.forEach { m ->
                        if (m.id.isBlank() || !missionIds.add(m.id) || m.title.isBlank()) throw ContentValidationException("Invalid mission: ${m.id}")
                    }
                }
            }
        }
        val lessonsById = courses.flatMap { it.chapters }.flatMap { it.lessons }.associateBy { it.id }
        courses.forEach { course -> course.chapters.forEach { chapter -> chapter.lessons.forEach { lesson ->
            lesson.prerequisiteLessonIds.forEach { prerequisite ->
                if (prerequisite !in lessonIds) throw ContentValidationException("Missing prerequisite $prerequisite for ${lesson.id}")
            }
        } } }
        val visiting = mutableSetOf<String>()
        val visited = mutableSetOf<String>()
        fun visit(id: String) {
            if (id in visiting) throw ContentValidationException("Cyclic lesson prerequisite detected at $id")
            if (!visited.add(id)) return
            visiting += id
            lessonsById.getValue(id).prerequisiteLessonIds.forEach(::visit)
            visiting -= id
        }
        lessonsById.keys.forEach(::visit)
    }
}

class AssetContentRepository(context: Context) : com.rockyx.app.domain.repository.ContentRepository {
    private val manifest: ContentManifest
    private val data: List<Course>

    init {
        val json = context.assets.open("content/catalog_v1.json").bufferedReader().use { it.readText() }
        val root = JSONObject(json)
        manifest = ContentManifest(root.getInt("schemaVersion"), root.getString("contentVersion"), root.getString("locale"))
        data = parseCourses(root.getJSONArray("courses"))
        ContentValidator.validate(manifest, data)
    }

    fun manifest(): ContentManifest = manifest
    override fun courses(): List<Course> = data
    override fun course(id: String): Course? = data.firstOrNull { it.id == id }

    private fun parseCourses(array: JSONArray): List<Course> = buildList {
        for (i in 0 until array.length()) {
            val c = array.getJSONObject(i)
            add(Course(c.getString("id"), c.getString("title"), c.getString("description"), Access.valueOf(c.getString("access")), c.optBoolean("daily"), parseChapters(c.optJSONArray("chapters") ?: JSONArray())))
        }
    }
    private fun parseChapters(array: JSONArray): List<Chapter> = buildList {
        for (i in 0 until array.length()) { val c = array.getJSONObject(i); add(Chapter(c.getString("id"), c.getString("title"), parseLessons(c.optJSONArray("lessons") ?: JSONArray()))) }
    }
    private fun parseLessons(array: JSONArray): List<Lesson> = buildList {
        for (i in 0 until array.length()) {
            val l = array.getJSONObject(i)
            val lessonMedia = parseMedia(l.optJSONArray("media") ?: JSONArray())
            val exercises = buildList { val a=l.optJSONArray("exercises") ?: JSONArray(); for (j in 0 until a.length()) { val e=a.getJSONObject(j); add(Exercise(e.getString("id"),e.getString("title"),e.getString("instructions"),jsonStrings(e.optJSONArray("successCriteria")),parseMedia(e.optJSONArray("media") ?: JSONArray()))) } }
            val missions = buildList { val a=l.optJSONArray("missions") ?: JSONArray(); for (j in 0 until a.length()) { val m=a.getJSONObject(j); add(Mission(m.getString("id"),m.getString("title"),m.getString("instructions"),m.optBoolean("requiresSubmission"))) } }
            val quiz = l.optJSONObject("quiz")?.let { q -> QuizConfig(parseQuestions(q.optJSONArray("questions") ?: JSONArray()), q.optInt("passPercent",70), q.optInt("maxAttempts").takeIf { it > 0 }) }
            add(Lesson(l.getString("id"),l.getString("title"),l.getString("summary"),Access.valueOf(l.getString("access")),l.getInt("durationMinutes"),exercises,quiz,missions,lessonMedia,prerequisiteLessonIds=jsonStrings(l.optJSONArray("prerequisiteLessonIds")),goalTags=jsonStrings(l.optJSONArray("goalTags")),behaviorTags=jsonStrings(l.optJSONArray("behaviorTags")),recommendedLevels=jsonStrings(l.optJSONArray("recommendedLevels"))))
        }
    }
    private fun parseMedia(array: JSONArray): List<MediaRef> = buildList {
        for (i in 0 until array.length()) {
            val m = array.getJSONObject(i)
            add(MediaRef(m.getString("id"), ContentType.valueOf(m.getString("type")), m.optString("uri").takeIf { it.isNotBlank() }, m.optBoolean("downloadable"), m.optString("thumbnailUri").takeIf { it.isNotBlank() }))
        }
    }
    private fun parseQuestions(array: JSONArray): List<QuizQuestion> = buildList { for (i in 0 until array.length()) { val q=array.getJSONObject(i); add(QuizQuestion(q.getString("id"),q.getString("prompt"),jsonStrings(q.getJSONArray("options")),q.getInt("correctIndex"))) } }
    private fun jsonStrings(array: JSONArray?): List<String> = buildList { if (array != null) for (i in 0 until array.length()) add(array.getString(i)) }
}

# Rocky X — Integrated Release 0.32.0

This release consolidates Phases 1–31 into one source tree. The goal of this release is **product integration**, not adding another isolated architecture layer.

## User journey

Home → Dog Profile → Personalized Recommendations → Course → Lesson → Exercise/Quiz/Mission → Progress → Media/Offline → Submission → Account → Billing/Entitlements.

## System journey

Android → authenticated API → PostgreSQL → content/CMS, progress/sync, submissions/media, AI personalization, billing verification and account/session services.

## Offline behavior

Learning progress, dog profile and downloaded media remain locally usable where their policies permit. Remote-only operations fail safely and are retried by background work when connectivity returns.

## Production truth

This source release is integration-ready and CI-buildable, but it is not a claim of production deployment. Real deployment still requires:
- production identity provider credentials
- Google Play Console products and service account/workload identity
- PostgreSQL production infrastructure, backups and restore tests
- S3-compatible object storage/CDN and media processing workers
- TLS/domain/DNS and secret management
- Play signing key and release AAB
- closed testing on physical Android devices

No production secret is included in this archive.

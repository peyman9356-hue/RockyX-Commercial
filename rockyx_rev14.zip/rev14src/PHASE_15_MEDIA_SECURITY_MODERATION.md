# Phase 15 — Media Security + Moderation/Processing Foundation

Rocky X now treats newly completed user media as **QUARANTINED**, never immediately public or approved.

## Security gates
- allowlisted video MIME types
- 500 MiB maximum size
- SHA-256 checksum format validation
- authenticated ownership check remains mandatory
- object key must match the server-issued asset
- no public URL is created by this phase

## Processing boundary
`MediaSecurityScanner` is the boundary for malware/media validation/moderation.
`MediaProcessingQueue` is the boundary for asynchronous processing.
Both are intentionally unconfigured and fail closed until real production infrastructure is deployed.

## State principle
`UPLOAD_PENDING -> QUARANTINED -> (scanner/processor) -> READY or REJECTED`

A `QUARANTINED` asset must not be exposed publicly. Approval is a server-side decision after processing/moderation.

## Database
V3 adds security event and moderation-decision tables. The current API does not invent scanner results; real scanner workers will populate these records in a later deployment step.

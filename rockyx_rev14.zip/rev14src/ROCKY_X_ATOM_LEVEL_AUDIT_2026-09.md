# ROCKY X — ATOM-LEVEL ARCHITECTURE AUDIT

Date: 2026-09-09
Baseline: v0.32.2
Previous architecture revision: 2
New revision: 3

## Scope
A forensic review of the ecosystem foundation and UX-01 changes, including domain models, in-memory repository behavior, PostgreSQL persistence, migration constraints, API boundary validation, security boundaries, idempotency behavior, and static integration checks.

## Findings fixed
1. **Cross-owner idempotency collision** — in-memory event/safety/AI/vet/device stores could accept or return an existing record when the same opaque ID was reused by another owner. Fixed with ownership + dog binding checks.
2. **PostgreSQL collision ambiguity** — `ON CONFLICT DO NOTHING` could turn an ID collision into a later generic persistence error. Fixed by reading existing records first and rejecting cross-owner reuse.
3. **Database ownership integrity** — child tables duplicated `owner_user_id` without a database-level guarantee that it matched the dog's owner. Fixed with composite `(dog_id, owner_user_id)` foreign keys and a unique dog-owner key.
4. **Device deletion semantics** — device-to-dog ownership needed to remain valid while allowing an unbound device after dog deletion. Composite FK now nulls only `dog_id` on dog deletion.
5. **Validation drift** — in-memory and PostgreSQL implementations did not share one invariant set. Added `EcosystemValidation` and applied it to both paths.
6. **Safety coordinate integrity** — latitude/longitude ranges and coordinate pairing were not enforced consistently. Added domain and database constraints.
7. **AI JSON integrity** — AI JSON fields were typed as strings but needed valid JSON before PostgreSQL JSONB persistence. Added shared JSON validation.
8. **Route query validation** — event, safety, AI, and vet-access listing routes did not consistently validate dog IDs and limits. Fixed.
9. **Input length boundaries** — hardware, firmware, sex, breed, device status, event/status fields now have explicit limits.
10. **Profile concurrency contract** — PostgreSQL update now requires the supplied expected version to match the current version when present; stale writers are rejected.

## Checks
- ZIP extraction: PASS
- Existing integration check: PASS
- Required modules: PASS
- Security boundary checks: PASS
- No committed production secrets: PASS by static inspection
- Ecosystem schema ownership constraints: PASS by static inspection
- Cross-owner idempotency tests added: PASS at source/test level; full Gradle execution remains pending because this environment has no Gradle/Android SDK/dependency cache.

## Explicit non-claims
This audit does NOT claim:
- APK/AAB build success
- iOS build success
- production PostgreSQL migration execution
- live Google Play billing verification
- production cloud deployment
- device/hardware validation
- real owner usability validation

Those require real build/deployment/device/user evidence.

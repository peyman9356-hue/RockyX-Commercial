# Phase 17 — Media Processing Pipeline

Version: 0.17.0 / versionCode 17

## Goal
Process the immutable original upload into delivery-ready derivatives without modifying or replacing the original object.

## Pipeline
QUARANTINED -> DOWNLOAD ORIGINAL -> FFPROBE METADATA -> TRANSCODE VARIANTS -> THUMBNAIL -> CHECKSUM -> UPLOAD DERIVATIVES -> PERSIST METADATA -> READY (only after the security/moderation gate is satisfied).

## Design
- Original object is immutable.
- Processing runs asynchronously behind the existing job queue.
- `MediaProcessor` and `MediaArtifactStore` are provider-neutral boundaries.
- `FfmpegMediaProcessor` uses `ProcessBuilder` argument lists; no shell interpolation.
- Default variants: 360p and 720p when the source is large enough.
- MP4 uses H.264/AAC and `+faststart` for progressive playback compatibility.
- Thumbnail is JPEG.
- Every derivative gets SHA-256 and a separate object key.
- Metadata is stored in PostgreSQL; binaries stay in object storage.

## Safety
This phase does not bypass the Phase 15 quarantine/moderation gate. A successful transcode is not equivalent to content approval. The existing worker must only transition to READY after all configured security/moderation checks pass.

## Deployment dependency
Production requires `ffprobe` and `ffmpeg` binaries in the worker runtime. They are deployment dependencies, not downloaded by the application. The current repository contains the integration boundary and processor; it does not claim those binaries are installed in this development environment.

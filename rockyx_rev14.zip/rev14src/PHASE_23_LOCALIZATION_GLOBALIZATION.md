# PHASE 23 — Localization + Globalization

## Delivered
- `LocaleManager`: System / English / Persian per-app preference.
- `Globalization`: locale-aware number, currency and date/time formatting.
- Android `supportsRtl=true` and runtime layout direction from locale.
- Core UI strings moved to Android resources with English and Persian translations.
- Language selector accessible from Home.
- Currency display uses `Currency`/`NumberFormat`, not manual decimal formatting.
- Architecture leaves content localization separate from UI localization so course data can later provide localized variants through the content/CMS boundary.

## Global-ready rules
- No business logic should inspect UI language to decide access, progress, pricing or entitlements.
- Currency is a configuration/data concern; locale controls presentation only.
- Store monetary values in minor units and format at the presentation boundary.
- Use BCP-47 language tags for future locales.
- Never assume Persian is the only RTL language; layout direction is derived from the selected locale.
- Dates/times are formatted for presentation only; persistence remains epoch/UTC-safe.

## Honest scope
This phase establishes the production architecture and localizes the core Android shell. Course/lesson content itself remains data-driven and is not automatically translated; localized content variants belong to the future CMS/content pipeline.

## Validation
- Static source checks for resource references and version 0.23.0.
- XML resource parsing and duplicate-name checks.
- ZIP integrity check after packaging.
- Full Gradle/APK build is not claimed when Android SDK/dependency graph is unavailable in the execution environment.

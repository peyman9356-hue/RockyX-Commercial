# PHASE 25 — AI Personalization Layer

Version: 0.25.0 / versionCode 25

## Quality objective
Introduce an AI-ready personalization boundary without coupling Rocky X to a model vendor, network availability, or a prompt format.

## Implemented
- Provider-neutral `PersonalizationProvider` on Android and backend.
- Deterministic local fallback for offline-first operation.
- Recommendations use dog goals, behaviors, level, lesson tags, progress, prerequisites, and in-progress state.
- Stable deterministic tie-breaking by confidence and lesson ID.
- Confidence is an evidence score, not a claim of model probability.
- Safety/input limits prevent oversized recommendation requests.
- Completed/mastered lessons and unmet prerequisites are excluded.
- Backend endpoint `POST /api/v1/ai/recommendations` with `ai:read` authorization.
- Provider failure maps to safe retryable API error; no stack trace is exposed.
- No AI vendor SDK, API key, prompt, or model is embedded in the mobile app.

## Production boundary
A remote ML/LLM provider may be added later behind the same interface. Secrets remain server-side. The local provider remains a safe fallback.

## Not claimed
No remote AI model, training pipeline, cloud inference, or production model monitoring is configured by this phase.

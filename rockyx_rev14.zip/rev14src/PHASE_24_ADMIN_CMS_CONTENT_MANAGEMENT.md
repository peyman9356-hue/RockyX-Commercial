# PHASE 24 — Admin / CMS / Content Management

Version: 0.24.0 / versionCode 24

## Goal
Provide a production-shaped content management boundary so course catalogs can be drafted, versioned, validated, reviewed, and published without editing the mobile application core.

## Implemented
- Content document model with locale, schema version, semantic content version, status and revision.
- Draft/publish lifecycle.
- Optimistic concurrency using expected revision; conflicting writes return 409.
- PostgreSQL persistence with Flyway migration V6.
- Revision history and audit events with actor identity.
- Admin endpoints protected by both `content:read`/`content:write` scopes and `admin` role.
- Published-catalog read endpoint by locale.
- JSON validation, size limit and duplicate course-id validation at the server boundary.
- In-memory repository for development mode; PostgreSQL repository for configured environments.
- No credentials, payment data or media bytes are stored in CMS documents.
- Existing asset-backed mobile content remains available; remote CMS is a replacement boundary, not a breaking rewrite.

## API
- `GET /api/v1/content/catalog?locale=fa-IR` — latest published document for a locale.
- `GET /api/v1/admin/content?locale=...` — admin summaries.
- `GET /api/v1/admin/content/{contentId}` — admin document.
- `PUT /api/v1/admin/content/{contentId}` — create/update draft with optional `expectedRevision`.
- `POST /api/v1/admin/content/{contentId}/publish` — publish with mandatory `expectedRevision`.

## Safety
Publishing is explicit. Draft saves never become live automatically. Revision conflicts fail closed instead of silently overwriting another editor's work.

## Not yet production-complete
- Human approval workflow beyond admin role.
- Dedicated web admin UI.
- CDN/cache invalidation.
- Signed content manifests.
- Full JSON Schema validation for every nested lesson/media/quiz field.
- Content scheduling/rollback endpoint and editorial preview UI.

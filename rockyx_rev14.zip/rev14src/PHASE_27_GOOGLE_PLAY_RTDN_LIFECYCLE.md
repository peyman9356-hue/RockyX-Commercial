# Phase 27 — Google Play RTDN Lifecycle & Entitlement Reconciliation

Version: 0.27.0 / versionCode 27

## Goal
Keep Rocky X entitlement state synchronized when Google Play changes a subscription outside the app (renewal, cancellation, grace period, hold, pause, expiry, etc.).

## Implemented
- Authenticated Pub/Sub push endpoint: `POST /api/v1/billing/google-play/rtdn`.
- OIDC bearer validation using Google's token verification service, then strict issuer/audience/service-account/expiry checks.
- Pub/Sub `messageId` deduplication persisted in PostgreSQL.
- Five-minute processing lease so a crashed worker can safely retry a message.
- Base64 RTDN payload decoding and package-name validation.
- Subscription notification handling.
- Token-to-existing-account association through the server-side SHA-256 purchase fingerprint.
- Re-verification against `purchases.subscriptionsv2.get` before changing entitlement state.
- Entitlement and purchase-record reconciliation from verified Google state.
- Server-side acknowledgement retry on active unacknowledged subscriptions.
- Test and one-time notification telemetry without granting access.
- Unknown purchase tokens do not create accounts or entitlements.
- Invalid/failed messages are not marked processed, allowing Pub/Sub retry.
- Production startup fails closed when RTDN authentication configuration is missing.

## Security model
RTDN is only a signal that state changed. It is never treated as proof of entitlement. The backend re-queries Google Play for the complete purchase state before modifying Rocky X access. This follows Google's current RTDN guidance. Purchase tokens remain server-side secrets and are never logged.

## Deployment requirements
Configure an authenticated Pub/Sub push subscription with:
- push endpoint: `/api/v1/billing/google-play/rtdn`
- OIDC audience matching `ROCKYX_RTDN_AUDIENCE`
- service account email matching `ROCKYX_RTDN_SERVICE_ACCOUNT_EMAIL`
- Pub/Sub service-agent permission to mint OIDC tokens for the push service account

Google Play must publish to the configured Pub/Sub topic. Production Google Play Developer API credentials remain server-side.

## Honest boundary
A live GCP Pub/Sub subscription, Google Play Console RTDN configuration, service account, and production credentials are deployment resources and are not embedded in this source tree.

# Phase 14 — Media Storage & Delivery

Goal: move large media out of the application database while preserving secure ownership, resumability and future CDN/object-storage integration.

## Production path
Android → authenticated API → short-lived upload intent → Object Storage → checksum completion → media metadata → moderation/review → controlled download URL/CDN.

The current source intentionally does not pretend that a cloud storage provider is configured. `UnconfiguredObjectStorage` returns no URL, so production cannot silently fall back to a fake upload.

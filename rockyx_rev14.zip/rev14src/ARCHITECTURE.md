# Rocky X Architecture — Phase 20

## Observability
Android / Backend code -> Telemetry / Analytics boundary -> future OTLP/metrics/log backend.

No product domain should depend directly on a vendor SDK.

## Privacy
Telemetry must not contain raw tokens, authorization headers, email, phone, addresses, raw media, or raw request payloads.

## Health
`/api/v1/health` reports liveness. `/api/v1/ready` is the readiness boundary. Deployment-specific readiness checks can be expanded to DB/storage dependencies without changing API/domain code.

## Analytics
Analytics events are product-level signals such as lesson_started, lesson_completed, submission_created. They must be minimal, non-sensitive, and safe to buffer while offline.


## Reliability
Android uses a local bounded failure queue, crash marker, recovery policy, and finite WorkManager retry budget. Backend errors are structured, correlated by request ID, sanitized, and readiness-aware.


## Phase 22 — Quality & Security Boundary
- Backend input validation is centralized in `SecurityPolicy`.
- Authentication rejects malformed/oversized Bearer headers before cryptographic verification.
- API errors remain structured and safe for clients; internal exception details are not returned.
- Android backup is disabled because local progress, submissions and session state are application data.
- Tests include pure security-policy and retry/recovery invariants.

## Phase 23 — Globalization boundary
Presentation uses `LocaleManager` and `Globalization`; domain/data layers remain locale-agnostic. UI language is not an authorization, entitlement, pricing, or learning-state input. Content localization is expected through versioned content data/CMS, not hardcoded in the learning engine.


## Phase 24 — Admin / CMS / Content Management
Rocky X now has a server-side, versioned content-management boundary with draft/publish lifecycle, optimistic concurrency, audit history, locale-aware published catalogs, and role/scope authorization.


## Phase 25
AI Personalization is provider-neutral, safety-gated, deterministic/offline-capable, and does not embed model credentials or vendor SDKs.

## Phase 26 — Billing Authority
Google Play purchase flow is split into client and server responsibilities. The Android BillingClient detects/query purchases and exposes purchase tokens. The authenticated backend is authoritative: it verifies the token against Google Play Developer API `purchases.subscriptionsv2.get`, maps only allow-listed product IDs to Rocky X tiers, persists the entitlement, and acknowledges active purchases server-side. Raw purchase tokens are not persisted; only a SHA-256 fingerprint is stored for replay/cross-account protection. Local debug trials are never a production entitlement source.


## Phase 28 — Billing purchase boundary
Android Google Play Billing → BillingPurchaseOrchestrator → PurchaseVerificationGateway → authenticated Rocky X backend → Google Play verification → Entitlement. The Android client never grants entitlement from local purchase state.


### Phase 29 — Authenticated API Boundary
Android network access now flows through `RockyXApiClient` → `AuthTokenProvider` → authenticated HTTPS API. Billing verification and entitlement reads remain server-authoritative. Local entitlement state is replaced only after a successful authenticated snapshot.


## Identity Provider Boundary — Phase 31
External identity providers (Google today; Passkeys and others later) are adapters. They establish external identity only. Rocky X then issues its own first-party session. Account data, billing entitlements, progress and dog profiles remain keyed by Rocky X userId.

## Master Ecosystem Foundation — Post-v0.32.2 repair
Rocky X is now architected as a Smart Dog Ecosystem. The Dog Identity is a first-class cloud domain and may have multiple dogs per owner. Dog events, device identity, safety events, veterinary access grants and AI insight records are explicit domain boundaries.

Positioning and communication are separate capabilities. Devices are vendor-neutral domain objects; Bluetooth/GNSS/cellular implementations belong behind platform adapters. Veterinary access is owner-controlled, scoped, expiring and revocable. AI evidence, inference and recommendation are stored as distinct fields.

The v0.32.2 learning/media/billing/auth foundations remain reusable. The ecosystem layer is additive and migration-safe; no existing migration is rewritten.

# Rocky X — Phase 1 Deep Security Hardening Revision 11

## Trigger
Deep pre-CI review of Revision 10 identified a security boundary flaw: external identity bearer tokens could be accepted directly by the API verifier, and first-party access JWTs were not checked against current server-side session state.

## Corrections
1. API authorization now uses first-party session verification only.
2. SessionAccessTokenVerifier requires a valid active session record by `sid`.
3. Postgres and in-memory session repositories implement active-session checks.
4. Session verifier and SessionManager share the same repository instance.
5. External identity claims are treated as identity assertions only; API scopes/roles are server-owned.
6. Added regression test for immediate access-token invalidation after session revocation.

## Verification
- Source-level static checks performed locally.
- Full Gradle build is NOT verified because this environment has no Gradle executable/wrapper and external DNS is unavailable.
- GitHub CI has not yet run Revision 11.

## Status
STATICALLY HARDENED / BUILD UNVERIFIED / RUNTIME UNVERIFIED.

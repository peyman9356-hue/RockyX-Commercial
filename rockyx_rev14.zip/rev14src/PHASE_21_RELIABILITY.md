# Phase 21 — Crash / Error Recovery + Reliability

Version: **0.21.0** / versionCode **21**

## Delivered
- Android failure taxonomy and recovery actions.
- Persistent, bounded, privacy-safe local failure queue.
- Global uncaught-exception crash marker that preserves Android's default handler.
- Startup detection of the previous crash without exposing stack traces or PII.
- Bounded background retry behavior to avoid retry storms.
- Sync/submission workers now stop retrying after a finite attempt budget.
- Backend structured `ApiError` includes stable category/retryable metadata.
- Request IDs are generated once per request and reused in error responses.
- Backend `/health` remains a liveness endpoint.
- Backend `/ready` reports dependency state and returns HTTP 503 when production dependencies are not ready.
- Backend exception responses never expose stack traces.

## Honest boundary
This phase does not claim a third-party crash-reporting SaaS, remote incident dashboard, production object-storage probe, or production deployment. Those remain provider/deployment work. The local reliability layer is real and fail-safe.

## Validation
- Source-level Kotlin sanity checks performed in the build environment.
- ZIP integrity checked with `unzip -t`.
- Full Gradle/Android build is not claimed because the Gradle/Android dependency toolchain is not available in this execution environment.

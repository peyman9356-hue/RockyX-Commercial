# Phase 26 — Real Google Play Billing + Entitlement Verification

Version: 0.26.0 / versionCode 26

## Goal
Move Pro/Premium entitlement authority from local test state to a secure server-verified Google Play purchase flow.

## Implemented
- Android Google Play Billing Library 9.1.0 adapter.
- Billing connection with automatic service reconnection.
- Product-details querying using current `queryProductDetailsAsync` APIs.
- Purchase detection through purchase callbacks and `queryPurchasesAsync`.
- Pending purchase support for one-time products and prepaid plans.
- Server endpoint `POST /api/v1/billing/google-play/subscriptions/verify`.
- Server uses Google Play Developer API `purchases.subscriptionsv2.get`.
- Product allow-list maps only known Google Play product IDs to PRO/PREMIUM tiers.
- Product ID returned by Google is checked against the submitted product ID.
- Purchase token is never stored in plaintext; only SHA-256 token fingerprint is persisted.
- A purchase token cannot be linked to two Rocky X accounts.
- Pending/non-active states do not receive active entitlement.
- Server persists entitlement state and purchase record.
- Server-side acknowledgement is attempted after entitlement persistence for active purchases.
- Acknowledgement state is persisted so failed acknowledgements can be retried by future worker infrastructure.
- `GET /api/v1/entitlements` now reads real repository state.
- Production startup fails closed when Google Play verification configuration is absent.
- No Google credentials or service-account material is accepted by the Android app.

## Security decisions
- Entitlement authority is server-side.
- The client must not self-grant Pro/Premium based only on a BillingClient callback.
- Purchase token is treated as a secret credential and is transmitted only over authenticated HTTPS.
- `orderId` is not used as the purchase identity or duplicate key.
- Product IDs are allow-listed rather than trusting arbitrary client input.
- Google Play API credentials use the Android Publisher OAuth scope and stay outside source control.

## Important production boundary
This phase contains the real integration boundary and real adapter code, but it is not an assertion that a live Google Play developer account, service account, Play Console products, OAuth credentials, or production backend have been configured. Those are deployment secrets/configuration and must be supplied at deployment time.

## Current limitation to carry forward
The Android app has the billing adapter, but the existing UI/commerce flow still needs to be connected to an authenticated backend API client that sends each verified purchase token to the endpoint and then refreshes entitlements. Local test trials remain development-only and must never be enabled as a production grant mechanism.

## Verification basis
Google's current Android guidance recommends verifying purchases on a secure backend before granting entitlement, handling PENDING separately, querying purchases to recover missed callbacks, and using server-side acknowledgement where possible. Current Google Play Developer API documentation exposes `purchases.subscriptionsv2.get`; older `purchases.subscriptions.get` is deprecated.

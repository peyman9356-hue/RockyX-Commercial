# Phase 28 — Billing Purchase Orchestration & Android Purchase Flow

Version: 0.28.0 / versionCode 28

## Goal
Complete the Android-side purchase journey without allowing the device to become the authority for Pro/Premium access.

## Implemented
- Production-oriented Google Play subscription purchase flow from the commerce screen.
- ProductDetails lookup from Google Play before launching a purchase.
- Valid subscription offer token required before launch.
- Purchase callback handling through a dedicated `BillingPurchaseOrchestrator`.
- Pending purchases are rejected for entitlement processing; only PURCHASED is eligible for verification.
- Purchase token and product ID are forwarded through a provider-neutral `PurchaseVerificationGateway`.
- No local entitlement is granted from a Google Play callback.
- Unconfigured backend verification fails closed.
- Billing client lifecycle is released with the Activity.
- Missing products/offers and Billing errors surface to the user.

## Security boundary
Google's current guidance requires the purchase to be verified before granting entitlement and recommends a secure backend for verification and acknowledgement. Rocky X therefore keeps entitlement authority on the backend. The Android purchase callback is only an input to verification. citeturn0search0turn0search3

## Important limitation
The repository does not contain a live authenticated Rocky X HTTP client or production Google Play credentials. Therefore this phase does NOT claim that a real purchase can currently activate Pro/Premium. The adapter launches Google Play when the product exists, but the unconfigured verification gateway intentionally refuses to grant access until the backend/auth integration is deployed.

## QA
- Static Kotlin/API wiring review completed.
- Version updated to 0.28.0 / 28.
- ZIP integrity checked.
- Full Gradle build is not claimed because this environment has no Gradle wrapper/Android SDK toolchain.

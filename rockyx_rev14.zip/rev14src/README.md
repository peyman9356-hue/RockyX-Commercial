# Rocky X — Professional Observability + Analytics

Phase 22 / version 0.22.0.

Adds a privacy-minimal, vendor-neutral observability and product analytics foundation while preserving offline-first behavior. Backend telemetry is separated from API/domain layers; Android analytics is buffered persistently on-device and redacts sensitive fields.

Production exporter, dashboards, alerting, crash backend, and retention policies remain deployment integrations and are not claimed as configured here.


### Current version
**0.27.0 / versionCode 27** — Phase 27 Google Play RTDN lifecycle is integrated.


## Phase 23 — Localization + Globalization
- Per-app locale foundation with System/English/Persian choices.
- Android RTL support enabled.
- UI strings moved toward Android resources with English/Persian translations.
- Locale-aware number, currency, date/time formatting.
- Globalization remains provider-neutral and ready for additional locales/regions.
- Content localization is intentionally separated from UI localization; future CMS/content manifests can carry localized variants without changing the learning engine.


## Phase 24 — Admin / CMS / Content Management
Rocky X now has a server-side, versioned content-management boundary with draft/publish lifecycle, optimistic concurrency, audit history, locale-aware published catalogs, and role/scope authorization.


## Phase 25
AI Personalization is provider-neutral, safety-gated, deterministic/offline-capable, and does not embed model credentials or vendor SDKs.


## Phase 26 — Google Play Billing
Real Google Play Billing 9.1.0 purchase verification boundary, server-side entitlement authority, token fingerprinting, product allow-list, and acknowledgement handling.

## Phase 27 — Google Play RTDN Lifecycle
Authenticated Pub/Sub push boundary, durable message deduplication with a five-minute recovery lease, subscription re-verification through `subscriptionsv2.get`, and server-side entitlement reconciliation. RTDN notifications are treated as triggers only; Google Play remains the source of truth.


## Phase 29
0.29.0 adds the authenticated Android API boundary and server-authoritative entitlement synchronization. The client uses a provider-neutral token boundary and never treats local purchase state as proof of paid access.


## Phase 30 — Identity & Session Security
Version 0.30.0 adds provider-neutral first-party sessions, rotating refresh tokens, server-side session persistence, and Android Keystore-backed token storage.


## Integrated Release 0.32.0
Real Google identity integration and authenticated account onboarding are available behind production configuration. Passkey transport is prepared; server-side WebAuthn verification remains deliberately gated until its full challenge/credential persistence path is implemented.


## Integrated release
See `INTEGRATED_RELEASE.md` for the unified product flow and production readiness boundaries.

## Master Ecosystem Architecture Status
The project now includes the PRE-BUILD Smart Dog Ecosystem foundation. Existing v0.32.2 training/media/auth/billing work is preserved. New additive contracts cover lifelong multi-dog identity, dog events, devices, safety events, veterinary access and AI insight separation. The repository is **not** claimed to be a production release until the real Gradle/Android build and physical-device/backend gates pass.

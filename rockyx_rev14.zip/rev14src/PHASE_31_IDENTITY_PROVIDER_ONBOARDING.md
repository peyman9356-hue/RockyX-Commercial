# Phase 31 — Identity Provider Adapters & Account Onboarding

Version 0.31.0 / versionCode 31

## Goal
Turn the Phase 30 session foundation into a real provider-aware identity boundary without coupling Rocky X Core to Google or any future identity vendor.

## Implemented
- Google Sign-in on Android through Credential Manager 1.6.0 (stable) and Google ID SDK 1.2.0.
- Per-request cryptographic nonce generated on device.
- Explicit Google ID token exchange with Rocky X backend.
- Backend Google OIDC ID-token verification using Google's published JWKS, fixed issuer, RS256 and configured web client audience.
- Provider-specific verification routing; the client cannot select an arbitrary verifier.
- First-party Rocky X session remains authoritative after external identity verification.
- Account onboarding/profile boundary: optional display name, locale, time zone and onboarding version.
- Profile data is scoped to the authenticated `userId` and has strict length limits.
- Android profile read/update APIs use authenticated API calls.
- Account screen supports sign-in, profile save and sign-out.
- Passkey Credential Manager adapter is included as a transport boundary for server-generated WebAuthn options. It intentionally does not invent or locally verify WebAuthn challenges.

## Security decisions
- No Google access token, refresh token or private credential is stored by Rocky X.
- Google ID tokens are verified server-side; email is not used as the stable account key.
- Google `sub` is the external stable identity key for account creation.
- Production requires `ROCKYX_GOOGLE_WEB_CLIENT_ID`.
- Passkey ceremonies require server-generated challenge/options and later WebAuthn4J verification; no fake passkey success path exists.
- Display name/profile fields are bounded and never used as identity keys.

## Deliberate boundary
Passkey server registration/authentication is NOT claimed complete in Phase 31. Android Credential Manager can execute the ceremony, but secure WebAuthn requires server-side challenge storage, RP ID/origin validation, credential public-key persistence, signature verification, sign-counter handling and replay protection. WebAuthn4J is the planned verifier boundary for the next passkey phase.

## Compatibility
Credential Manager 1.6.0 is the stable release as of this phase. Google ID SDK 1.2.0 is the latest release documented by Google in 2026-01 release notes.

## Validation
- Static source scans: required.
- ZIP integrity: required.
- Full Gradle build: not claimed unless the complete Android/Gradle environment is available.

# ROCKY X — MASTER SYSTEM ARCHITECTURE

## Core graph
User → Dog Identity → Dog Data/Event Stream → Cloud → AI/Insights → Recommendations → Training/Action → Results → Dog Data

Devices feed the same data graph. Safety and veterinary access are controlled domains around the Dog Identity.

## Domains
1. Identity & Accounts
2. Dog Identity & Lifelong Profile
3. Dog Events / Observations
4. Learning & Training
5. AI / Insights / Recommendations
6. Device Platform
7. Positioning
8. Communication
9. Safety & Lost Dog
10. Veterinary Access
11. Media
12. Commerce & Entitlements
13. Store
14. Localization / Globalization
15. Security / Consent / Audit
16. Observability / Reliability

## Ownership
Dog is the central aggregate. User owns dogs. Devices are bound to a user and optionally a dog. Vet access is an explicit grant. AI outputs reference evidence and inference separately.

## Device abstraction
App/domain must depend on DeviceIdentity and capabilities, never directly on Bluetooth/GNSS/cellular vendor SDKs. Concrete transports belong in platform/data adapters.

## Privacy
Location, veterinary and health-related data require least-privilege access, explicit ownership and auditable grants. Telemetry must not leak raw sensitive data.

## Sync
Every durable cross-device write needs an idempotency key and version/concurrency strategy. Local cache is not the authority for identity, entitlements or cloud history.

## Migration
Existing v0.32.2 learning, content, media, identity and billing foundations remain reusable. Dog profile persistence moves from phone-centric storage toward the cloud Dog Identity model without deleting old local data until migration is verified.

## Future hardware readiness
The architecture intentionally defines device, telemetry, safety and location boundaries now, while postponing physical component selection until market/engineering validation.

## UX-01 — Owner-first navigation architecture
UX is an architectural constraint because information architecture and navigation determine how capabilities are exposed.

- Primary navigation must expose the highest-frequency owner tasks directly; target is one or two taps for routine actions.
- Home is a task-oriented entry point, not a dump of every domain.
- Advanced domains remain available through progressive disclosure without polluting primary navigation.
- Navigation state and entry points must be consistent across Android and iOS.
- Cross-domain flows (training, dog profile, AI insights, safety and vet access) must preserve clear context so the owner does not lose the active dog or task.
- UX complexity must not be solved by duplicating business logic in screens; navigation and presentation consume stable domain contracts.
- Accessibility, localization, offline states, loading/error states and permission states are part of the navigation contract.
- Every new domain or feature requires an owner-task/accessibility review before it is added to primary navigation.

### Owner-task acceptance gate
A feature is not UX-complete merely because its screen exists. The owner must be able to identify the correct entry point, understand the current state, complete the task, and recover from common errors without developer knowledge.

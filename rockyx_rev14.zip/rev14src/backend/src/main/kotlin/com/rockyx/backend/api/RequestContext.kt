package com.rockyx.backend.api

import io.ktor.server.application.ApplicationCall
import io.ktor.util.AttributeKey

object RequestContext {
    val requestIdKey = AttributeKey<String>("rockyx.request.id")
}

fun ApplicationCall.requestId(): String = attributes.getOrNull(RequestContext.requestIdKey) ?: request.headers["X-Request-Id"] ?: "missing-request-id"

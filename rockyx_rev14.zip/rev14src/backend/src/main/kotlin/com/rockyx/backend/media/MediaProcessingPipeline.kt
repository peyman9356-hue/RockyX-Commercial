package com.rockyx.backend.media

import java.nio.file.Path
import java.time.Duration

/** Immutable technical metadata extracted from the original upload. */
data class MediaMetadata(
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val videoCodec: String,
    val audioCodec: String?,
    val bitrate: Long?,
    val frameRate: Double?
)

data class MediaVariant(
    val name: String,
    val objectKey: String,
    val contentType: String,
    val width: Int,
    val height: Int,
    val bitrate: Long,
    val checksumSha256: String,
    val sizeBytes: Long
)

data class ProcessingResult(
    val metadata: MediaMetadata,
    val variants: List<MediaVariant>,
    val thumbnailObjectKey: String,
    val thumbnailChecksumSha256: String,
    val thumbnailSizeBytes: Long
)

interface MediaArtifactStore {
    fun download(objectKey: String, destination: Path): Boolean
    fun upload(source: Path, objectKey: String, contentType: String, checksumSha256: String): Boolean
}

interface MediaProcessor {
    fun process(original: Path, workspace: Path, objectKeyPrefix: String): ProcessingResult
}

interface MediaCommandRunner {
    fun run(command: List<String>, timeout: Duration): CommandResult
}

data class CommandResult(val exitCode: Int, val stdout: String, val stderr: String)

/** Executes ffprobe/ffmpeg without shell interpolation. */
class ProcessBuilderMediaCommandRunner : MediaCommandRunner {
    override fun run(command: List<String>, timeout: Duration): CommandResult {
        require(command.isNotEmpty())
        val process = ProcessBuilder(command).redirectErrorStream(false).start()
        val stdout = process.inputStream.bufferedReader().readText()
        val stderr = process.errorStream.bufferedReader().readText()
        if (!process.waitFor(timeout.toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS)) {
            process.destroyForcibly()
            throw IllegalStateException("MEDIA_COMMAND_TIMEOUT")
        }
        return CommandResult(process.exitValue(), stdout, stderr)
    }
}

/**
 * Production processing adapter. ffprobe/ffmpeg binaries are deployment dependencies and
 * are never downloaded or executed through a shell command string.
 */
class FfmpegMediaProcessor(
    private val ffprobeBinary: String = System.getenv("ROCKYX_FFPROBE_BINARY") ?: "ffprobe",
    private val ffmpegBinary: String = System.getenv("ROCKYX_FFMPEG_BINARY") ?: "ffmpeg",
    private val runner: MediaCommandRunner = ProcessBuilderMediaCommandRunner()
) : MediaProcessor {
    override fun process(original: Path, workspace: Path, objectKeyPrefix: String): ProcessingResult {
        java.nio.file.Files.createDirectories(workspace)
        val metadataJson = workspace.resolve("metadata.json")
        val probe = runner.run(
            listOf(ffprobeBinary, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", original.toString()),
            Duration.ofMinutes(2)
        )
        if (probe.exitCode != 0) throw IllegalStateException("FFPROBE_FAILED")
        java.nio.file.Files.writeString(metadataJson, probe.stdout)
        val metadata = FfprobeJsonParser.parse(probe.stdout)

        val variants = listOf(
            VariantSpec("360p", 640, 360, 700_000L),
            VariantSpec("720p", 1280, 720, 2_500_000L)
        ).filter { it.height <= metadata.height }

        val builtVariants = variants.map { spec ->
            val output = workspace.resolve("${spec.name}.mp4")
            val command = listOf(
                ffmpegBinary, "-hide_banner", "-loglevel", "error", "-y", "-i", original.toString(),
                "-vf", "scale=-2:${spec.height}", "-c:v", "libx264", "-preset", "veryfast",
                "-b:v", spec.bitrate.toString(), "-maxrate", spec.bitrate.toString(),
                "-bufsize", (spec.bitrate * 2).toString(), "-c:a", "aac", "-b:a", "128k",
                "-movflags", "+faststart", output.toString()
            )
            val result = runner.run(command, Duration.ofMinutes(20))
            if (result.exitCode != 0) throw IllegalStateException("FFMPEG_TRANSCODE_FAILED")
            val checksum = sha256(output)
            MediaVariant(spec.name, "$objectKeyPrefix/${spec.name}.mp4", "video/mp4", spec.width, spec.height, spec.bitrate, checksum, java.nio.file.Files.size(output))
        }

        val thumbnail = workspace.resolve("thumbnail.jpg")
        val thumb = runner.run(
            listOf(ffmpegBinary, "-hide_banner", "-loglevel", "error", "-y", "-ss", "00:00:01", "-i", original.toString(), "-frames:v", "1", "-vf", "scale=640:-2", thumbnail.toString()),
            Duration.ofMinutes(2)
        )
        if (thumb.exitCode != 0) throw IllegalStateException("FFMPEG_THUMBNAIL_FAILED")

        return ProcessingResult(metadata, builtVariants, "$objectKeyPrefix/thumbnail.jpg", sha256(thumbnail), java.nio.file.Files.size(thumbnail))
    }

    private fun sha256(path: Path): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        java.nio.file.Files.newInputStream(path).use { input ->
            val buffer = ByteArray(1024 * 64)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private data class VariantSpec(val name: String, val width: Int, val height: Int, val bitrate: Long)
}

/** Small, strict parser for the ffprobe JSON shape used by this pipeline. */
object FfprobeJsonParser {
    fun parse(json: String): MediaMetadata {
        fun number(name: String): Double? = Regex("\\\"$name\\\"\\s*:\\s*\\\"?([0-9.]+)").find(json)?.groupValues?.get(1)?.toDoubleOrNull()
        fun text(name: String): String? = Regex("\\\"$name\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"").find(json)?.groupValues?.get(1)
        val durationMs = ((number("duration") ?: 0.0) * 1000).toLong()
        val width = number("width")?.toInt() ?: 0
        val height = number("height")?.toInt() ?: 0
        val videoCodec = text("codec_name") ?: throw IllegalArgumentException("VIDEO_CODEC_MISSING")
        val audioCodec = Regex("\\\"codec_type\\\"\\s*:\\s*\\\"audio\\\"[\\s\\S]*?\\\"codec_name\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"").find(json)?.groupValues?.get(1)
        val bitrate = number("bit_rate")?.toLong()
        val frameRateText = Regex("\\\"r_frame_rate\\\"\\s*:\\s*\\\"(\\d+)/(\\d+)\\\"").find(json)
        val frameRate = frameRateText?.let { it.groupValues[1].toDouble() / it.groupValues[2].toDouble() }
        require(width > 0 && height > 0 && durationMs > 0) { "INVALID_MEDIA_METADATA" }
        return MediaMetadata(durationMs, width, height, videoCodec, audioCodec, bitrate, frameRate)
    }
}

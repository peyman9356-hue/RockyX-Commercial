package com.rockyx.backend.domain

import kotlinx.serialization.Serializable

@Serializable
enum class ContentStatus { DRAFT, PUBLISHED, ARCHIVED }

@Serializable
data class ContentDocument(
    val contentId: String,
    val locale: String,
    val contentVersion: String,
    val status: ContentStatus,
    val revision: Int,
    val schemaVersion: Int,
    val catalogJson: String,
    val updatedAtEpochMs: Long,
    val publishedAtEpochMs: Long? = null
)

@Serializable
data class ContentRevision(
    val contentId: String,
    val revision: Int,
    val locale: String,
    val contentVersion: String,
    val schemaVersion: Int,
    val catalogJson: String,
    val createdBy: String,
    val createdAtEpochMs: Long
)

@Serializable
data class ContentUpsertRequest(
    val locale: String,
    val contentVersion: String,
    val schemaVersion: Int,
    val catalogJson: String,
    val expectedRevision: Int? = null
)

@Serializable
data class ContentPublishRequest(val expectedRevision: Int)

@Serializable
data class ContentSummary(
    val contentId: String,
    val locale: String,
    val contentVersion: String,
    val status: ContentStatus,
    val revision: Int,
    val schemaVersion: Int,
    val updatedAtEpochMs: Long,
    val publishedAtEpochMs: Long? = null
)

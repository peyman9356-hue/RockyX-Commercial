package com.rockyx.backend.observability

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import org.slf4j.LoggerFactory
import kotlinx.serialization.Serializable

/** Vendor-neutral observability boundary. No PII or raw payloads should cross this API. */
interface Telemetry {
    fun count(name: String, value: Long = 1, tags: Map<String, String> = emptyMap())
    fun timing(name: String, durationMs: Long, tags: Map<String, String> = emptyMap())
    fun event(name: String, tags: Map<String, String> = emptyMap())
}

class InMemoryTelemetry : Telemetry {
    private val logger = LoggerFactory.getLogger("RockyX.Telemetry")
    private val counters = ConcurrentHashMap<String, AtomicLong>()

    override fun count(name: String, value: Long, tags: Map<String, String>) {
        counters.computeIfAbsent(key(name, tags)) { AtomicLong() }.addAndGet(value)
    }

    override fun timing(name: String, durationMs: Long, tags: Map<String, String>) {
        // Keep timing telemetry lightweight for local/dev use; production export belongs behind Telemetry.
        event("timing.$name", tags + ("duration_ms" to durationMs.toString()))
    }

    override fun event(name: String, tags: Map<String, String>) {
        logger.info("telemetry event={} tags={}", name, sanitize(tags))
    }

    fun snapshot(): Map<String, Long> = counters.mapValues { it.value.get() }

    private fun key(name: String, tags: Map<String, String>): String =
        if (tags.isEmpty()) name else name + tags.toSortedMap().entries.joinToString(prefix = "{", postfix = "}") { "${it.key}=${it.value}" }

    private fun sanitize(tags: Map<String, String>): Map<String, String> =
        tags.filterKeys { it.lowercase() !in setOf("email", "phone", "name", "token", "authorization", "payload", "ip") }
}

@Serializable
data class HealthSnapshot(
    val service: String,
    val status: String,
    val version: String,
    val database: String,
    val storage: String
)

package com.rockyx.backend.infra.db

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.flywaydb.core.Flyway
import javax.sql.DataSource

class DatabaseConfig(
    val jdbcUrl: String,
    val username: String,
    val password: String,
    val maximumPoolSize: Int = 10
) {
    companion object {
        fun fromEnvironment(env: Map<String, String> = System.getenv()): DatabaseConfig? {
            val url = env["ROCKYX_DATABASE_URL"] ?: return null
            val username = env["ROCKYX_DATABASE_USER"] ?: return null
            val password = env["ROCKYX_DATABASE_PASSWORD"] ?: return null
            return DatabaseConfig(url, username, password, env["ROCKYX_DATABASE_POOL_SIZE"]?.toIntOrNull() ?: 10)
        }
    }
}

class Database(private val config: DatabaseConfig) : AutoCloseable {
    private val dataSource = HikariDataSource(HikariConfig().apply {
        jdbcUrl = config.jdbcUrl
        username = config.username
        password = config.password
        maximumPoolSize = config.maximumPoolSize
        minimumIdle = 1
        poolName = "rockyx-db"
        connectionTimeout = 10_000
        validationTimeout = 5_000
    })

    fun migrate() {
        Flyway.configure().dataSource(dataSource).locations("classpath:db/migration").load().migrate()
    }

    fun dataSource(): DataSource = dataSource
    override fun close() = dataSource.close()
}

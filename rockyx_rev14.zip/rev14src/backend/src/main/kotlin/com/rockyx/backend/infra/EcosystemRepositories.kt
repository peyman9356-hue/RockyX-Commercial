package com.rockyx.backend.infra

import com.rockyx.backend.domain.*
import java.util.concurrent.ConcurrentHashMap
import kotlinx.serialization.json.Json

interface EcosystemRepository {
    fun listDogs(userId: String): List<DogRecord>
    fun getDog(userId: String, dogId: String): DogRecord?
    fun upsertDog(userId: String, request: DogUpsertRequest): DogRecord
    fun addDogEvent(userId: String, request: DogEventCreateRequest): DogEvent
    fun listDogEvents(userId: String, dogId: String, limit: Int = 100): List<DogEvent>
    fun upsertDevice(userId: String, request: DeviceUpsertRequest): DeviceRecord
    fun listDevices(userId: String, dogId: String? = null): List<DeviceRecord>
    fun createVetAccess(userId: String, request: VetAccessCreateRequest): VetAccessGrant
    fun listVetAccess(userId: String, dogId: String): List<VetAccessGrant>
    fun revokeVetAccess(userId: String, grantId: String): Boolean
    fun getDogForVet(vetSubjectId: String, dogId: String): DogRecord?
    fun addSafetyEvent(userId: String, request: SafetyEventCreateRequest): SafetyEvent
    fun listSafetyEvents(userId: String, dogId: String, limit: Int = 100): List<SafetyEvent>
    fun addAiInsight(userId: String, request: AiInsightCreateRequest): AiInsight
    fun listAiInsights(userId: String, dogId: String, limit: Int = 50): List<AiInsight>
}

class InMemoryEcosystemRepository : EcosystemRepository {
    private val dogs = ConcurrentHashMap<String, DogRecord>()
    private val dogEvents = ConcurrentHashMap<String, DogEvent>()
    private val devices = ConcurrentHashMap<String, DeviceRecord>()
    private val vet = ConcurrentHashMap<String, VetAccessGrant>()
    private val safety = ConcurrentHashMap<String, SafetyEvent>()
    private val insights = ConcurrentHashMap<String, AiInsight>()

    override fun listDogs(userId: String) = dogs.values.filter { it.ownerUserId == userId }.sortedBy { it.createdAtEpochMs }
    override fun getDog(userId: String, dogId: String) = dogs[dogId]?.takeIf { it.ownerUserId == userId }
    override fun upsertDog(userId: String, request: DogUpsertRequest): DogRecord {
        EcosystemValidation.id(request.dogId)
        EcosystemValidation.name(request.name)
        EcosystemValidation.optionalText(request.breed, 80)
        EcosystemValidation.optionalEpoch(request.dateOfBirthEpochMs)
        EcosystemValidation.optionalText(request.sex, 32)
        EcosystemValidation.weight(request.weightGrams)
        EcosystemValidation.activity(request.activityBaseline)
        return synchronized(dogs) {
            val old = dogs[request.dogId]
            if (old != null) require(old.ownerUserId == userId)
            if (request.expectedProfileVersion != null) require(old == null || old.profileVersion == request.expectedProfileVersion)
            val now = System.currentTimeMillis()
            val record = DogRecord(request.dogId, userId, request.name.trim(), request.breed?.trim()?.takeIf { it.isNotBlank() }, request.dateOfBirthEpochMs, request.sex?.trim()?.takeIf { it.isNotBlank() }, request.weightGrams, request.activityBaseline, (old?.profileVersion ?: 0) + 1, old?.createdAtEpochMs ?: now, now)
            dogs[record.dogId] = record
            record
        }
    }
    override fun addDogEvent(userId: String, request: DogEventCreateRequest): DogEvent {
        EcosystemValidation.id(request.eventId)
        EcosystemValidation.id(request.dogId)
        EcosystemValidation.type(request.eventType)
        EcosystemValidation.json(request.payloadJson)
        EcosystemValidation.epoch(request.occurredAtEpochMs)
        require(getDog(userId, request.dogId) != null)
        val now = System.currentTimeMillis()
        val event = DogEvent(request.eventId, request.dogId, userId, request.eventType.trim(), request.payloadJson, request.occurredAtEpochMs, now)
        return synchronized(dogEvents) {
            val existing = dogEvents[event.eventId]
            if (existing != null) {
                require(existing.ownerUserId == userId && existing.dogId == request.dogId)
                existing
            } else { dogEvents[event.eventId] = event; event }
        }
    }
    override fun listDogEvents(userId: String, dogId: String, limit: Int) = dogEvents.values.filter { it.ownerUserId == userId && it.dogId == dogId }.sortedByDescending { it.occurredAtEpochMs }.take(limit.coerceIn(1, 200))
    override fun upsertDevice(userId: String, request: DeviceUpsertRequest): DeviceRecord {
        EcosystemValidation.id(request.deviceId)
        request.dogId?.let { EcosystemValidation.id(it); require(getDog(userId, it) != null) }
        EcosystemValidation.type(request.deviceType)
        EcosystemValidation.optionalText(request.hardwareRevision, 64)
        EcosystemValidation.optionalText(request.firmwareVersion, 64)
        EcosystemValidation.battery(request.batteryPercent)
        val now = System.currentTimeMillis()
        return synchronized(devices) {
            val old = devices[request.deviceId]
            require(old == null || old.ownerUserId == userId)
            DeviceRecord(request.deviceId, userId, request.dogId, request.deviceType, request.hardwareRevision, request.firmwareVersion, old?.status ?: "ACTIVE", old?.lastSeenAtEpochMs, request.batteryPercent ?: old?.batteryPercent, old?.createdAtEpochMs ?: now, now).also { devices[it.deviceId] = it }
        }
    }
    override fun listDevices(userId: String, dogId: String?) = devices.values.filter { it.ownerUserId == userId && (dogId == null || it.dogId == dogId) }
    override fun createVetAccess(userId: String, request: VetAccessCreateRequest): VetAccessGrant {
        EcosystemValidation.id(request.grantId)
        EcosystemValidation.id(request.dogId)
        EcosystemValidation.id(request.vetSubjectId)
        require(getDog(userId, request.dogId) != null)
        require(request.accessLevel in setOf("VIEW", "VIEW_HEALTH", "EDIT"))
        EcosystemValidation.optionalEpoch(request.expiresAtEpochMs)
        require(request.expiresAtEpochMs == null || request.expiresAtEpochMs > System.currentTimeMillis())
        val now = System.currentTimeMillis()
        val grant = VetAccessGrant(request.grantId, request.dogId, userId, request.vetSubjectId, request.accessLevel, request.expiresAtEpochMs, false, now, now)
        return synchronized(vet) {
            val existing = vet[grant.grantId]
            if (existing != null) { require(existing.ownerUserId == userId && existing.dogId == request.dogId); existing }
            else { vet[grant.grantId] = grant; grant }
        }
    }
    override fun listVetAccess(userId: String, dogId: String) = vet.values.filter { it.ownerUserId == userId && it.dogId == dogId && !it.revoked && (it.expiresAtEpochMs == null || it.expiresAtEpochMs > System.currentTimeMillis()) }
    override fun revokeVetAccess(userId: String, grantId: String): Boolean = synchronized(vet) { val old = vet[grantId] ?: return@synchronized false; if (old.ownerUserId != userId) return@synchronized false; vet[grantId] = old.copy(revoked = true, updatedAtEpochMs = System.currentTimeMillis()); true }
    override fun getDogForVet(vetSubjectId: String, dogId: String): DogRecord? {
        val grant = vet.values.firstOrNull { it.vetSubjectId == vetSubjectId && it.dogId == dogId && !it.revoked && (it.expiresAtEpochMs == null || it.expiresAtEpochMs > System.currentTimeMillis()) } ?: return null
        return dogs[grant.dogId]
    }
    override fun addSafetyEvent(userId: String, request: SafetyEventCreateRequest): SafetyEvent {
        EcosystemValidation.id(request.safetyEventId)
        EcosystemValidation.id(request.dogId)
        EcosystemValidation.type(request.eventType)
        EcosystemValidation.type(request.status)
        EcosystemValidation.latitudeE6(request.latitudeE6)
        EcosystemValidation.longitudeE6(request.longitudeE6)
        EcosystemValidation.accuracy(request.accuracyMeters)
        EcosystemValidation.epoch(request.occurredAtEpochMs)
        require(getDog(userId, request.dogId) != null)
        require((request.latitudeE6 == null) == (request.longitudeE6 == null))
        val now = System.currentTimeMillis()
        val event = SafetyEvent(request.safetyEventId, request.dogId, userId, request.eventType.trim(), request.status.trim(), request.latitudeE6, request.longitudeE6, request.accuracyMeters, request.occurredAtEpochMs, now)
        return synchronized(safety) {
            val existing = safety[event.safetyEventId]
            if (existing != null) { require(existing.ownerUserId == userId && existing.dogId == request.dogId); existing }
            else { safety[event.safetyEventId] = event; event }
        }
    }
    override fun listSafetyEvents(userId: String, dogId: String, limit: Int) = safety.values.filter { it.ownerUserId == userId && it.dogId == dogId }.sortedByDescending { it.occurredAtEpochMs }.take(limit.coerceIn(1, 200))
    override fun addAiInsight(userId: String, request: AiInsightCreateRequest): AiInsight {
        EcosystemValidation.id(request.insightId)
        EcosystemValidation.id(request.dogId)
        EcosystemValidation.type(request.kind)
        EcosystemValidation.json(request.evidenceJson)
        EcosystemValidation.json(request.inferenceJson)
        EcosystemValidation.json(request.recommendationJson)
        EcosystemValidation.confidence(request.confidence)
        require(getDog(userId, request.dogId) != null)
        val now = System.currentTimeMillis()
        val insight = AiInsight(request.insightId, request.dogId, userId, request.kind.trim(), request.evidenceJson, request.inferenceJson, request.recommendationJson, request.confidence, now)
        return synchronized(insights) {
            val existing = insights[insight.insightId]
            if (existing != null) { require(existing.ownerUserId == userId && existing.dogId == request.dogId); existing }
            else { insights[insight.insightId] = insight; insight }
        }
    }
    override fun listAiInsights(userId: String, dogId: String, limit: Int) = insights.values.filter { it.ownerUserId == userId && it.dogId == dogId }.sortedByDescending { it.createdAtEpochMs }.take(limit.coerceIn(1, 100))
}

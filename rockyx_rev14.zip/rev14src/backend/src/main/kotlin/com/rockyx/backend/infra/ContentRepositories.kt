package com.rockyx.backend.infra

import com.rockyx.backend.domain.*
import java.util.concurrent.ConcurrentHashMap
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive

interface ContentRepository {
    fun list(locale: String? = null): List<ContentSummary>
    fun get(contentId: String): ContentDocument?
    fun getPublished(locale: String): ContentDocument?
    fun upsert(contentId: String, request: ContentUpsertRequest, actorUserId: String): ContentDocument
    fun publish(contentId: String, expectedRevision: Int, actorUserId: String): ContentDocument
}

class ContentConflictException(message: String) : IllegalStateException(message)
class ContentValidationException(message: String) : IllegalArgumentException(message)

object ContentDocumentValidator {
    fun validate(request: ContentUpsertRequest) {
        require(request.locale.matches(Regex("^[a-z]{2}(?:-[A-Z]{2})?$"))) { "Invalid locale" }
        require(request.contentVersion.length in 1..64 && request.contentVersion.matches(Regex("^[A-Za-z0-9._-]+$"))) { "Invalid content version" }
        require(request.schemaVersion > 0) { "Invalid schema version" }
        require(request.catalogJson.toByteArray(Charsets.UTF_8).size <= 2_000_000) { "Content document is too large" }
        val root = try { Json.parseToJsonElement(request.catalogJson).jsonObject } catch (_: Exception) { throw ContentValidationException("Catalog must be valid JSON") }
        val courses = root["courses"]?.jsonArray ?: throw ContentValidationException("Catalog must contain courses")
        val ids = mutableSetOf<String>()
        courses.forEach { course ->
            val id = course.jsonObject["id"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() } ?: throw ContentValidationException("Course id is required")
            if (!ids.add(id)) throw ContentValidationException("Duplicate course id: $id")
        }
    }
}

class InMemoryContentRepository : ContentRepository {
    private val docs = ConcurrentHashMap<String, ContentDocument>()
    private val revisions = ConcurrentHashMap<String, MutableList<ContentRevision>>()

    override fun list(locale: String?): List<ContentSummary> = docs.values
        .filter { locale == null || it.locale == locale }
        .sortedWith(compareBy<ContentDocument> { it.locale }.thenBy { it.contentId })
        .map { it.summary() }

    override fun get(contentId: String): ContentDocument? = docs[contentId]

    override fun getPublished(locale: String): ContentDocument? = docs.values
        .filter { it.locale == locale && it.status == ContentStatus.PUBLISHED }
        .maxByOrNull { it.publishedAtEpochMs ?: 0L }

    override fun upsert(contentId: String, request: ContentUpsertRequest, actorUserId: String): ContentDocument {
        ContentDocumentValidator.validate(request)
        synchronized(docs) {
            val current = docs[contentId]
            if (request.expectedRevision != null && current?.revision != request.expectedRevision) throw ContentConflictException("Revision conflict")
            val nextRevision = (current?.revision ?: 0) + 1
            val now = System.currentTimeMillis()
            val doc = ContentDocument(contentId, request.locale, request.contentVersion, ContentStatus.DRAFT, nextRevision, request.schemaVersion, request.catalogJson, now, current?.publishedAtEpochMs)
            docs[contentId] = doc
            revisions.computeIfAbsent(contentId) { mutableListOf() }.add(ContentRevision(contentId, nextRevision, request.locale, request.contentVersion, request.schemaVersion, request.catalogJson, actorUserId, now))
            return doc
        }
    }

    override fun publish(contentId: String, expectedRevision: Int, actorUserId: String): ContentDocument {
        synchronized(docs) {
            val current = docs[contentId] ?: throw NoSuchElementException("Content not found")
            if (current.revision != expectedRevision) throw ContentConflictException("Revision conflict")
            val now = System.currentTimeMillis()
            val published = current.copy(status = ContentStatus.PUBLISHED, publishedAtEpochMs = now, updatedAtEpochMs = now)
            docs[contentId] = published
            return published
        }
    }

    private fun ContentDocument.summary() = ContentSummary(contentId, locale, contentVersion, status, revision, schemaVersion, updatedAtEpochMs, publishedAtEpochMs)
}

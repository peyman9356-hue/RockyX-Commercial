package com.rockyx.backend.ai

import kotlinx.serialization.Serializable

@Serializable
data class AiLessonSignal(
    val lessonId: String,
    val goalTags: List<String> = emptyList(),
    val behaviorTags: List<String> = emptyList(),
    val recommendedLevels: List<String> = emptyList(),
    val durationMinutes: Int = 0,
    val completed: Boolean = false,
    val inProgress: Boolean = false,
    val prerequisitesMet: Boolean = true
)

@Serializable
data class AiRecommendationRequest(
    val dogProfileVersion: Int,
    val level: String,
    val goals: List<String> = emptyList(),
    val behaviors: List<String> = emptyList(),
    val lessons: List<AiLessonSignal>,
    val limit: Int = 3
)

@Serializable
data class AiRecommendation(
    val lessonId: String,
    val score: Int,
    val confidence: Int,
    val reasons: List<String>,
    val safetyNotes: List<String> = emptyList()
)

interface PersonalizationProvider {
    fun recommend(request: AiRecommendationRequest): List<AiRecommendation>
}

/** Deterministic server fallback. It is intentionally not presented as an ML model. */
class LocalPersonalizationProvider : PersonalizationProvider {
    override fun recommend(request: AiRecommendationRequest): List<AiRecommendation> {
        require(request.limit in 1..20)
        require(request.dogProfileVersion > 0)
        require(request.level.length <= 64)
        require(request.goals.size <= 50 && request.behaviors.size <= 50 && request.lessons.size <= 5000)
        val goals = request.goals.map { it.trim().lowercase() }.filter { it.isNotBlank() }.toSet()
        val behaviors = request.behaviors.map { it.trim().lowercase() }.filter { it.isNotBlank() }.toSet()
        return request.lessons.asSequence().filter { !it.completed && it.prerequisitesMet }
            .map { lesson ->
                var score = 0
                val reasons = mutableListOf<String>()
                val gh = lesson.goalTags.count { it.trim().lowercase() in goals }
                val bh = lesson.behaviorTags.count { it.trim().lowercase() in behaviors }
                val level = lesson.recommendedLevels.any { it.equals(request.level, true) }
                if (gh > 0) { score += (gh * 35).coerceAtMost(70); reasons += "goal_match" }
                if (bh > 0) { score += (bh * 25).coerceAtMost(50); reasons += "behavior_match" }
                if (level) { score += 25; reasons += "level_match" }
                if (lesson.inProgress) { score += 40; reasons += "continue_in_progress" }
                score += (20 - lesson.durationMinutes.coerceAtMost(20)).coerceAtLeast(0)
                val evidence = listOf(gh > 0, bh > 0, level, lesson.inProgress).count { it }
                AiRecommendation(lesson.lessonId, score, (35 + evidence * 15).coerceAtMost(95), reasons.ifEmpty { listOf("general_next_step") })
            }.sortedWith(compareByDescending<AiRecommendation> { it.score }.thenByDescending { it.confidence }.thenBy { it.lessonId })
            .take(request.limit).toList()
    }
}

object PersonalizationSafetyPolicy {
    fun validate(request: AiRecommendationRequest) {
        require(request.dogProfileVersion > 0)
        require(request.limit in 1..20)
        require(request.level.length <= 64)
        require(request.goals.size <= 50 && request.behaviors.size <= 50)
        require(request.lessons.size <= 5000)
        request.lessons.forEach { require(it.lessonId.length in 1..128 && it.durationMinutes in 0..1440) }
    }
}

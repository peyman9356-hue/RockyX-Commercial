package com.rockyx.backend.media

import kotlinx.serialization.Serializable

@Serializable
data class MediaScanResult(
    val malware: String,
    val mediaValidation: String,
    val moderation: String
)

interface MediaSecurityScanner {
    fun scan(asset: MediaAsset): MediaScanResult
}

/** Fail-closed production boundary. No media is approved until a real scanner is configured. */
class UnconfiguredMediaSecurityScanner : MediaSecurityScanner {
    override fun scan(asset: MediaAsset): MediaScanResult = MediaScanResult("NOT_SCANNED", "NOT_VALIDATED", "NOT_REVIEWED")
}

interface MediaProcessingQueue {
    fun enqueue(mediaId: String): Boolean
}

class UnconfiguredMediaProcessingQueue : MediaProcessingQueue {
    override fun enqueue(mediaId: String): Boolean = false
}

object MediaSecurityPolicy {
    private val allowedTypes = setOf("video/mp4", "video/webm", "video/quicktime")
    const val MAX_BYTES: Long = 500L * 1024 * 1024

    fun validateUpload(contentType: String, sizeBytes: Long, checksum: String): String? {
        if (contentType.lowercase() !in allowedTypes) return "UNSUPPORTED_MEDIA_TYPE"
        if (sizeBytes <= 0 || sizeBytes > MAX_BYTES) return "INVALID_MEDIA_SIZE"
        if (!checksum.matches(Regex("[A-Fa-f0-9]{64}"))) return "INVALID_CHECKSUM"
        return null
    }
}

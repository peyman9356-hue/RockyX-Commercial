package com.rockyx.backend.auth

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPrivateCrtKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.time.Instant
import java.util.Base64
import java.util.Date
import java.util.UUID
import java.security.MessageDigest
import com.rockyx.backend.infra.AuthSessionRepository
import com.rockyx.backend.infra.AuthSessionRecord

/** Short-lived first-party access token + rotating opaque refresh token session. */
data class SessionTokens(val accessToken: String, val refreshToken: String, val expiresAtEpochMs: Long, val userId: String)

data class SessionSecurityConfig(
    val issuer: String,
    val audience: String,
    val keyId: String,
    val privateKey: RSAPrivateCrtKey,
    val accessTtlSeconds: Long = 900,
    val refreshTtlSeconds: Long = 60L * 60 * 24 * 30
) {
    companion object {
        fun fromEnvironment(env: Map<String, String> = System.getenv()): SessionSecurityConfig? {
            val issuer = env["ROCKYX_SESSION_ISSUER"]?.trim().orEmpty()
            val audience = env["ROCKYX_SESSION_AUDIENCE"]?.trim().orEmpty()
            val keyId = env["ROCKYX_SESSION_KEY_ID"]?.trim().orEmpty()
            val pem = env["ROCKYX_SESSION_PRIVATE_KEY_PKCS8_B64"]?.trim().orEmpty()
            if (issuer.isBlank() || audience.isBlank() || keyId.isBlank() || pem.isBlank()) return null
            require(keyId.length <= 128) { "ROCKYX_SESSION_KEY_ID is too long" }
            val bytes = Base64.getDecoder().decode(pem)
            val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(bytes)) as RSAPrivateCrtKey
            return SessionSecurityConfig(issuer, audience, keyId, key,
                env["ROCKYX_SESSION_ACCESS_TTL_SECONDS"]?.toLongOrNull()?.coerceIn(60, 3600) ?: 900,
                env["ROCKYX_SESSION_REFRESH_TTL_SECONDS"]?.toLongOrNull()?.coerceIn(3600, 90L * 24 * 3600) ?: 60L * 60 * 24 * 30)
        }
    }
}

class SessionManager(private val config: SessionSecurityConfig, private val sessions: AuthSessionRepository) {
    fun issue(userId: String, provider: String, scopes: Set<String>, roles: Set<String>, now: Long = System.currentTimeMillis()): SessionTokens {
        require(userId.isNotBlank() && userId.length <= 256)
        val sessionId = UUID.randomUUID().toString()
        val accessExp = now + config.accessTtlSeconds * 1000
        val refreshExp = now + config.refreshTtlSeconds * 1000
        val refresh = randomToken()
        val record = AuthSessionRecord(sessionId, userId, provider, hash(refresh), refreshExp, false, now, scopes = scopes, roles = roles)
        sessions.create(record)
        val access = JWT.create().withKeyId(config.keyId).withIssuer(config.issuer).withAudience(config.audience)
            .withSubject(userId).withClaim("sid", sessionId).withClaim("scope", scopes.joinToString(" "))
            .withArrayClaim("roles", roles.toTypedArray()).withIssuedAt(Date(now)).withExpiresAt(Date(accessExp))
            .sign(Algorithm.RSA256(config.privateKey))
        return SessionTokens(access, refresh, accessExp, userId)
    }

    fun rotate(refreshToken: String, now: Long = System.currentTimeMillis()): SessionTokens? {
        if (refreshToken.length !in 32..512) return null
        val hash = hash(refreshToken)
        val current = sessions.consumeActiveByRefreshHash(hash, now) ?: return null
        return issue(current.userId, current.provider, current.scopes, current.roles, now)
    }

    fun revoke(refreshToken: String, now: Long = System.currentTimeMillis()): Boolean =
        sessions.findActiveByRefreshHash(hash(refreshToken), now)?.let { sessions.revoke(it.sessionId, now); true } ?: false

    private fun randomToken(): String = Base64.getUrlEncoder().withoutPadding().encodeToString(java.security.SecureRandom().generateSeed(48))
    companion object {
        fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}

class SessionAccessTokenVerifier(
    private val config: SessionSecurityConfig,
    private val publicKey: RSAPublicKey,
    private val sessions: AuthSessionRepository
) : AccessTokenVerifier {
    override suspend fun verify(bearerToken: String): AuthenticatedPrincipal? {
        return try {
        val decoded = JWT.decode(bearerToken)
        if (decoded.algorithm != "RS256" || decoded.keyId != config.keyId) return null
        val jwt = JWT.require(Algorithm.RSA256(publicKey, null)).withIssuer(config.issuer).withAudience(config.audience).build().verify(bearerToken)
        val userId = jwt.subject?.takeIf { it.isNotBlank() } ?: return null
        val sessionId = jwt.getClaim("sid").asString()?.takeIf { it.isNotBlank() } ?: return null
        if (!sessions.isActive(sessionId, System.currentTimeMillis())) return null
        val scopes = jwt.getClaim("scope").asString()?.split(' ')?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
        val roles = jwt.getClaim("roles").asList(String::class.java)?.toSet() ?: emptySet()
        AuthenticatedPrincipal(userId, config.issuer, scopes, roles)
        } catch (_: Exception) { null }
    }
}

fun SessionSecurityConfig.publicKey(): RSAPublicKey = java.security.KeyFactory.getInstance("RSA").generatePublic(java.security.spec.RSAPublicKeySpec(privateKey.modulus, privateKey.publicExponent)) as RSAPublicKey

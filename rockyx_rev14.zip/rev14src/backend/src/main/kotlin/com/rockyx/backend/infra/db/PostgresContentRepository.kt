package com.rockyx.backend.infra.db

import com.rockyx.backend.domain.*
import com.rockyx.backend.infra.*
import java.sql.Connection
import java.time.OffsetDateTime
import java.time.ZoneOffset
import javax.sql.DataSource

class PostgresContentRepository(private val ds: DataSource) : ContentRepository {
    override fun list(locale: String?): List<ContentSummary> = ds.connection.use { c ->
        val sql = if (locale == null) "SELECT content_id,locale,content_version,status,revision,schema_version,updated_at,published_at FROM content_documents ORDER BY locale,content_id" else "SELECT content_id,locale,content_version,status,revision,schema_version,updated_at,published_at FROM content_documents WHERE locale=? ORDER BY content_id"
        c.prepareStatement(sql).use { ps ->
            if (locale != null) ps.setString(1, locale)
            ps.executeQuery().use { rs ->
                buildList { while (rs.next()) add(ContentSummary(rs.getString(1),rs.getString(2),rs.getString(3),ContentStatus.valueOf(rs.getString(4)),rs.getInt(5),rs.getInt(6),epoch(rs.getObject(7, OffsetDateTime::class.java)),rs.getObject(8, OffsetDateTime::class.java)?.toInstant()?.toEpochMilli())) }
            }
        }
    }

    override fun get(contentId: String): ContentDocument? = find(contentId, null)
    override fun getPublished(locale: String): ContentDocument? = ds.connection.use { c ->
        c.prepareStatement("SELECT content_id,locale,content_version,status,revision,schema_version,catalog_json,updated_at,published_at FROM content_documents WHERE locale=? AND status='PUBLISHED' ORDER BY published_at DESC NULLS LAST LIMIT 1").use { ps ->
            ps.setString(1, locale); ps.executeQuery().use { rs -> if (rs.next()) map(rs) else null }
        }
    }

    override fun upsert(contentId: String, request: ContentUpsertRequest, actorUserId: String): ContentDocument {
        ContentDocumentValidator.validate(request)
        return ds.connection.use { c ->
            c.autoCommit = false
            try {
                val currentRevision = c.prepareStatement("SELECT revision FROM content_documents WHERE content_id=? FOR UPDATE").use { ps -> ps.setString(1, contentId); ps.executeQuery().use { rs -> if (rs.next()) rs.getInt(1) else null } }
                if (request.expectedRevision != null && currentRevision != request.expectedRevision) throw ContentConflictException("Revision conflict")
                val next = (currentRevision ?: 0) + 1
                val now = OffsetDateTime.now(ZoneOffset.UTC)
                if (currentRevision == null) {
                    c.prepareStatement("INSERT INTO content_documents(content_id,locale,content_version,status,revision,schema_version,catalog_json,updated_at) VALUES (?,?,?,'DRAFT',?,?,?::jsonb,?)").use { ps ->
                        ps.setString(1,contentId); ps.setString(2,request.locale); ps.setString(3,request.contentVersion); ps.setInt(4,next); ps.setInt(5,request.schemaVersion); ps.setString(6,request.catalogJson); ps.setObject(7,now); ps.executeUpdate()
                    }
                } else {
                    c.prepareStatement("UPDATE content_documents SET locale=?,content_version=?,status='DRAFT',revision=?,schema_version=?,catalog_json=?::jsonb,updated_at=? WHERE content_id=?").use { ps ->
                        ps.setString(1,request.locale); ps.setString(2,request.contentVersion); ps.setInt(3,next); ps.setInt(4,request.schemaVersion); ps.setString(5,request.catalogJson); ps.setObject(6,now); ps.setString(7,contentId); ps.executeUpdate()
                    }
                }
                c.prepareStatement("INSERT INTO content_revisions(content_id,revision,locale,content_version,schema_version,catalog_json,created_by) VALUES (?,?,?,?,?,?::jsonb,?)").use { ps ->
                    ps.setString(1,contentId); ps.setInt(2,next); ps.setString(3,request.locale); ps.setString(4,request.contentVersion); ps.setInt(5,request.schemaVersion); ps.setString(6,request.catalogJson); ps.setString(7,actorUserId); ps.executeUpdate()
                }
                c.prepareStatement("INSERT INTO content_audit_events(content_id,actor_user_id,action,revision) VALUES (?,?, 'UPSERT',?)").use { ps -> ps.setString(1,contentId); ps.setString(2,actorUserId); ps.setInt(3,next); ps.executeUpdate() }
                val doc = find(c, contentId) ?: error("Content was not persisted")
                c.commit(); doc
            } catch (t: Throwable) { c.rollback(); throw t }
        }
    }

    override fun publish(contentId: String, expectedRevision: Int, actorUserId: String): ContentDocument = ds.connection.use { c ->
        c.autoCommit = false
        try {
            c.prepareStatement("SELECT revision,status FROM content_documents WHERE content_id=? FOR UPDATE").use { ps ->
                ps.setString(1,contentId); ps.executeQuery().use { rs ->
                    if (!rs.next()) throw NoSuchElementException("Content not found")
                    if (rs.getInt(1) != expectedRevision) throw ContentConflictException("Revision conflict")
                }
            }
            val now = OffsetDateTime.now(ZoneOffset.UTC)
            c.prepareStatement("UPDATE content_documents SET status='PUBLISHED',published_at=?,updated_at=? WHERE content_id=?").use { ps -> ps.setObject(1,now); ps.setObject(2,now); ps.setString(3,contentId); ps.executeUpdate() }
            c.prepareStatement("INSERT INTO content_audit_events(content_id,actor_user_id,action,revision) VALUES (?,?, 'PUBLISH',?)").use { ps -> ps.setString(1,contentId); ps.setString(2,actorUserId); ps.setInt(3,expectedRevision); ps.executeUpdate() }
            val doc = find(c, contentId) ?: error("Content was not persisted")
            c.commit(); doc
        } catch (t: Throwable) { c.rollback(); throw t }
    }

    private fun find(contentId: String, unused: String?): ContentDocument? = ds.connection.use { c -> find(c, contentId) }
    private fun find(c: Connection, contentId: String): ContentDocument? = c.prepareStatement("SELECT content_id,locale,content_version,status,revision,schema_version,catalog_json,updated_at,published_at FROM content_documents WHERE content_id=?").use { ps -> ps.setString(1,contentId); ps.executeQuery().use { rs -> if (rs.next()) map(rs) else null } }
    private fun map(rs: java.sql.ResultSet) = ContentDocument(rs.getString(1),rs.getString(2),rs.getString(3),ContentStatus.valueOf(rs.getString(4)),rs.getInt(5),rs.getInt(6),rs.getString(7),epoch(rs.getObject(8, OffsetDateTime::class.java)),rs.getObject(9, OffsetDateTime::class.java)?.toInstant()?.toEpochMilli())
    private fun epoch(value: OffsetDateTime) = value.toInstant().toEpochMilli()
}

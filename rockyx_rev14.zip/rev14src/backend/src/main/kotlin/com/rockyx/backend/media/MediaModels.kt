package com.rockyx.backend.media

import kotlinx.serialization.Serializable

@Serializable
data class MediaUploadIntentRequest(
    val submissionId: String,
    val contentType: String,
    val sizeBytes: Long,
    val checksum: String
)

@Serializable
data class MediaUploadIntentResponse(
    val mediaId: String,
    val objectKey: String,
    val uploadUrl: String?,
    val expiresAtEpochMs: Long,
    val status: String,
    val requiredHeaders: Map<String, String> = emptyMap()
)

@Serializable
data class MediaCompleteRequest(
    val mediaId: String,
    val objectKey: String,
    val checksum: String
)

@Serializable
data class MediaSecurityStatus(
    val mediaId: String,
    val state: String,
    val malwareScan: String,
    val mediaValidation: String,
    val moderation: String,
    val updatedAtEpochMs: Long
)

@Serializable
data class MediaAsset(
    val mediaId: String,
    val userId: String,
    val submissionId: String,
    val objectKey: String,
    val contentType: String,
    val sizeBytes: Long,
    val checksum: String,
    val state: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long
)

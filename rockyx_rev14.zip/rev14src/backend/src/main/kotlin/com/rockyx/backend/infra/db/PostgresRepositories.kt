package com.rockyx.backend.infra.db

import com.rockyx.backend.domain.*
import com.rockyx.backend.infra.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.sql.Connection
import java.sql.ResultSet
import java.sql.SQLException
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneOffset
import javax.sql.DataSource

private val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }
private fun ResultSet.epochMs(column: String): Long = getObject(column, OffsetDateTime::class.java).toInstant().toEpochMilli()

class PostgresIdempotencyRepository(private val ds: DataSource) : IdempotencyRepository {
    override fun get(userId: String, key: String): String? = ds.connection.use { c ->
        c.prepareStatement("SELECT response_json::text FROM idempotency_keys WHERE user_id=? AND key=?").use { ps ->
            ps.setString(1, userId); ps.setString(2, key)
            ps.executeQuery().use { rs -> if (rs.next()) rs.getString(1) else null }
        }
    }

    override fun put(userId: String, key: String, responseJson: String) {
        ds.connection.use { c ->
            c.prepareStatement("INSERT INTO idempotency_keys(user_id,key,response_json) VALUES (?, ?, ?::jsonb) ON CONFLICT (user_id,key) DO NOTHING").use { ps ->
                ps.setString(1, userId); ps.setString(2, key); ps.setString(3, responseJson); ps.executeUpdate()
            }
        }
    }
}

class PostgresAccountRepository(private val ds: DataSource) : AccountRepository {
    override fun getOrCreate(userId: String): AccountResponse = ds.connection.use { c ->
        c.autoCommit = false
        try {
            c.prepareStatement("INSERT INTO accounts(user_id) VALUES (?) ON CONFLICT (user_id) DO NOTHING").use { ps -> ps.setString(1, userId); ps.executeUpdate() }
            c.prepareStatement("SELECT user_id, created_at, account_version FROM accounts WHERE user_id=?").use { ps ->
                ps.setString(1, userId)
                ps.executeQuery().use { rs ->
                    if (!rs.next()) error("Account was not persisted")
                    val response = AccountResponse(rs.getString("user_id"), rs.epochMs("created_at"), rs.getInt("account_version"))
                    c.commit(); response
                }
            }
        } catch (t: Throwable) { c.rollback(); throw t }
    }
}

class PostgresSyncRepository(private val ds: DataSource) : SyncRepository {
    override fun accept(userId: String, request: SyncOperationRequest): SyncOperationResponse = ds.connection.use { c ->
        c.autoCommit = false
        try {
            ensureAccount(c, userId)
            c.prepareStatement("""
                INSERT INTO sync_operations(operation_id,user_id,entity_type,entity_id,payload_version,payload_json,client_changed_at)
                VALUES (?, ?, ?, ?, ?, ?::jsonb, ?)
                ON CONFLICT (operation_id) DO NOTHING
            """.trimIndent()).use { ps ->
                ps.setString(1, request.operationId); ps.setString(2, userId); ps.setString(3, request.entityType); ps.setString(4, request.entityId)
                ps.setInt(5, request.payloadVersion); ps.setString(6, request.payloadJson)
                ps.setObject(7, OffsetDateTime.ofInstant(Instant.ofEpochMilli(request.clientChangedAtEpochMs), ZoneOffset.UTC))
                ps.executeUpdate()
            }
            val acceptedAt = c.prepareStatement("SELECT server_accepted_at FROM sync_operations WHERE operation_id=? AND user_id=?").use { ps ->
                ps.setString(1, request.operationId); ps.setString(2, userId)
                ps.executeQuery().use { rs -> if (rs.next()) rs.getObject(1, OffsetDateTime::class.java).toInstant().toEpochMilli() else error("Sync operation missing") }
            }
            c.commit(); SyncOperationResponse(request.operationId, "ACCEPTED", acceptedAt)
        } catch (t: Throwable) { c.rollback(); throw t }
    }
}

class PostgresSubmissionRepository(private val ds: DataSource) : SubmissionRepository {
    override fun create(userId: String, request: SubmissionCreateRequest): SubmissionResponse = ds.connection.use { c ->
        c.autoCommit = false
        try {
            ensureAccount(c, userId)
            require(request.visibility in setOf("PRIVATE", "UNLISTED", "PUBLIC")) { "Invalid visibility" }
            require(request.consentVersion > 0) { "Consent version is required" }
            c.prepareStatement("""
                INSERT INTO submissions(submission_id,user_id,mission_id,state,visibility,consent_version,media_checksum)
                VALUES (?, ?, ?, 'PENDING_UPLOAD', ?, ?, ?)
                ON CONFLICT (submission_id) DO NOTHING
            """.trimIndent()).use { ps ->
                ps.setString(1, request.submissionId); ps.setString(2, userId); ps.setString(3, request.missionId)
                ps.setString(4, request.visibility); ps.setInt(5, request.consentVersion); ps.setString(6, request.mediaChecksum); ps.executeUpdate()
            }
            c.prepareStatement("SELECT submission_id,user_id,mission_id,state,visibility,server_updated_at FROM submissions WHERE submission_id=? AND user_id=?").use { ps ->
                ps.setString(1, request.submissionId); ps.setString(2, userId)
                ps.executeQuery().use { rs ->
                    if (!rs.next()) error("Submission was not persisted")
                    val response = SubmissionResponse(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.epochMs("server_updated_at"))
                    c.commit(); response
                }
            }
        } catch (t: Throwable) { c.rollback(); throw t }
    }
    override fun get(userId: String, submissionId: String): SubmissionResponse? = ds.connection.use { c ->
        c.prepareStatement("SELECT submission_id,user_id,mission_id,state,visibility,server_updated_at FROM submissions WHERE submission_id=? AND user_id=?").use { ps ->
            ps.setString(1, submissionId); ps.setString(2, userId)
            ps.executeQuery().use { rs -> if (rs.next()) SubmissionResponse(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.epochMs("server_updated_at")) else null }
        }
    }

}

private fun ensureAccount(c: Connection, userId: String) {
    c.prepareStatement("INSERT INTO accounts(user_id) VALUES (?) ON CONFLICT (user_id) DO NOTHING").use { ps -> ps.setString(1, userId); ps.executeUpdate() }
}

class PostgresAuthSessionRepository(private val ds: javax.sql.DataSource) : AuthSessionRepository {
    override fun create(record: AuthSessionRecord) { ds.connection.use { c ->
        c.prepareStatement("INSERT INTO auth_sessions(session_id,user_id,provider,refresh_token_hash,expires_at,revoked,created_at,scopes,roles) VALUES (?,?,?,?,to_timestamp(?/1000.0),false,to_timestamp(?/1000.0),?,?)").use { ps ->
            ps.setString(1, record.sessionId); ps.setString(2, record.userId); ps.setString(3, record.provider); ps.setString(4, record.refreshTokenHash)
            ps.setLong(5, record.expiresAtEpochMs); ps.setLong(6, record.createdAtEpochMs); ps.setString(7, record.scopes.joinToString(" ")); ps.setString(8, record.roles.joinToString(" ")); ps.executeUpdate()
        }
    }
    }
    override fun findActiveByRefreshHash(hash: String, nowEpochMs: Long): AuthSessionRecord? = ds.connection.use { c ->
        c.prepareStatement("SELECT session_id,user_id,provider,refresh_token_hash,extract(epoch from expires_at)*1000,revoked,extract(epoch from created_at)*1000,scopes,roles FROM auth_sessions WHERE refresh_token_hash=? AND revoked=false AND expires_at>now() LIMIT 1").use { ps ->
            ps.setString(1, hash); ps.executeQuery().use { rs ->
                if (!rs.next()) null else toRecord(rs)
            }
        }
    }
    override fun consumeActiveByRefreshHash(hash: String, nowEpochMs: Long): AuthSessionRecord? = ds.connection.use { c ->
        c.autoCommit = false
        try {
            val current = c.prepareStatement("SELECT session_id,user_id,provider,refresh_token_hash,extract(epoch from expires_at)*1000,revoked,extract(epoch from created_at)*1000,scopes,roles FROM auth_sessions WHERE refresh_token_hash=? AND revoked=false AND expires_at>now() FOR UPDATE").use { ps ->
                ps.setString(1, hash); ps.executeQuery().use { rs -> if (rs.next()) toRecord(rs) else null }
            } ?: run { c.commit(); return@use null }
            c.prepareStatement("UPDATE auth_sessions SET revoked=true,revoked_at=now() WHERE session_id=? AND revoked=false").use { ps ->
                ps.setString(1, current.sessionId)
                require(ps.executeUpdate() == 1)
            }
            c.commit()
            current
        } catch (t: Throwable) { c.rollback(); throw t }
    }
    override fun isActive(sessionId: String, nowEpochMs: Long): Boolean = ds.connection.use { c ->
        c.prepareStatement("SELECT 1 FROM auth_sessions WHERE session_id=? AND revoked=false AND expires_at>now() LIMIT 1").use { ps ->
            ps.setObject(1, java.util.UUID.fromString(sessionId))
            ps.executeQuery().use { rs -> rs.next() }
        }
    }
    override fun revoke(sessionId: String, nowEpochMs: Long) { ds.connection.use { c ->
        c.prepareStatement("UPDATE auth_sessions SET revoked=true,revoked_at=now() WHERE session_id=? AND revoked=false").use { ps -> ps.setString(1,sessionId); ps.executeUpdate() }
    } }

    private fun toRecord(rs: java.sql.ResultSet): AuthSessionRecord =
        AuthSessionRecord(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDouble(5).toLong(),rs.getBoolean(6),rs.getDouble(7).toLong(),rs.getString(8).orEmpty().split(' ').filter{it.isNotBlank()}.toSet(),rs.getString(9).orEmpty().split(' ').filter{it.isNotBlank()}.toSet())
}

class PostgresAccountProfileRepository(private val ds: javax.sql.DataSource) : AccountProfileRepository {
    override fun get(userId: String): com.rockyx.backend.domain.AccountProfileResponse = ds.connection.use { c ->
        c.prepareStatement("SELECT user_id,display_name,locale,time_zone,onboarding_version,profile_version FROM accounts WHERE user_id=?").use { ps ->
            ps.setString(1, userId); ps.executeQuery().use { rs ->
                if (!rs.next()) com.rockyx.backend.domain.AccountProfileResponse(userId)
                else com.rockyx.backend.domain.AccountProfileResponse(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6))
            }
        }
    }
    override fun update(userId: String, displayName: String?, locale: String?, timeZone: String?, onboardingVersion: Int): com.rockyx.backend.domain.AccountProfileResponse = ds.connection.use { c ->
        c.autoCommit = false
        try {
            ensureAccount(c, userId)
            c.prepareStatement("UPDATE accounts SET display_name=?,locale=?,time_zone=?,onboarding_version=?,profile_version=profile_version+1 WHERE user_id=?").use { ps ->
                ps.setString(1, displayName); ps.setString(2, locale); ps.setString(3, timeZone); ps.setInt(4, onboardingVersion); ps.setString(5, userId); ps.executeUpdate()
            }
            val result = c.prepareStatement("SELECT user_id,display_name,locale,time_zone,onboarding_version,profile_version FROM accounts WHERE user_id=?").use { ps ->
                ps.setString(1, userId); ps.executeQuery().use { rs ->
                    if (!rs.next()) error("Profile was not persisted")
                    com.rockyx.backend.domain.AccountProfileResponse(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6))
                }
            }
            c.commit(); result
        } catch (t: Throwable) { c.rollback(); throw t }
    }
}

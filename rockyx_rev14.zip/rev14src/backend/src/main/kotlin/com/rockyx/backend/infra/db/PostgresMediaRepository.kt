package com.rockyx.backend.infra.db

import com.rockyx.backend.media.*
import java.time.OffsetDateTime
import javax.sql.DataSource

private fun java.sql.ResultSet.mediaEpoch(column: String): Long = getObject(column, OffsetDateTime::class.java).toInstant().toEpochMilli()

class PostgresMediaRepository(private val ds: DataSource) : MediaRepository {
    override fun create(asset: MediaAsset): MediaAsset = ds.connection.use { c ->
        c.prepareStatement("""
            INSERT INTO media_assets(media_id,user_id,submission_id,object_key,content_type,size_bytes,checksum,state)
            VALUES (?,?,?,?,?,?,?,?) ON CONFLICT (media_id) DO NOTHING
        """.trimIndent()).use { ps ->
            ps.setString(1, asset.mediaId); ps.setString(2, asset.userId); ps.setString(3, asset.submissionId); ps.setString(4, asset.objectKey)
            ps.setString(5, asset.contentType); ps.setLong(6, asset.sizeBytes); ps.setString(7, asset.checksum); ps.setString(8, asset.state); ps.executeUpdate()
        }
        getForUser(asset.userId, asset.mediaId) ?: error("Media was not persisted")
    }

    override fun getForUser(userId: String, mediaId: String): MediaAsset? = ds.connection.use { c ->
        c.prepareStatement("SELECT media_id,user_id,submission_id,object_key,content_type,size_bytes,checksum,state,created_at,updated_at FROM media_assets WHERE media_id=? AND user_id=?").use { ps ->
            ps.setString(1, mediaId); ps.setString(2, userId)
            ps.executeQuery().use { rs -> if (!rs.next()) null else MediaAsset(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getLong(6),rs.getString(7),rs.getString(8),rs.mediaEpoch("created_at"),rs.mediaEpoch("updated_at")) }
        }
    }

    override fun markReady(userId: String, mediaId: String, checksum: String): MediaAsset? = ds.connection.use { c ->
        c.prepareStatement("UPDATE media_assets SET state='QUARANTINED', updated_at=now() WHERE media_id=? AND user_id=? AND checksum=? AND state='UPLOAD_PENDING'").use { ps ->
            ps.setString(1, mediaId); ps.setString(2, userId); ps.setString(3, checksum); ps.executeUpdate()
        }
        getForUser(userId, mediaId)
    }

    override fun getForSystem(mediaId: String): MediaAsset? = ds.connection.use { c ->
        c.prepareStatement("SELECT media_id,user_id,submission_id,object_key,content_type,size_bytes,checksum,state,created_at,updated_at FROM media_assets WHERE media_id=?").use { ps ->
            ps.setString(1, mediaId)
            ps.executeQuery().use { rs -> if (!rs.next()) null else MediaAsset(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getLong(6),rs.getString(7),rs.getString(8),rs.mediaEpoch("created_at"),rs.mediaEpoch("updated_at")) }
        }
    }

    override fun updateSystemState(mediaId: String, expectedState: String, newState: String): Boolean = ds.connection.use { c ->
        c.prepareStatement("UPDATE media_assets SET state=?, updated_at=now() WHERE media_id=? AND state=?").use { ps ->
            ps.setString(1, newState); ps.setString(2, mediaId); ps.setString(3, expectedState); ps.executeUpdate() == 1
        }
    }

    override fun updateState(userId: String, mediaId: String, expectedState: String, newState: String): MediaAsset? = ds.connection.use { c ->
        c.prepareStatement("UPDATE media_assets SET state=?, updated_at=now() WHERE media_id=? AND user_id=? AND state=?").use { ps ->
            ps.setString(1, newState); ps.setString(2, mediaId); ps.setString(3, userId); ps.setString(4, expectedState); ps.executeUpdate()
        }
        getForUser(userId, mediaId)
    }
}

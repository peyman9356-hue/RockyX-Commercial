package com.rockyx.backend.auth

import com.auth0.jwk.JwkProviderBuilder
import com.auth0.jwt.interfaces.DecodedJWT
import com.auth0.jwt.interfaces.JWTVerifier
import com.auth0.jwt.exceptions.JWTVerificationException
import com.auth0.jwt.algorithms.Algorithm
import com.auth0.jwt.JWT
import java.security.interfaces.RSAPublicKey
import io.ktor.server.application.*
import java.net.URI
import java.util.concurrent.TimeUnit

/** Authenticated identity extracted only after cryptographic token verification. */
data class AuthenticatedPrincipal(
    val userId: String,
    val provider: String,
    val scopes: Set<String> = emptySet(),
    val roles: Set<String> = emptySet()
)

interface AccessTokenVerifier {
    suspend fun verify(bearerToken: String): AuthenticatedPrincipal?
}

/** Production-safe default: rejects every token until an IdP is configured. */
class RejectAllTokenVerifier : AccessTokenVerifier {
    override suspend fun verify(bearerToken: String): AuthenticatedPrincipal? = null
}

data class JwtSecurityConfig(
    val issuer: String,
    val audience: String,
    val jwksUrl: String,
    val userIdClaim: String = "sub",
    val scopesClaim: String = "scope",
    val rolesClaim: String = "roles"
) {
    companion object {
        fun fromEnvironment(): JwtSecurityConfig? {
            val issuer = System.getenv("ROCKYX_JWT_ISSUER")?.trim().orEmpty()
            val audience = System.getenv("ROCKYX_JWT_AUDIENCE")?.trim().orEmpty()
            val jwksUrl = System.getenv("ROCKYX_JWT_JWKS_URL")?.trim().orEmpty()
            if (issuer.isBlank() || audience.isBlank() || jwksUrl.isBlank()) return null
            require(URI(jwksUrl).scheme == "https") { "ROCKYX_JWT_JWKS_URL must use HTTPS" }
            return JwtSecurityConfig(issuer, audience, jwksUrl,
                System.getenv("ROCKYX_JWT_USER_ID_CLAIM")?.takeIf { it.isNotBlank() } ?: "sub",
                System.getenv("ROCKYX_JWT_SCOPES_CLAIM")?.takeIf { it.isNotBlank() } ?: "scope",
                System.getenv("ROCKYX_JWT_ROLES_CLAIM")?.takeIf { it.isNotBlank() } ?: "roles")
        }
    }
}

/** RS256/RS384/RS512 verification through a remotely managed JWKS set. */
class JwksAccessTokenVerifier(private val config: JwtSecurityConfig) : AccessTokenVerifier {
    private val provider = JwkProviderBuilder(config.jwksUrl)
        .cached(10, 24, TimeUnit.HOURS)
        .rateLimited(10, 1, TimeUnit.MINUTES)
        .build()

    override suspend fun verify(bearerToken: String): AuthenticatedPrincipal? = try {
        val unsigned = JWT.decode(bearerToken)
        require(unsigned.algorithm == "RS256") { "Unsupported JWT algorithm" }
        val publicKey = provider.get(unsigned.keyId).publicKey as? RSAPublicKey ?: return null
        val verifier: JWTVerifier = JWT.require(Algorithm.RSA256(publicKey, null))
            .withIssuer(config.issuer)
            .withAudience(config.audience)
            .acceptLeeway(3)
            .build()
        val jwt = verifier.verify(bearerToken)
        val userId = jwt.getClaim(config.userIdClaim).asString()?.takeIf { it.isNotBlank() } ?: return null
        val scopes = readStringSet(jwt, config.scopesClaim)
        val roles = readStringSet(jwt, config.rolesClaim)
        AuthenticatedPrincipal(userId, config.issuer, scopes, roles)
    } catch (_: JWTVerificationException) {
        null
    } catch (_: IllegalArgumentException) {
        null
    } catch (_: Exception) {
        null
    }

    private fun readStringSet(jwt: DecodedJWT, claim: String): Set<String> {
        val raw = jwt.getClaim(claim)
        return raw.asString()?.split(' ', ',', ';')?.filter { it.isNotBlank() }?.toSet()
            ?: raw.asList(String::class.java)?.filter { it.isNotBlank() }?.toSet()
            ?: emptySet()
    }
}

suspend fun ApplicationCall.requirePrincipal(verifier: AccessTokenVerifier): AuthenticatedPrincipal? {
    val header = request.headers["Authorization"] ?: return null
    if (!com.rockyx.backend.api.SecurityPolicy.validTokenHeader(header)) return null
    val token = header.substringAfter(' ').trim()
    return verifier.verify(token)
}

fun AuthenticatedPrincipal.hasScope(scope: String): Boolean = scope in scopes
fun AuthenticatedPrincipal.hasRole(role: String): Boolean = role in roles


/** Tries first-party sessions before an external OIDC/OAuth verifier. */
class CompositeAccessTokenVerifier(private val firstParty: AccessTokenVerifier?) : AccessTokenVerifier {
    override suspend fun verify(bearerToken: String): AuthenticatedPrincipal? = firstParty?.verify(bearerToken)
}

package com.rockyx.backend.infra.db

import com.rockyx.backend.domain.*
import com.rockyx.backend.infra.EcosystemRepository
import java.sql.Connection
import java.sql.ResultSet
import java.time.OffsetDateTime
import javax.sql.DataSource

private const val DOG_COLUMNS = "dog_id,owner_user_id,name,breed,date_of_birth,sex,weight_grams,activity_baseline,profile_version,created_at,updated_at"

private fun epochMs(rs: ResultSet, column: String): Long =
    rs.getObject(column, OffsetDateTime::class.java).toInstant().toEpochMilli()

private fun nullableEpochMs(rs: ResultSet, column: String): Long? =
    rs.getObject(column, OffsetDateTime::class.java)?.toInstant()?.toEpochMilli()

class PostgresEcosystemRepository(private val ds: DataSource) : EcosystemRepository {
    override fun listDogs(userId: String): List<DogRecord> = ds.connection.use { c ->
        c.prepareStatement("SELECT $DOG_COLUMNS FROM dogs WHERE owner_user_id=? ORDER BY created_at").use { ps ->
            ps.setString(1, userId)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(dog(rs)) } }
        }
    }

    override fun getDog(userId: String, dogId: String): DogRecord? = ds.connection.use { c -> getDog(c, userId, dogId) }

    override fun upsertDog(userId: String, request: DogUpsertRequest): DogRecord = ds.connection.use { c ->
        c.autoCommit = false
        try {
            ensureAccount(c, userId)
            validateDog(request)
            val oldVersion = c.prepareStatement(
                "SELECT profile_version FROM dogs WHERE dog_id=? AND owner_user_id=? FOR UPDATE"
            ).use { ps ->
                ps.setString(1, request.dogId)
                ps.setString(2, userId)
                ps.executeQuery().use { rs -> if (rs.next()) rs.getInt(1) else null }
            }
            if (request.expectedProfileVersion != null) {
                require(oldVersion == request.expectedProfileVersion)
            }
            val rows = c.prepareStatement(
                """
                INSERT INTO dogs(dog_id,owner_user_id,name,breed,date_of_birth,sex,weight_grams,activity_baseline)
                VALUES (?,?,?,?,to_timestamp(?/1000.0),?,?,?)
                ON CONFLICT (dog_id) DO UPDATE SET
                    name=EXCLUDED.name,
                    breed=EXCLUDED.breed,
                    date_of_birth=EXCLUDED.date_of_birth,
                    sex=EXCLUDED.sex,
                    weight_grams=EXCLUDED.weight_grams,
                    activity_baseline=EXCLUDED.activity_baseline,
                    profile_version=dogs.profile_version+1,
                    updated_at=now()
                WHERE dogs.owner_user_id=EXCLUDED.owner_user_id
                """.trimIndent()
            ).use { ps ->
                ps.setString(1, request.dogId)
                ps.setString(2, userId)
                ps.setString(3, request.name.trim())
                ps.setString(4, request.breed?.trim()?.takeIf { it.isNotBlank() })
                if (request.dateOfBirthEpochMs == null) ps.setObject(5, null) else ps.setLong(5, request.dateOfBirthEpochMs)
                ps.setString(6, request.sex?.trim()?.takeIf { it.isNotBlank() })
                ps.setObject(7, request.weightGrams)
                ps.setObject(8, request.activityBaseline)
                ps.executeUpdate()
            }
            // A conflicting dog owned by another account must never become a silent no-op.
            require(dogExistsOwnedBy(c, request.dogId, userId))
            val result = getDog(c, userId, request.dogId) ?: error("Dog was not persisted")
            c.commit()
            result
        } catch (t: Throwable) {
            c.rollback()
            throw t
        }
    }

    override fun addDogEvent(userId: String, request: DogEventCreateRequest): DogEvent = ds.connection.use { c ->
        c.autoCommit = false
        try {
            validateEvent(request)
            require(getDog(c, userId, request.dogId) != null)
            val existing = getDogEvent(c, request.eventId)
            if (existing != null) {
                require(existing.ownerUserId == userId && existing.dogId == request.dogId)
                c.commit()
                return@use existing
            }
            c.prepareStatement(
                "INSERT INTO dog_events(event_id,dog_id,owner_user_id,event_type,payload_json,occurred_at) VALUES (?,?,?,?,?::jsonb,to_timestamp(?/1000.0))"
            ).use { ps ->
                ps.setString(1, request.eventId)
                ps.setString(2, request.dogId)
                ps.setString(3, userId)
                ps.setString(4, request.eventType.trim())
                ps.setString(5, request.payloadJson)
                ps.setLong(6, request.occurredAtEpochMs)
                ps.executeUpdate()
            }
            val result = getDogEvent(c, request.eventId) ?: error("Event was not persisted")
            c.commit()
            result
        } catch (t: Throwable) {
            c.rollback()
            throw t
        }
    }

    override fun listDogEvents(userId: String, dogId: String, limit: Int): List<DogEvent> = ds.connection.use { c ->
        val safeLimit = limit.coerceIn(1, 200)
        c.prepareStatement(
            "SELECT event_id,dog_id,owner_user_id,event_type,payload_json::text,occurred_at,created_at FROM dog_events WHERE owner_user_id=? AND dog_id=? ORDER BY occurred_at DESC LIMIT ?"
        ).use { ps ->
            ps.setString(1, userId); ps.setString(2, dogId); ps.setInt(3, safeLimit)
            ps.executeQuery().use { rs ->
                buildList {
                    while (rs.next()) add(
                        DogEvent(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), epochMs(rs, "occurred_at"), epochMs(rs, "created_at"))
                    )
                }
            }
        }
    }

    override fun upsertDevice(userId: String, request: DeviceUpsertRequest): DeviceRecord = ds.connection.use { c ->
        c.autoCommit = false
        try {
            validateDevice(request)
            request.dogId?.let { require(getDog(c, userId, it) != null) }
            val existing = getDevice(c, request.deviceId)
            if (existing != null) require(existing.ownerUserId == userId)
            c.prepareStatement(
                "INSERT INTO devices(device_id,owner_user_id,dog_id,device_type,hardware_revision,firmware_version,battery_percent) VALUES (?,?,?,?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET dog_id=EXCLUDED.dog_id,device_type=EXCLUDED.device_type,hardware_revision=EXCLUDED.hardware_revision,firmware_version=EXCLUDED.firmware_version,battery_percent=EXCLUDED.battery_percent,updated_at=now() WHERE devices.owner_user_id=EXCLUDED.owner_user_id"
            ).use { ps ->
                ps.setString(1, request.deviceId); ps.setString(2, userId); ps.setString(3, request.dogId); ps.setString(4, request.deviceType.trim()); ps.setString(5, request.hardwareRevision?.trim()?.takeIf { it.isNotBlank() }); ps.setString(6, request.firmwareVersion?.trim()?.takeIf { it.isNotBlank() }); ps.setObject(7, request.batteryPercent)
                ps.executeUpdate()
            }
            val result = getDevice(c, request.deviceId) ?: error("Device was not persisted")
            require(result.ownerUserId == userId)
            c.commit(); result
        } catch (t: Throwable) { c.rollback(); throw t }
    }

    override fun listDevices(userId: String, dogId: String?): List<DeviceRecord> = ds.connection.use { c ->
        val sql = if (dogId == null) "SELECT * FROM devices WHERE owner_user_id=? ORDER BY created_at DESC" else "SELECT * FROM devices WHERE owner_user_id=? AND dog_id=? ORDER BY created_at DESC"
        c.prepareStatement(sql).use { ps ->
            ps.setString(1, userId); if (dogId != null) ps.setString(2, dogId)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(device(rs)) } }
        }
    }

    override fun createVetAccess(userId: String, request: VetAccessCreateRequest): VetAccessGrant = ds.connection.use { c ->
        c.autoCommit = false
        try {
            validateVet(request)
            require(getDog(c, userId, request.dogId) != null)
            val existing = getVet(c, request.grantId)
            if (existing != null) {
                require(existing.ownerUserId == userId && existing.dogId == request.dogId)
                c.commit(); return@use existing
            }
            c.prepareStatement("INSERT INTO vet_access_grants(grant_id,dog_id,owner_user_id,vet_subject_id,access_level,expires_at) VALUES (?,?,?,?,?,to_timestamp(?/1000.0))").use { ps ->
                ps.setString(1, request.grantId); ps.setString(2, request.dogId); ps.setString(3, userId); ps.setString(4, request.vetSubjectId); ps.setString(5, request.accessLevel)
                if (request.expiresAtEpochMs == null) ps.setObject(6, null) else ps.setLong(6, request.expiresAtEpochMs)
                ps.executeUpdate()
            }
            val result = getVet(c, request.grantId) ?: error("Grant was not persisted")
            c.commit(); result
        } catch (t: Throwable) { c.rollback(); throw t }
    }

    override fun listVetAccess(userId: String, dogId: String): List<VetAccessGrant> = ds.connection.use { c ->
        c.prepareStatement("SELECT * FROM vet_access_grants WHERE owner_user_id=? AND dog_id=? AND revoked=false AND (expires_at IS NULL OR expires_at>now()) ORDER BY created_at DESC").use { ps ->
            ps.setString(1, userId); ps.setString(2, dogId); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(vet(rs)) } }
        }
    }

    override fun revokeVetAccess(userId: String, grantId: String): Boolean = ds.connection.use { c ->
        c.prepareStatement("UPDATE vet_access_grants SET revoked=true,updated_at=now() WHERE grant_id=? AND owner_user_id=? AND revoked=false").use { ps ->
            ps.setString(1, grantId); ps.setString(2, userId); ps.executeUpdate() == 1
        }
    }

    override fun getDogForVet(vetSubjectId: String, dogId: String): DogRecord? = ds.connection.use { c ->
        c.prepareStatement("SELECT $DOG_COLUMNS FROM dogs d JOIN vet_access_grants g ON g.dog_id=d.dog_id AND g.owner_user_id=d.owner_user_id WHERE g.vet_subject_id=? AND g.dog_id=? AND g.revoked=false AND (g.expires_at IS NULL OR g.expires_at>now())").use { ps ->
            ps.setString(1, vetSubjectId); ps.setString(2, dogId); ps.executeQuery().use { rs -> if (rs.next()) dog(rs) else null }
        }
    }

    override fun addSafetyEvent(userId: String, request: SafetyEventCreateRequest): SafetyEvent = ds.connection.use { c ->
        c.autoCommit = false
        try {
            validateSafety(request)
            require(getDog(c, userId, request.dogId) != null)
            val existing = getSafety(c, request.safetyEventId)
            if (existing != null) {
                require(existing.ownerUserId == userId && existing.dogId == request.dogId)
                c.commit(); return@use existing
            }
            c.prepareStatement("INSERT INTO safety_events(safety_event_id,dog_id,owner_user_id,event_type,status,latitude_e6,longitude_e6,accuracy_meters,occurred_at) VALUES (?,?,?,?,?,?,?,?,to_timestamp(?/1000.0))").use { ps ->
                ps.setString(1, request.safetyEventId); ps.setString(2, request.dogId); ps.setString(3, userId); ps.setString(4, request.eventType.trim()); ps.setString(5, request.status.trim()); ps.setObject(6, request.latitudeE6); ps.setObject(7, request.longitudeE6); ps.setObject(8, request.accuracyMeters); ps.setLong(9, request.occurredAtEpochMs); ps.executeUpdate()
            }
            val result = getSafety(c, request.safetyEventId) ?: error("Safety event was not persisted")
            c.commit(); result
        } catch (t: Throwable) { c.rollback(); throw t }
    }

    override fun listSafetyEvents(userId: String, dogId: String, limit: Int): List<SafetyEvent> = ds.connection.use { c ->
        c.prepareStatement("SELECT * FROM safety_events WHERE owner_user_id=? AND dog_id=? ORDER BY occurred_at DESC LIMIT ?").use { ps ->
            ps.setString(1, userId); ps.setString(2, dogId); ps.setInt(3, limit.coerceIn(1, 200)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(safety(rs)) } }
        }
    }

    override fun addAiInsight(userId: String, request: AiInsightCreateRequest): AiInsight = ds.connection.use { c ->
        c.autoCommit = false
        try {
            validateInsight(request)
            require(getDog(c, userId, request.dogId) != null)
            val existing = getInsight(c, request.insightId)
            if (existing != null) {
                require(existing.ownerUserId == userId && existing.dogId == request.dogId)
                c.commit(); return@use existing
            }
            c.prepareStatement("INSERT INTO ai_insights(insight_id,dog_id,owner_user_id,kind,evidence_json,inference_json,recommendation_json,confidence) VALUES (?,?,?,?,?::jsonb,?::jsonb,?::jsonb,?)").use { ps ->
                ps.setString(1, request.insightId); ps.setString(2, request.dogId); ps.setString(3, userId); ps.setString(4, request.kind.trim()); ps.setString(5, request.evidenceJson); ps.setString(6, request.inferenceJson); ps.setString(7, request.recommendationJson); ps.setInt(8, request.confidence); ps.executeUpdate()
            }
            val result = getInsight(c, request.insightId) ?: error("Insight was not persisted")
            c.commit(); result
        } catch (t: Throwable) { c.rollback(); throw t }
    }

    override fun listAiInsights(userId: String, dogId: String, limit: Int): List<AiInsight> = ds.connection.use { c ->
        c.prepareStatement("SELECT * FROM ai_insights WHERE owner_user_id=? AND dog_id=? ORDER BY created_at DESC LIMIT ?").use { ps ->
            ps.setString(1, userId); ps.setString(2, dogId); ps.setInt(3, limit.coerceIn(1, 100)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(insight(rs)) } }
        }
    }

    private fun ensureAccount(c: Connection, userId: String) {
        c.prepareStatement("INSERT INTO accounts(user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING").use { ps -> ps.setString(1, userId); ps.executeUpdate() }
    }

    private fun dogExistsOwnedBy(c: Connection, dogId: String, userId: String): Boolean =
        c.prepareStatement("SELECT 1 FROM dogs WHERE dog_id=? AND owner_user_id=?").use { ps -> ps.setString(1, dogId); ps.setString(2, userId); ps.executeQuery().use { it.next() } }

    private fun getDog(c: Connection, userId: String, dogId: String): DogRecord? =
        c.prepareStatement("SELECT $DOG_COLUMNS FROM dogs WHERE dog_id=? AND owner_user_id=?").use { ps -> ps.setString(1, dogId); ps.setString(2, userId); ps.executeQuery().use { rs -> if (rs.next()) dog(rs) else null } }

    private fun getDogEvent(c: Connection, id: String): DogEvent? =
        c.prepareStatement("SELECT event_id,dog_id,owner_user_id,event_type,payload_json::text,occurred_at,created_at FROM dog_events WHERE event_id=?").use { ps -> ps.setString(1, id); ps.executeQuery().use { rs -> if (rs.next()) DogEvent(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), epochMs(rs, "occurred_at"), epochMs(rs, "created_at")) else null } }

    private fun getDevice(c: Connection, id: String): DeviceRecord? =
        c.prepareStatement("SELECT * FROM devices WHERE device_id=?").use { ps -> ps.setString(1, id); ps.executeQuery().use { rs -> if (rs.next()) device(rs) else null } }

    private fun getVet(c: Connection, id: String): VetAccessGrant? =
        c.prepareStatement("SELECT * FROM vet_access_grants WHERE grant_id=?").use { ps -> ps.setString(1, id); ps.executeQuery().use { rs -> if (rs.next()) vet(rs) else null } }

    private fun getSafety(c: Connection, id: String): SafetyEvent? =
        c.prepareStatement("SELECT * FROM safety_events WHERE safety_event_id=?").use { ps -> ps.setString(1, id); ps.executeQuery().use { rs -> if (rs.next()) safety(rs) else null } }

    private fun getInsight(c: Connection, id: String): AiInsight? =
        c.prepareStatement("SELECT * FROM ai_insights WHERE insight_id=?").use { ps -> ps.setString(1, id); ps.executeQuery().use { rs -> if (rs.next()) insight(rs) else null } }

    private fun dog(rs: ResultSet) = DogRecord(rs.getString("dog_id"), rs.getString("owner_user_id"), rs.getString("name"), rs.getString("breed"), nullableEpochMs(rs, "date_of_birth"), rs.getString("sex"), rs.getObject("weight_grams") as Int?, rs.getObject("activity_baseline") as Int?, rs.getInt("profile_version"), epochMs(rs, "created_at"), epochMs(rs, "updated_at"))
    private fun device(rs: ResultSet) = DeviceRecord(rs.getString("device_id"), rs.getString("owner_user_id"), rs.getString("dog_id"), rs.getString("device_type"), rs.getString("hardware_revision"), rs.getString("firmware_version"), rs.getString("status"), nullableEpochMs(rs, "last_seen_at"), rs.getObject("battery_percent") as Int?, epochMs(rs, "created_at"), epochMs(rs, "updated_at"))
    private fun vet(rs: ResultSet) = VetAccessGrant(rs.getString("grant_id"), rs.getString("dog_id"), rs.getString("owner_user_id"), rs.getString("vet_subject_id"), rs.getString("access_level"), nullableEpochMs(rs, "expires_at"), rs.getBoolean("revoked"), epochMs(rs, "created_at"), epochMs(rs, "updated_at"))
    private fun safety(rs: ResultSet) = SafetyEvent(rs.getString("safety_event_id"), rs.getString("dog_id"), rs.getString("owner_user_id"), rs.getString("event_type"), rs.getString("status"), rs.getObject("latitude_e6") as Int?, rs.getObject("longitude_e6") as Int?, rs.getObject("accuracy_meters") as Int?, epochMs(rs, "occurred_at"), epochMs(rs, "created_at"))
    private fun insight(rs: ResultSet) = AiInsight(rs.getString("insight_id"), rs.getString("dog_id"), rs.getString("owner_user_id"), rs.getString("kind"), rs.getString("evidence_json"), rs.getString("inference_json"), rs.getString("recommendation_json"), rs.getInt("confidence"), epochMs(rs, "created_at"))

    private fun validateDog(r: DogUpsertRequest) {
        EcosystemValidation.id(r.dogId); EcosystemValidation.name(r.name); EcosystemValidation.optionalText(r.breed, 80); EcosystemValidation.optionalEpoch(r.dateOfBirthEpochMs); EcosystemValidation.optionalText(r.sex, 32); EcosystemValidation.weight(r.weightGrams); EcosystemValidation.activity(r.activityBaseline); require(r.expectedProfileVersion == null || r.expectedProfileVersion >= 1)
    }
    private fun validateEvent(r: DogEventCreateRequest) { EcosystemValidation.id(r.eventId); EcosystemValidation.id(r.dogId); EcosystemValidation.type(r.eventType); EcosystemValidation.json(r.payloadJson); EcosystemValidation.epoch(r.occurredAtEpochMs) }
    private fun validateDevice(r: DeviceUpsertRequest) { EcosystemValidation.id(r.deviceId); r.dogId?.let(EcosystemValidation::id); EcosystemValidation.type(r.deviceType); EcosystemValidation.optionalText(r.hardwareRevision, 64); EcosystemValidation.optionalText(r.firmwareVersion, 64); EcosystemValidation.battery(r.batteryPercent) }
    private fun validateVet(r: VetAccessCreateRequest) { EcosystemValidation.id(r.grantId); EcosystemValidation.id(r.dogId); EcosystemValidation.id(r.vetSubjectId); require(r.accessLevel in setOf("VIEW", "VIEW_HEALTH", "EDIT")); EcosystemValidation.optionalEpoch(r.expiresAtEpochMs); require(r.expiresAtEpochMs == null || r.expiresAtEpochMs > System.currentTimeMillis()) }
    private fun validateSafety(r: SafetyEventCreateRequest) { EcosystemValidation.id(r.safetyEventId); EcosystemValidation.id(r.dogId); EcosystemValidation.type(r.eventType); EcosystemValidation.type(r.status); EcosystemValidation.latitudeE6(r.latitudeE6); EcosystemValidation.longitudeE6(r.longitudeE6); EcosystemValidation.accuracy(r.accuracyMeters); EcosystemValidation.epoch(r.occurredAtEpochMs); require((r.latitudeE6 == null) == (r.longitudeE6 == null)) }
    private fun validateInsight(r: AiInsightCreateRequest) { EcosystemValidation.id(r.insightId); EcosystemValidation.id(r.dogId); EcosystemValidation.type(r.kind); EcosystemValidation.json(r.evidenceJson); EcosystemValidation.json(r.inferenceJson); EcosystemValidation.json(r.recommendationJson); EcosystemValidation.confidence(r.confidence) }
}

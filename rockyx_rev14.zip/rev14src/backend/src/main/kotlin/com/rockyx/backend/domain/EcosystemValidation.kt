package com.rockyx.backend.domain

import kotlinx.serialization.json.Json

/** Shared invariants used by every ecosystem persistence implementation. */
object EcosystemValidation {
    private const val MAX_ID = 128
    private const val MAX_TYPE = 64
    private const val MAX_JSON = 100_000

    fun id(value: String) = value.trim().also { require(it.isNotEmpty() && it.length <= MAX_ID) }
    fun type(value: String) = value.trim().also { require(it.isNotEmpty() && it.length <= MAX_TYPE) }
    fun name(value: String) = value.trim().also { require(it.isNotEmpty() && it.length <= 80) }
    fun optionalText(value: String?, max: Int): String? = value?.trim()?.takeIf { it.isNotEmpty() }?.also { require(it.length <= max) }
    fun json(value: String) = value.also { require(it.length <= MAX_JSON); Json.parseToJsonElement(it) }
    fun weight(grams: Int?) = grams.also { require(it == null || it in 1..300_000) }
    fun activity(value: Int?) = value.also { require(it == null || it in 0..100) }
    fun battery(value: Int?) = value.also { require(it == null || it in 0..100) }
    fun confidence(value: Int) = value.also { require(it in 0..100) }
    fun latitudeE6(value: Int?) = value.also { require(it == null || it in -90_000_000..90_000_000) }
    fun longitudeE6(value: Int?) = value.also { require(it == null || it in -180_000_000..180_000_000) }
    fun accuracy(value: Int?) = value.also { require(it == null || it in 0..100_000) }
    fun epoch(value: Long) = value.also { require(it in 0..4_102_444_800_000L) } // through 2100-01-01
    fun optionalEpoch(value: Long?) = value.also { require(it == null || it in 0..4_102_444_800_000L) }
}

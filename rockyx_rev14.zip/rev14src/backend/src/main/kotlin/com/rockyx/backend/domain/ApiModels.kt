package com.rockyx.backend.domain

import kotlinx.serialization.Serializable

@Serializable
enum class FailureCategory { NETWORK, AUTH, SYNC, MEDIA, SUBMISSION, STORAGE, BILLING, CONTENT, UNKNOWN }

@Serializable
data class ApiError(
    val code: String,
    val message: String,
    val requestId: String,
    val retryable: Boolean = false,
    val category: FailureCategory = FailureCategory.UNKNOWN,
    val details: Map<String, String> = emptyMap()
)

@Serializable
data class HealthResponse(val status: String, val apiVersion: String)

@Serializable
data class AccountResponse(
    val userId: String,
    val createdAtEpochMs: Long,
    val accountVersion: Int
)

@Serializable
data class SyncOperationRequest(
    val operationId: String,
    val entityType: String,
    val entityId: String,
    val payloadVersion: Int,
    val payloadJson: String,
    val clientChangedAtEpochMs: Long
)

@Serializable
data class SyncOperationResponse(
    val operationId: String,
    val status: String,
    val serverAcceptedAtEpochMs: Long
)

@Serializable
data class SubmissionCreateRequest(
    val submissionId: String,
    val missionId: String,
    val visibility: String,
    val consentVersion: Int,
    val mediaChecksum: String
)

@Serializable
data class SubmissionResponse(
    val submissionId: String,
    val userId: String,
    val missionId: String,
    val state: String,
    val visibility: String,
    val serverUpdatedAtEpochMs: Long
)

@Serializable
data class EntitlementResponse(
    val productId: String,
    val tier: String,
    val state: String,
    val expiresAtEpochMs: Long? = null
)

@Serializable
data class PlayPurchaseVerifyRequest(
    val productId: String,
    val purchaseToken: String
)

@Serializable
data class PlayPurchaseVerifyResponse(
    val productId: String,
    val tier: String,
    val state: String,
    val expiresAtEpochMs: Long? = null,
    val acknowledged: Boolean
)


@kotlinx.serialization.Serializable
data class AuthExchangeRequest(val provider: String, val idToken: String)
@kotlinx.serialization.Serializable
data class AuthRefreshRequest(val refreshToken: String)
@kotlinx.serialization.Serializable
data class AuthTokenResponse(val accessToken: String, val refreshToken: String, val expiresAtEpochMs: Long, val userId: String)

package com.rockyx.backend.billing

import com.google.auth.oauth2.GoogleCredentials
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.Duration

/** Result returned by the trusted Google Play verification boundary. */
data class VerifiedPlayPurchase(
    val productId: String,
    val tier: String,
    val state: String,
    val startsAtEpochMs: Long?,
    val expiresAtEpochMs: Long?,
    val acknowledged: Boolean,
    val purchaseTokenHash: String,
    val testPurchase: Boolean
)

interface GooglePlayPurchaseVerifier {
    fun verifySubscription(productId: String, purchaseToken: String): VerifiedPlayPurchase
    fun acknowledgeSubscription(productId: String, purchaseToken: String)
    fun configured(): Boolean
}

class UnconfiguredGooglePlayPurchaseVerifier : GooglePlayPurchaseVerifier {
    override fun verifySubscription(productId: String, purchaseToken: String): VerifiedPlayPurchase =
        throw IllegalStateException("Google Play verification is not configured")
    override fun acknowledgeSubscription(productId: String, purchaseToken: String) =
        throw IllegalStateException("Google Play verification is not configured")
    override fun configured() = false
}

data class GooglePlayBillingConfig(
    val packageName: String,
    val allowedProducts: Map<String, String>,
    val credentials: GoogleCredentials
) {
    companion object {
        fun fromEnvironment(): GooglePlayBillingConfig? {
            val packageName = System.getenv("ROCKYX_PLAY_PACKAGE_NAME")?.trim().orEmpty()
            val mapping = System.getenv("ROCKYX_PLAY_PRODUCTS")?.trim().orEmpty()
            if (packageName.isBlank() || mapping.isBlank()) return null
            val products = mapping.split(',').mapNotNull { entry ->
                val parts = entry.trim().split(':', limit = 2)
                if (parts.size != 2) null else {
                    val product = parts[0].trim()
                    val tier = parts[1].trim().uppercase()
                    if (product.isBlank() || tier !in setOf("PRO", "PREMIUM")) null else product to tier
                }
            }.toMap()
            if (products.isEmpty()) return null
            val credentials = runCatching {
                GoogleCredentials.getApplicationDefault().createScoped("https://www.googleapis.com/auth/androidpublisher")
            }.getOrNull() ?: return null
            return GooglePlayBillingConfig(packageName, products, credentials)
        }
    }
}

/**
 * Real Google Play Developer API adapter. Credentials stay server-side and are never accepted from the app.
 * It uses purchases.subscriptionsv2.get and the server-side acknowledgement endpoint.
 */
class GooglePlayPurchaseVerifierImpl(
    private val config: GooglePlayBillingConfig,
    private val client: HttpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build()
) : GooglePlayPurchaseVerifier {
    private val json = Json { ignoreUnknownKeys = true }
    private val base = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/" +
        encode(config.packageName)

    override fun configured() = true

    override fun verifySubscription(productId: String, purchaseToken: String): VerifiedPlayPurchase {
        require(config.allowedProducts.containsKey(productId)) { "Product is not configured" }
        require(purchaseToken.length in 20..4096) { "Invalid purchase token" }
        val response = execute("$base/purchases/subscriptionsv2/tokens/${encode(purchaseToken)}")
        if (response.statusCode() != 200) throw GooglePlayBillingException(response.statusCode())
        val root = json.parseToJsonElement(response.body()).jsonObject
        val returnedProduct = root["lineItems"]?.jsonObjectOrNullList()?.firstOrNull()
            ?.get("productId")?.jsonPrimitive?.content
            ?: throw IllegalStateException("Google Play response has no productId")
        require(returnedProduct == productId) { "Product token mismatch" }
        val state = root["subscriptionState"]?.jsonPrimitive?.content ?: "SUBSCRIPTION_STATE_UNSPECIFIED"
        val ack = root["acknowledgementState"]?.jsonPrimitive?.content == "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED"
        val start = root["startTime"]?.jsonPrimitive?.content?.let(::parseGoogleTimestamp)
        val expiry = root["lineItems"]?.jsonObjectOrNullList()?.firstOrNull()
            ?.get("expiryTime")?.jsonPrimitive?.content?.let(::parseGoogleTimestamp)
        val testPurchase = root.containsKey("testPurchase")
        val mappedState = when (state) {
            "SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD" -> "ACTIVE"
            // Google says a cancelled subscription retains access until its expiry time.
            "SUBSCRIPTION_STATE_CANCELED" -> if (expiry == null || expiry > System.currentTimeMillis()) "ACTIVE" else "EXPIRED"
            "SUBSCRIPTION_STATE_EXPIRED" -> "EXPIRED"
            "SUBSCRIPTION_STATE_ON_HOLD", "SUBSCRIPTION_STATE_PAUSED" -> "REVOKED"
            else -> "PENDING"
        }
        return VerifiedPlayPurchase(productId, config.allowedProducts.getValue(productId), mappedState, start, expiry, ack, sha256(purchaseToken), testPurchase)
    }

    override fun acknowledgeSubscription(productId: String, purchaseToken: String) {
        require(config.allowedProducts.containsKey(productId)) { "Product is not configured" }
        val uri = "$base/purchases/subscriptions/${encode(productId)}/tokens/${encode(purchaseToken)}:acknowledge"
        val response = execute(uri, "POST", "{}")
        if (response.statusCode() !in 200..299) throw GooglePlayBillingException(response.statusCode())
    }

    private fun execute(url: String, method: String = "GET", body: String? = null): HttpResponse<String> {
        val accessToken = config.credentials.apply { refreshIfExpired() }.accessToken?.tokenValue ?: throw IllegalStateException("Google access token unavailable")
        val builder = HttpRequest.newBuilder(URI(url)).timeout(Duration.ofSeconds(15))
            .header("Authorization", "Bearer $accessToken")
            .header("Accept", "application/json")
        if (method == "POST") builder.header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(body ?: "{}"))
        else builder.GET()
        return client.send(builder.build(), HttpResponse.BodyHandlers.ofString())
    }

    private fun encode(value: String) = URLEncoder.encode(value, StandardCharsets.UTF_8).replace("+", "%20")
    private fun parseGoogleTimestamp(value: String): Long? = runCatching { java.time.Instant.parse(value).toEpochMilli() }.getOrNull()
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}

private fun kotlinx.serialization.json.JsonElement.jsonObjectOrNullList(): List<kotlinx.serialization.json.JsonObject>? =
    (this as? kotlinx.serialization.json.JsonArray)?.mapNotNull { it as? kotlinx.serialization.json.JsonObject }

class GooglePlayBillingException(val status: Int) : RuntimeException("Google Play API returned HTTP $status")

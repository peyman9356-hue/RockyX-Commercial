package com.rockyx.backend.infra

import com.rockyx.backend.domain.AccountProfileResponse
import java.util.concurrent.ConcurrentHashMap

interface AccountProfileRepository {
    fun get(userId: String): AccountProfileResponse
    fun update(userId: String, displayName: String?, locale: String?, timeZone: String?, onboardingVersion: Int): AccountProfileResponse
}

class InMemoryAccountProfileRepository : AccountProfileRepository {
    private val values = ConcurrentHashMap<String, AccountProfileResponse>()
    override fun get(userId: String) = values.computeIfAbsent(userId) { AccountProfileResponse(userId) }
    override fun update(userId: String, displayName: String?, locale: String?, timeZone: String?, onboardingVersion: Int): AccountProfileResponse =
        values.compute(userId) { _, old ->
            AccountProfileResponse(userId, displayName, locale, timeZone, onboardingVersion, (old?.profileVersion ?: 0) + 1)
        }!!
}

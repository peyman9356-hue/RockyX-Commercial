package com.rockyx.backend

import com.rockyx.backend.api.RequestContext
import com.rockyx.backend.api.registerApiRoutes
import com.rockyx.backend.auth.*
import com.rockyx.backend.ai.LocalPersonalizationProvider
import com.rockyx.backend.infra.*
import com.rockyx.backend.infra.db.*
import com.rockyx.backend.media.*
import com.rockyx.backend.observability.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.calllogging.*
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.request.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.util.AttributeKey
import java.util.UUID
import kotlinx.coroutines.cancel
import org.slf4j.event.Level

fun main() {
    embeddedServer(Netty, port = System.getenv("PORT")?.toIntOrNull() ?: 8080, host = "0.0.0.0") { module() }.start(wait = true)
}

fun Application.module() {
    val telemetry = InMemoryTelemetry()
    val requireTls = System.getenv("ROCKYX_REQUIRE_TLS")?.equals("true", ignoreCase = true) == true
    val production = System.getenv("ROCKYX_ENV")?.equals("production", ignoreCase = true) == true

    intercept(ApplicationCallPipeline.Plugins) {
        val requestId = UUID.randomUUID().toString()
        call.attributes.put(RequestContext.requestIdKey, requestId)
        call.response.headers.append("X-Request-Id", requestId)
        call.response.headers.append("X-Content-Type-Options", "nosniff")
        call.response.headers.append("X-Frame-Options", "DENY")
        call.response.headers.append("Referrer-Policy", "no-referrer")
        call.response.headers.append("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        call.response.headers.append("Cache-Control", "no-store")
        if (requireTls) call.response.headers.append("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        telemetry.count("http.requests", tags = mapOf("method" to call.request.httpMethod.value, "path" to call.request.path()))
        if (requireTls && call.request.local.scheme != "https") {
            call.respond(HttpStatusCode.Forbidden, com.rockyx.backend.domain.ApiError("TLS_REQUIRED", "HTTPS is required", requestId))
            finish()
        }
    }

    install(CallLogging) { level = Level.INFO }
    install(ContentNegotiation) { json() }
    environment.monitor.subscribe(ApplicationStopped) { telemetry.event("service.stopped") }

    install(StatusPages) {
        exception<Throwable> { call, cause ->
            telemetry.count("http.errors", tags = mapOf("type" to (cause::class.simpleName ?: "UnknownException")))
            call.application.environment.log.error("Unhandled request failure requestId={}", call.attributes.getOrNull(RequestContext.requestIdKey))
            call.respond(HttpStatusCode.InternalServerError, com.rockyx.backend.domain.ApiError("INTERNAL_ERROR", "Unexpected server error", call.attributes.getOrNull(RequestContext.requestIdKey) ?: "missing-request-id", retryable = true, category = com.rockyx.backend.domain.FailureCategory.UNKNOWN))
        }
    }

    val jwtConfig = com.rockyx.backend.auth.JwtSecurityConfig.fromEnvironment()
    val sessionConfig = com.rockyx.backend.auth.SessionSecurityConfig.fromEnvironment()
    if (production && sessionConfig == null) error("ROCKYX_SESSION_* must be configured in production")
    val externalVerifier: AccessTokenVerifier? = jwtConfig?.let {
        log.info("External JWT/OIDC authentication enabled for issuer={}", it.issuer)
        com.rockyx.backend.auth.JwksAccessTokenVerifier(it)
    }
    val googleIdentityConfig = com.rockyx.backend.auth.GoogleIdentityConfig.fromEnvironment()
    val googleIdentityVerifier: AccessTokenVerifier? = googleIdentityConfig?.let { com.rockyx.backend.auth.GoogleIdentityVerifier(it) }
    if (production && googleIdentityVerifier == null) error("ROCKYX_GOOGLE_WEB_CLIENT_ID must be configured in production")

    val playBillingConfig = com.rockyx.backend.billing.GooglePlayBillingConfig.fromEnvironment()
    if (production && playBillingConfig == null) error("ROCKYX_PLAY_PACKAGE_NAME, ROCKYX_PLAY_PRODUCTS and server Google credentials must be configured in production")
    val playBilling: com.rockyx.backend.billing.GooglePlayPurchaseVerifier = playBillingConfig?.let { com.rockyx.backend.billing.GooglePlayPurchaseVerifierImpl(it) }
        ?: com.rockyx.backend.billing.UnconfiguredGooglePlayPurchaseVerifier()
    val rtdnAudience = System.getenv("ROCKYX_RTDN_AUDIENCE")?.trim().orEmpty()
    val rtdnServiceAccount = System.getenv("ROCKYX_RTDN_SERVICE_ACCOUNT_EMAIL")?.trim().orEmpty()
    val rtdnAuthenticator: com.rockyx.backend.billing.RtdnPushAuthenticator = if (rtdnAudience.isNotBlank() && rtdnServiceAccount.isNotBlank())
        com.rockyx.backend.billing.GoogleTokenInfoRtdnAuthenticator(rtdnAudience, rtdnServiceAccount)
    else com.rockyx.backend.billing.UnconfiguredRtdnPushAuthenticator()
    if (production && !rtdnAuthenticator.configured()) error("ROCKYX_RTDN_AUDIENCE and ROCKYX_RTDN_SERVICE_ACCOUNT_EMAIL must be configured in production")

    val storage = S3ObjectStorage.fromEnvironment() ?: UnconfiguredObjectStorage()
    if (production && storage is UnconfiguredObjectStorage) error("ROCKYX_STORAGE_BUCKET and ROCKYX_STORAGE_REGION must be configured in production")
    val mediaSecurityScanner: MediaSecurityScanner = UnconfiguredMediaSecurityScanner()
    if (production && mediaSecurityScanner is UnconfiguredMediaSecurityScanner) error("ROCKYX_MEDIA_SECURITY_SCANNER must be configured in production")
    val processingScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)
    val dbConfig = DatabaseConfig.fromEnvironment()

    fun readiness(dbReady: Boolean): HealthSnapshot {
        val dbStatus = when { dbConfig == null -> "not_configured"; dbReady -> "ready"; else -> "unhealthy" }
        val storageStatus = when { storage is UnconfiguredObjectStorage -> "not_configured"; storage is S3ObjectStorage && storage.checkReady() -> "ready"; else -> "unhealthy" }
        val dependenciesReady = dbStatus != "unhealthy" && storageStatus != "unhealthy"
        val status = if (production && !dependenciesReady) "not_ready" else "ready"
        return HealthSnapshot("rockyx-backend", status, "v1", dbStatus, storageStatus)
    }

    val inMemorySessions = InMemoryAuthSessionRepository()
    val sessionVerifierInMemory: AccessTokenVerifier? = sessionConfig?.let { SessionAccessTokenVerifier(it, it.publicKey(), inMemorySessions) }
    val verifierInMemory: AccessTokenVerifier = CompositeAccessTokenVerifier(sessionVerifierInMemory)
    val sessionManagerInMemory = sessionConfig?.let { SessionManager(it, inMemorySessions) }

    if (dbConfig == null) {
        if (production) error("ROCKYX_DATABASE_* must be configured in production")
        log.warn("ROCKYX_DATABASE_* is not configured; using in-memory repositories. This mode is development-only.")
        routing {
            registerApiRoutes(verifierInMemory, InMemoryAccountRepository(), InMemorySyncRepository(), InMemorySubmissionRepository(), InMemoryIdempotencyRepository(), InMemoryMediaRepository(), storage, mediaSecurityScanner, UnconfiguredMediaProcessingQueue(), InMemoryContentRepository(), telemetry, { readiness(true) }, LocalPersonalizationProvider(), InMemoryEntitlementRepository(), InMemoryPurchaseRepository(), playBilling, rtdnAuthenticator, InMemoryRtdnMessageRepository(), inMemorySessions, sessionManagerInMemory, externalVerifier, googleIdentityVerifier, InMemoryAccountProfileRepository(), InMemoryEcosystemRepository())
        }
    } else {
        val database = Database(dbConfig)
        database.migrate()
        environment.monitor.subscribe(ApplicationStopped) { database.close() }
        val ds = database.dataSource()
        val mediaRepository = PostgresMediaRepository(ds)
        val jobRepository = PostgresMediaJobRepository(ds)
        val postgresSessions = PostgresAuthSessionRepository(ds)
        val sessionVerifierPostgres: AccessTokenVerifier? = sessionConfig?.let { SessionAccessTokenVerifier(it, it.publicKey(), postgresSessions) }
        val verifierPostgres: AccessTokenVerifier = CompositeAccessTokenVerifier(sessionVerifierPostgres)
        val worker = MediaProcessingWorker(jobRepository, mediaRepository, mediaSecurityScanner)
        worker.start(processingScope)
        environment.monitor.subscribe(ApplicationStopped) { worker.stop(); processingScope.cancel(); if (storage is S3ObjectStorage) storage.close() }
        routing {
            registerApiRoutes(verifierPostgres, PostgresAccountRepository(ds), PostgresSyncRepository(ds), PostgresSubmissionRepository(ds), PostgresIdempotencyRepository(ds), mediaRepository, storage, mediaSecurityScanner, object : MediaProcessingQueue { override fun enqueue(mediaId: String): Boolean = jobRepository.enqueue(mediaId) }, PostgresContentRepository(ds), telemetry, {
                val dbReady = runCatching { ds.connection.use { it.createStatement().use { stmt -> stmt.execute("SELECT 1") } }; true }.getOrDefault(false)
                readiness(dbReady)
            }, LocalPersonalizationProvider(), PostgresEntitlementRepository(ds), PostgresPurchaseRepository(ds), playBilling, rtdnAuthenticator, PostgresRtdnMessageRepository(ds), postgresSessions, sessionConfig?.let { SessionManager(it, postgresSessions) }, externalVerifier, googleIdentityVerifier, PostgresAccountProfileRepository(ds), PostgresEcosystemRepository(ds))
        }
    }
}

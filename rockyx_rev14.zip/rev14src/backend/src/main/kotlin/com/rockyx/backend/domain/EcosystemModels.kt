package com.rockyx.backend.domain

import kotlinx.serialization.Serializable

/** Master ecosystem primitives. These are intentionally domain-level and vendor-neutral. */
@Serializable
data class DogRecord(
    val dogId: String,
    val ownerUserId: String,
    val name: String,
    val breed: String? = null,
    val dateOfBirthEpochMs: Long? = null,
    val sex: String? = null,
    val weightGrams: Int? = null,
    val activityBaseline: Int? = null,
    val profileVersion: Int = 1,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long
)

@Serializable
data class DogEvent(
    val eventId: String,
    val dogId: String,
    val ownerUserId: String,
    val eventType: String,
    val payloadJson: String,
    val occurredAtEpochMs: Long,
    val createdAtEpochMs: Long
)

@Serializable
data class DeviceRecord(
    val deviceId: String,
    val ownerUserId: String,
    val dogId: String? = null,
    val deviceType: String,
    val hardwareRevision: String? = null,
    val firmwareVersion: String? = null,
    val status: String = "ACTIVE",
    val lastSeenAtEpochMs: Long? = null,
    val batteryPercent: Int? = null,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long
)

@Serializable
data class VetAccessGrant(
    val grantId: String,
    val dogId: String,
    val ownerUserId: String,
    val vetSubjectId: String,
    val accessLevel: String,
    val expiresAtEpochMs: Long? = null,
    val revoked: Boolean = false,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long
)

@Serializable
data class SafetyEvent(
    val safetyEventId: String,
    val dogId: String,
    val ownerUserId: String,
    val eventType: String,
    val status: String,
    val latitudeE6: Int? = null,
    val longitudeE6: Int? = null,
    val accuracyMeters: Int? = null,
    val occurredAtEpochMs: Long,
    val createdAtEpochMs: Long
)

@Serializable
data class AiInsight(
    val insightId: String,
    val dogId: String,
    val ownerUserId: String,
    val kind: String,
    val evidenceJson: String,
    val inferenceJson: String,
    val recommendationJson: String,
    val confidence: Int,
    val createdAtEpochMs: Long
)

@Serializable
data class DogUpsertRequest(
    val dogId: String,
    val name: String,
    val breed: String? = null,
    val dateOfBirthEpochMs: Long? = null,
    val sex: String? = null,
    val weightGrams: Int? = null,
    val activityBaseline: Int? = null,
    val expectedProfileVersion: Int? = null
)

@Serializable
data class DogEventCreateRequest(
    val eventId: String,
    val dogId: String,
    val eventType: String,
    val payloadJson: String,
    val occurredAtEpochMs: Long
)

@Serializable
data class DeviceUpsertRequest(
    val deviceId: String,
    val dogId: String? = null,
    val deviceType: String,
    val hardwareRevision: String? = null,
    val firmwareVersion: String? = null,
    val batteryPercent: Int? = null
)

@Serializable
data class VetAccessCreateRequest(
    val grantId: String,
    val dogId: String,
    val vetSubjectId: String,
    val accessLevel: String,
    val expiresAtEpochMs: Long? = null
)

@Serializable
data class SafetyEventCreateRequest(
    val safetyEventId: String,
    val dogId: String,
    val eventType: String,
    val status: String,
    val latitudeE6: Int? = null,
    val longitudeE6: Int? = null,
    val accuracyMeters: Int? = null,
    val occurredAtEpochMs: Long
)

@Serializable
data class AiInsightCreateRequest(
    val insightId: String,
    val dogId: String,
    val kind: String,
    val evidenceJson: String,
    val inferenceJson: String,
    val recommendationJson: String,
    val confidence: Int
)

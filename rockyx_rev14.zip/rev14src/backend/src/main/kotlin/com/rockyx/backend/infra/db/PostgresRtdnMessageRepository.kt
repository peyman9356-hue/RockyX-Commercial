package com.rockyx.backend.infra.db

import com.rockyx.backend.infra.RtdnMessageRepository
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneOffset
import javax.sql.DataSource

class PostgresRtdnMessageRepository(private val ds: DataSource) : RtdnMessageRepository {
    override fun claim(messageId: String, nowEpochMs: Long): Boolean = ds.connection.use { c ->
        c.prepareStatement("""
            INSERT INTO google_play_rtdn_messages(message_id, received_at, processed_at, processing_started_at)
            VALUES (?, now(), NULL, now())
            ON CONFLICT (message_id) DO UPDATE SET processing_started_at = now()
            WHERE google_play_rtdn_messages.processed_at IS NULL
              AND google_play_rtdn_messages.processing_started_at < now() - interval '5 minutes'
        """.trimIndent()).use { ps ->
            ps.setString(1, messageId)
            ps.executeUpdate() == 1
        }
    }

    override fun markProcessed(messageId: String, processedAtEpochMs: Long) { ds.connection.use { c ->
        c.prepareStatement("UPDATE google_play_rtdn_messages SET processed_at=?, processing_started_at=NULL WHERE message_id=?").use { ps ->
            ps.setObject(1, OffsetDateTime.ofInstant(Instant.ofEpochMilli(processedAtEpochMs), ZoneOffset.UTC))
            ps.setString(2, messageId)
            ps.executeUpdate()
        }
    }
} }

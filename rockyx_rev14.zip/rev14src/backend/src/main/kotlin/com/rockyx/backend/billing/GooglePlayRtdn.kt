package com.rockyx.backend.billing

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration
import java.time.Instant

@Serializable
data class PubSubPushEnvelope(val message: PubSubMessage? = null, val subscription: String? = null)

@Serializable
data class PubSubMessage(
    val data: String? = null,
    val messageId: String? = null,
    val publishTime: String? = null,
    val attributes: Map<String, String> = emptyMap()
)

@Serializable
data class PlayRtdn(
    val version: String? = null,
    val packageName: String? = null,
    val eventTimeMillis: String? = null,
    val subscriptionNotification: SubscriptionNotification? = null,
    val oneTimeProductNotification: OneTimeProductNotification? = null,
    val testNotification: TestNotification? = null
)

@Serializable
data class SubscriptionNotification(
    val version: String? = null,
    val notificationType: Int? = null,
    val purchaseToken: String? = null,
    val subscriptionId: String? = null
)

@Serializable
data class OneTimeProductNotification(val version: String? = null, val notificationType: Int? = null, val purchaseToken: String? = null, val sku: String? = null)
@Serializable
data class TestNotification(val version: String? = null)

/** Verifies the OIDC bearer token attached to authenticated Pub/Sub push requests. */
interface RtdnPushAuthenticator {
    fun configured(): Boolean
    fun verify(authorizationHeader: String?): Boolean
}

class UnconfiguredRtdnPushAuthenticator : RtdnPushAuthenticator {
    override fun configured() = false
    override fun verify(authorizationHeader: String?) = false
}

/**
 * Uses Google's tokeninfo endpoint to validate the signed OIDC token, then enforces issuer,
 * audience, service-account email and expiry locally. This keeps the verification boundary
 * replaceable if the deployment later moves to a local JWKS verifier.
 */
class GoogleTokenInfoRtdnAuthenticator(
    private val audience: String,
    private val serviceAccountEmail: String,
    private val client: HttpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()
) : RtdnPushAuthenticator {
    private val json = Json { ignoreUnknownKeys = true }
    override fun configured() = audience.isNotBlank() && serviceAccountEmail.isNotBlank()

    override fun verify(authorizationHeader: String?): Boolean {
        val bearer = authorizationHeader?.removePrefix("Bearer ")?.takeIf { it.length in 100..8192 } ?: return false
        return runCatching {
            val request = HttpRequest.newBuilder(URI.create("https://oauth2.googleapis.com/tokeninfo?id_token=${java.net.URLEncoder.encode(bearer, Charsets.UTF_8)}"))
                .timeout(Duration.ofSeconds(8)).GET().build()
            val response = client.send(request, HttpResponse.BodyHandlers.ofString())
            if (response.statusCode() != 200) return false
            val claims = json.parseToJsonElement(response.body()).jsonObject
            val iss = claims["iss"]?.jsonPrimitive?.content
            val aud = claims["aud"]?.jsonPrimitive?.content
            val email = claims["email"]?.jsonPrimitive?.content
            val verified = claims["email_verified"]?.jsonPrimitive?.content?.toBooleanStrictOrNull() == true
            val exp = claims["exp"]?.jsonPrimitive?.content?.toLongOrNull() ?: return false
            iss in setOf("https://accounts.google.com", "accounts.google.com") &&
                aud.equals(audience, ignoreCase = false) && email == serviceAccountEmail && verified && exp > Instant.now().epochSecond
        }.getOrDefault(false)
    }
}

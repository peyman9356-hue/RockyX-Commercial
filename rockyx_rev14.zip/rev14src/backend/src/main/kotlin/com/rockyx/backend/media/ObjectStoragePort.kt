package com.rockyx.backend.media

interface ObjectStoragePort {
    fun createUploadUrl(objectKey: String, contentType: String, checksum: String, expiresAtEpochMs: Long): String?
    fun createDownloadUrl(objectKey: String, expiresAtEpochMs: Long): String?
    /** Verifies an uploaded object against server-owned metadata before it enters quarantine. */
    fun verifyUploadedObject(objectKey: String, expectedSizeBytes: Long, expectedContentType: String, expectedSha256Hex: String): Boolean
    fun delete(objectKey: String): Boolean
}

/** Production adapter is intentionally not provider-coupled. Configure S3-compatible/CDN storage at deployment. */
class UnconfiguredObjectStorage : ObjectStoragePort {
    override fun createUploadUrl(objectKey: String, contentType: String, checksum: String, expiresAtEpochMs: Long): String? = null
    override fun createDownloadUrl(objectKey: String, expiresAtEpochMs: Long): String? = null
    override fun verifyUploadedObject(objectKey: String, expectedSizeBytes: Long, expectedContentType: String, expectedSha256Hex: String): Boolean = false
    override fun delete(objectKey: String): Boolean = false
}

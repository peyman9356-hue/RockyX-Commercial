package com.rockyx.backend.media

import java.util.concurrent.ConcurrentHashMap

interface MediaRepository {
    fun create(asset: MediaAsset) : MediaAsset
    fun getForUser(userId: String, mediaId: String): MediaAsset?
    fun markReady(userId: String, mediaId: String, checksum: String): MediaAsset?
    fun updateState(userId: String, mediaId: String, expectedState: String, newState: String): MediaAsset?
    fun getForSystem(mediaId: String): MediaAsset? = null
    fun updateSystemState(mediaId: String, expectedState: String, newState: String): Boolean = false
}

class InMemoryMediaRepository : MediaRepository {
    private val store = ConcurrentHashMap<String, MediaAsset>()
    override fun create(asset: MediaAsset): MediaAsset { store[asset.mediaId] = asset; return asset }
    override fun getForUser(userId: String, mediaId: String): MediaAsset? = store[mediaId]?.takeIf { it.userId == userId }
    override fun markReady(userId: String, mediaId: String, checksum: String): MediaAsset? = store.computeIfPresent(mediaId) { _, old ->
        if (old.userId != userId || old.checksum != checksum || old.state != "UPLOAD_PENDING") old else old.copy(state = "QUARANTINED", updatedAtEpochMs = System.currentTimeMillis())
    }
    override fun updateState(userId: String, mediaId: String, expectedState: String, newState: String): MediaAsset? = store.computeIfPresent(mediaId) { _, old ->
        if (old.userId != userId || old.state != expectedState) old else old.copy(state = newState, updatedAtEpochMs = System.currentTimeMillis())
    }
    override fun getForSystem(mediaId: String): MediaAsset? = store[mediaId]
    override fun updateSystemState(mediaId: String, expectedState: String, newState: String): Boolean {
        val old = store[mediaId] ?: return false
        if (old.state != expectedState) return false
        store[mediaId] = old.copy(state = newState, updatedAtEpochMs = System.currentTimeMillis())
        return true
    }

}

package com.rockyx.backend.api

/** Deterministic input limits. These are deliberately small and provider-neutral. */
object SecurityPolicy {
    const val MAX_IDEMPOTENCY_KEY = 128
    const val MAX_OPERATION_ID = 128
    const val MAX_ENTITY_TYPE = 64
    const val MAX_ENTITY_ID = 128
    const val MAX_PAYLOAD_JSON = 64 * 1024
    const val MAX_MISSION_ID = 128
    const val MAX_SUBMISSION_ID = 128
    const val MAX_CHECKSUM = 128

    fun validTokenHeader(value: String?): Boolean = value?.let {
        it.length in 7..16_384 && it.startsWith("Bearer ", ignoreCase = true) && it.substringAfter(' ').trim().isNotEmpty()
    } ?: false

    fun validOpaque(value: String?, max: Int): Boolean = value?.let {
        it.isNotBlank() && it.length <= max && it.none(Char::isISOControl)
    } ?: false

    fun validJsonPayload(value: String?): Boolean = value?.let {
        it.length <= MAX_PAYLOAD_JSON && it.isNotBlank()
    } ?: false

    fun validIdempotencyKey(value: String?): Boolean = validOpaque(value, MAX_IDEMPOTENCY_KEY)

    fun validChecksum(value: String?): Boolean = value?.matches(Regex("^[A-Fa-f0-9]{64}$")) == true
}

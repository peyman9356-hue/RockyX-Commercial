package com.rockyx.backend.infra

import com.rockyx.backend.domain.*
import java.util.concurrent.ConcurrentHashMap

interface IdempotencyRepository {
    fun get(userId: String, key: String): String?
    fun put(userId: String, key: String, responseJson: String)
}

class InMemoryIdempotencyRepository : IdempotencyRepository {
    private val values = ConcurrentHashMap<String, String>()
    override fun get(userId: String, key: String) = values["$userId:$key"]
    override fun put(userId: String, key: String, responseJson: String) { values["$userId:$key"] = responseJson }
}

interface AccountRepository { fun getOrCreate(userId: String): AccountResponse }
class InMemoryAccountRepository : AccountRepository {
    private val accounts = ConcurrentHashMap<String, AccountResponse>()
    override fun getOrCreate(userId: String): AccountResponse = accounts.computeIfAbsent(userId) {
        AccountResponse(it, System.currentTimeMillis(), 1)
    }
}

interface SyncRepository { fun accept(userId: String, request: SyncOperationRequest): SyncOperationResponse }
class InMemorySyncRepository : SyncRepository {
    private val accepted = ConcurrentHashMap<String, SyncOperationResponse>()
    override fun accept(userId: String, request: SyncOperationRequest): SyncOperationResponse = accepted.computeIfAbsent("$userId:${request.operationId}") {
        SyncOperationResponse(request.operationId, "ACCEPTED", System.currentTimeMillis())
    }
}

interface SubmissionRepository { fun create(userId: String, request: SubmissionCreateRequest): SubmissionResponse; fun get(userId: String, submissionId: String): SubmissionResponse? }
class InMemorySubmissionRepository : SubmissionRepository {
    private val submissions = ConcurrentHashMap<String, SubmissionResponse>()
    override fun create(userId: String, request: SubmissionCreateRequest): SubmissionResponse {
        require(request.visibility in setOf("PRIVATE", "UNLISTED", "PUBLIC")) { "Invalid visibility" }
        require(request.consentVersion > 0) { "Consent version is required" }
        return submissions.computeIfAbsent("$userId:${request.submissionId}") {
            SubmissionResponse(request.submissionId, userId, request.missionId, "PENDING_UPLOAD", request.visibility, System.currentTimeMillis())
        }
    }
    override fun get(userId: String, submissionId: String): SubmissionResponse? = submissions["$userId:$submissionId"]
}

interface EntitlementRepository {
    fun list(userId: String): List<EntitlementResponse>
    fun upsert(userId: String, entitlement: EntitlementResponse)
}

data class VerifiedPurchaseRecord(
    val userId: String,
    val productId: String,
    val purchaseTokenHash: String,
    val state: String,
    val acknowledged: Boolean,
    val updatedAtEpochMs: Long
)

interface PurchaseRepository {
    fun findByTokenHash(tokenHash: String): VerifiedPurchaseRecord?
    /** Atomically claims a token for the account. False means another account already owns it. */
    fun claim(record: VerifiedPurchaseRecord): Boolean
    fun upsert(record: VerifiedPurchaseRecord)
}

class InMemoryEntitlementRepository : EntitlementRepository {
    private val values = ConcurrentHashMap<String, EntitlementResponse>()
    override fun list(userId: String): List<EntitlementResponse> = values.filterKeys { it.startsWith("$userId:") }.values.toList()
    override fun upsert(userId: String, entitlement: EntitlementResponse) { values["$userId:${entitlement.productId}"] = entitlement }
}

class InMemoryPurchaseRepository : PurchaseRepository {
    private val values = ConcurrentHashMap<String, VerifiedPurchaseRecord>()
    override fun findByTokenHash(tokenHash: String) = values[tokenHash]
    override fun claim(record: VerifiedPurchaseRecord): Boolean = synchronized(values) {
        val existing = values[record.purchaseTokenHash]
        if (existing != null && existing.userId != record.userId) false else { values.putIfAbsent(record.purchaseTokenHash, record); true }
    }
    override fun upsert(record: VerifiedPurchaseRecord) { values[record.purchaseTokenHash] = record }
}

/** Durable RTDN message deduplication boundary. */
interface RtdnMessageRepository {
    /** Returns true only when the message may be processed by this worker. */
    fun claim(messageId: String, nowEpochMs: Long = System.currentTimeMillis()): Boolean
    fun markProcessed(messageId: String, processedAtEpochMs: Long = System.currentTimeMillis())
}

class InMemoryRtdnMessageRepository : RtdnMessageRepository {
    private val values = ConcurrentHashMap<String, Long>()
    override fun claim(messageId: String, nowEpochMs: Long): Boolean = synchronized(values) {
        if (values.containsKey(messageId)) false else { values[messageId] = -nowEpochMs; true }
    }
    override fun markProcessed(messageId: String, processedAtEpochMs: Long) { values[messageId] = processedAtEpochMs }
}

/** Durable first-party authentication sessions. Refresh tokens are stored only as SHA-256 hashes. */
data class AuthSessionRecord(
    val sessionId: String,
    val userId: String,
    val provider: String,
    val refreshTokenHash: String,
    val expiresAtEpochMs: Long,
    val revoked: Boolean,
    val createdAtEpochMs: Long,
    val scopes: Set<String> = emptySet(),
    val roles: Set<String> = emptySet()
)

interface AuthSessionRepository {
    fun create(record: AuthSessionRecord)
    fun findActiveByRefreshHash(hash: String, nowEpochMs: Long): AuthSessionRecord?
    /** Atomically consumes a refresh token so concurrent rotation cannot mint multiple sessions. */
    fun consumeActiveByRefreshHash(hash: String, nowEpochMs: Long): AuthSessionRecord?
    fun isActive(sessionId: String, nowEpochMs: Long): Boolean
    fun revoke(sessionId: String, nowEpochMs: Long)
}

class InMemoryAuthSessionRepository : AuthSessionRepository {
    private val values = java.util.concurrent.ConcurrentHashMap<String, AuthSessionRecord>()
    override fun create(record: AuthSessionRecord) { values[record.sessionId] = record }
    override fun findActiveByRefreshHash(hash: String, nowEpochMs: Long): AuthSessionRecord? = values.values.firstOrNull { it.refreshTokenHash == hash && !it.revoked && it.expiresAtEpochMs > nowEpochMs }
    override fun consumeActiveByRefreshHash(hash: String, nowEpochMs: Long): AuthSessionRecord? = synchronized(values) {
        val current = values.values.firstOrNull { it.refreshTokenHash == hash && !it.revoked && it.expiresAtEpochMs > nowEpochMs } ?: return@synchronized null
        values[current.sessionId] = current.copy(revoked = true)
        current
    }
    override fun isActive(sessionId: String, nowEpochMs: Long): Boolean = values[sessionId]?.let { !it.revoked && it.expiresAtEpochMs > nowEpochMs } == true
    override fun revoke(sessionId: String, nowEpochMs: Long) { values.computeIfPresent(sessionId) { _, r -> r.copy(revoked = true) } }
}

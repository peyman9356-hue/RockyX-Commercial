package com.rockyx.backend.domain

import kotlinx.serialization.Serializable

@Serializable
data class AccountProfileResponse(
    val userId: String,
    val displayName: String? = null,
    val locale: String? = null,
    val timeZone: String? = null,
    val onboardingVersion: Int = 1,
    val profileVersion: Int = 1
)

@Serializable
data class AccountProfileUpdateRequest(
    val displayName: String? = null,
    val locale: String? = null,
    val timeZone: String? = null,
    val onboardingVersion: Int = 1
)

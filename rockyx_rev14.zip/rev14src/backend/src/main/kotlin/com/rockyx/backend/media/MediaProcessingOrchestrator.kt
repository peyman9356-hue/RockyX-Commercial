package com.rockyx.backend.media

import java.nio.file.Files
import java.nio.file.Path
import java.util.UUID

class MediaProcessingOrchestrator(
    private val media: MediaRepository,
    private val artifacts: MediaArtifactStore,
    private val processor: MediaProcessor,
    private val metadataWriter: MediaProcessingMetadataWriter
) {
    fun process(mediaId: String): ProcessingResult {
        val asset = media.getForSystem(mediaId) ?: throw IllegalArgumentException("MEDIA_NOT_FOUND")
        require(asset.state == "QUARANTINED") { "MEDIA_NOT_PROCESSABLE" }
        val workspace = Files.createTempDirectory("rockyx-media-${UUID.randomUUID()}-")
        val original = workspace.resolve("original")
        return try {
            require(artifacts.download(asset.objectKey, original)) { "ORIGINAL_DOWNLOAD_FAILED" }
            val result = processor.process(original, workspace, "processed/$mediaId")
            result.variants.forEach { variant ->
                val source = workspace.resolve("${variant.name}.mp4")
                require(artifacts.upload(source, variant.objectKey, variant.contentType, variant.checksumSha256)) { "VARIANT_UPLOAD_FAILED" }
            }
            val thumbnail = workspace.resolve("thumbnail.jpg")
            require(artifacts.upload(thumbnail, result.thumbnailObjectKey, "image/jpeg", result.thumbnailChecksumSha256)) { "THUMBNAIL_UPLOAD_FAILED" }
            metadataWriter.persist(mediaId, result)
            result
        } finally {
            workspace.toFile().deleteRecursively()
        }
    }
}

interface MediaProcessingMetadataWriter {
    fun persist(mediaId: String, result: ProcessingResult)
}

class NoopMediaProcessingMetadataWriter : MediaProcessingMetadataWriter {
    override fun persist(mediaId: String, result: ProcessingResult) = Unit
}

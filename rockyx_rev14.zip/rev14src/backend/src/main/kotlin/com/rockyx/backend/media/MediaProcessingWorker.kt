package com.rockyx.backend.media

import kotlinx.coroutines.*
import java.util.UUID

interface MediaJobRepository {
    fun enqueue(mediaId: String): Boolean
    fun claimNext(workerId: String): String?
    fun complete(mediaId: String, outcome: String): Boolean
    fun fail(mediaId: String, message: String): Boolean
}

class MediaProcessingWorker(
    private val jobs: MediaJobRepository,
    private val media: MediaRepository,
    private val scanner: MediaSecurityScanner,
    private val intervalMs: Long = 2_000L
) {
    private val workerId = "worker-${UUID.randomUUID()}"
    private var job: Job? = null

    fun start(scope: CoroutineScope): Job {
        if (job != null) return job!!
        job = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val mediaId = jobs.claimNext(workerId)
                if (mediaId == null) delay(intervalMs) else process(mediaId)
            }
        }
        return job!!
    }

    fun stop() { job?.cancel(); job = null }

    private fun process(mediaId: String) {
        try {
            val asset = media.getForSystem(mediaId) ?: run { jobs.fail(mediaId, "MEDIA_NOT_FOUND"); return }
            val result = scanner.scan(asset)
            when {
                result.malware == "PASS" && result.mediaValidation == "PASS" && result.moderation == "PASS" -> {
                    media.updateSystemState(mediaId, "QUARANTINED", "READY")
                    jobs.complete(mediaId, "READY")
                }
                listOf(result.malware, result.mediaValidation, result.moderation).any { it == "FAIL" } -> {
                    media.updateSystemState(mediaId, "QUARANTINED", "REJECTED")
                    jobs.complete(mediaId, "REJECTED")
                }
                else -> jobs.fail(mediaId, "SECURITY_PIPELINE_NOT_CONFIGURED")
            }
        } catch (t: Throwable) { jobs.fail(mediaId, t.message ?: "PROCESSING_FAILED") }
    }
}

package com.rockyx.backend.infra.db

import com.rockyx.backend.media.MediaJobRepository
import java.time.OffsetDateTime
import javax.sql.DataSource

class PostgresMediaJobRepository(private val ds: DataSource) : MediaJobRepository {
    override fun enqueue(mediaId: String): Boolean = ds.connection.use { c ->
        c.prepareStatement("INSERT INTO media_processing_jobs(media_id,status) VALUES (?, 'QUEUED') ON CONFLICT (media_id) DO UPDATE SET status='QUEUED', available_at=now(), last_error=NULL WHERE media_processing_jobs.status IN ('FAILED','QUEUED')").use { ps ->
            ps.setString(1, mediaId); ps.executeUpdate() == 1
        }
    }

    override fun claimNext(workerId: String): String? = ds.connection.use { c ->
        c.autoCommit = false
        try {
            val id = c.prepareStatement("SELECT job_id,media_id FROM media_processing_jobs WHERE status='QUEUED' AND available_at <= now() ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1").use { ps ->
                ps.executeQuery().use { rs -> if (rs.next()) Pair(rs.getObject(1, java.util.UUID::class.java), rs.getString(2)) else null }
            } ?: run { c.rollback(); return@use null }
            c.prepareStatement("UPDATE media_processing_jobs SET status='PROCESSING', locked_by=?, locked_at=now(), attempts=attempts+1 WHERE job_id=?").use { ps ->
                ps.setString(1, workerId); ps.setObject(2, id.first); ps.executeUpdate()
            }
            c.commit(); id.second
        } catch (t: Throwable) { c.rollback(); throw t }
    }

    override fun complete(mediaId: String, outcome: String): Boolean = update(mediaId, "COMPLETED", outcome)
    override fun fail(mediaId: String, message: String): Boolean = ds.connection.use { c ->
        c.prepareStatement("UPDATE media_processing_jobs SET status='FAILED', last_error=?, available_at=now() + interval '30 seconds' WHERE media_id=? AND status='PROCESSING'").use { ps ->
            ps.setString(1, message.take(1000)); ps.setString(2, mediaId); ps.executeUpdate() == 1
        }
    }

    private fun update(mediaId: String, status: String, result: String): Boolean = ds.connection.use { c ->
        c.prepareStatement("UPDATE media_processing_jobs SET status=?, result=?, completed_at=now(), last_error=NULL WHERE media_id=? AND status='PROCESSING'").use { ps ->
            ps.setString(1, status); ps.setString(2, result); ps.setString(3, mediaId); ps.executeUpdate() == 1
        }
    }
}

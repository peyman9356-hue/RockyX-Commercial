ALTER TABLE media_assets
    ADD COLUMN IF NOT EXISTS original_object_key TEXT,
    ADD COLUMN IF NOT EXISTS duration_ms BIGINT,
    ADD COLUMN IF NOT EXISTS width INT,
    ADD COLUMN IF NOT EXISTS height INT,
    ADD COLUMN IF NOT EXISTS video_codec TEXT,
    ADD COLUMN IF NOT EXISTS audio_codec TEXT,
    ADD COLUMN IF NOT EXISTS bitrate BIGINT,
    ADD COLUMN IF NOT EXISTS frame_rate DOUBLE PRECISION,
    ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS media_variants (
    variant_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    media_id TEXT NOT NULL REFERENCES media_assets(media_id) ON DELETE CASCADE,
    variant_name TEXT NOT NULL,
    object_key TEXT NOT NULL,
    content_type TEXT NOT NULL,
    width INT NOT NULL,
    height INT NOT NULL,
    bitrate BIGINT NOT NULL,
    checksum_sha256 TEXT NOT NULL,
    size_bytes BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (media_id, variant_name)
);

CREATE INDEX IF NOT EXISTS idx_media_variants_media ON media_variants(media_id);

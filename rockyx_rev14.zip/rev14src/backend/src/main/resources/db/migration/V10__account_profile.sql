ALTER TABLE accounts
    ADD COLUMN display_name TEXT,
    ADD COLUMN locale TEXT,
    ADD COLUMN time_zone TEXT,
    ADD COLUMN onboarding_version INTEGER NOT NULL DEFAULT 1,
    ADD COLUMN profile_version INTEGER NOT NULL DEFAULT 1;

ALTER TABLE accounts
    ADD CONSTRAINT accounts_display_name_length CHECK (display_name IS NULL OR char_length(display_name) <= 80),
    ADD CONSTRAINT accounts_locale_length CHECK (locale IS NULL OR char_length(locale) <= 32),
    ADD CONSTRAINT accounts_timezone_length CHECK (time_zone IS NULL OR char_length(time_zone) <= 64);

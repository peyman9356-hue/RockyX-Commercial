CREATE TABLE dogs (
    dog_id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    breed TEXT,
    date_of_birth TIMESTAMPTZ,
    sex TEXT,
    weight_grams INTEGER,
    activity_baseline INTEGER,
    profile_version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT dogs_owner_dog_unique UNIQUE (dog_id, owner_user_id),
    CONSTRAINT dogs_name_length CHECK (char_length(name) BETWEEN 1 AND 80),
    CONSTRAINT dogs_breed_length CHECK (breed IS NULL OR char_length(breed) <= 80),
    CONSTRAINT dogs_sex_length CHECK (sex IS NULL OR char_length(sex) <= 32),
    CONSTRAINT dogs_weight_valid CHECK (weight_grams IS NULL OR weight_grams BETWEEN 1 AND 300000),
    CONSTRAINT dogs_activity_valid CHECK (activity_baseline IS NULL OR activity_baseline BETWEEN 0 AND 100),
    CONSTRAINT dogs_profile_version_valid CHECK (profile_version >= 1)
);
CREATE INDEX idx_dogs_owner_updated ON dogs(owner_user_id, updated_at DESC);

CREATE TABLE dog_events (
    event_id TEXT PRIMARY KEY,
    dog_id TEXT NOT NULL,
    owner_user_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload_json JSONB NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT dog_events_dog_owner_fk FOREIGN KEY (dog_id, owner_user_id) REFERENCES dogs(dog_id, owner_user_id) ON DELETE CASCADE,
    CONSTRAINT dog_events_type_length CHECK (char_length(event_type) BETWEEN 1 AND 64),
    CONSTRAINT dog_events_payload_size CHECK (pg_column_size(payload_json) <= 100000)
);
CREATE INDEX idx_dog_events_dog_occurred ON dog_events(dog_id, occurred_at DESC);

CREATE TABLE devices (
    device_id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    dog_id TEXT,
    device_type TEXT NOT NULL,
    hardware_revision TEXT,
    firmware_version TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    last_seen_at TIMESTAMPTZ,
    battery_percent INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT devices_dog_owner_fk FOREIGN KEY (dog_id, owner_user_id) REFERENCES dogs(dog_id, owner_user_id) ON DELETE SET NULL (dog_id),
    CONSTRAINT devices_type_length CHECK (char_length(device_type) BETWEEN 1 AND 64),
    CONSTRAINT devices_hardware_length CHECK (hardware_revision IS NULL OR char_length(hardware_revision) <= 64),
    CONSTRAINT devices_firmware_length CHECK (firmware_version IS NULL OR char_length(firmware_version) <= 64),
    CONSTRAINT devices_status_length CHECK (char_length(status) BETWEEN 1 AND 32),
    CONSTRAINT devices_battery_valid CHECK (battery_percent IS NULL OR battery_percent BETWEEN 0 AND 100)
);
CREATE INDEX idx_devices_owner_dog ON devices(owner_user_id, dog_id);

CREATE TABLE vet_access_grants (
    grant_id TEXT PRIMARY KEY,
    dog_id TEXT NOT NULL,
    owner_user_id TEXT NOT NULL,
    vet_subject_id TEXT NOT NULL,
    access_level TEXT NOT NULL,
    expires_at TIMESTAMPTZ,
    revoked BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT vet_access_dog_owner_fk FOREIGN KEY (dog_id, owner_user_id) REFERENCES dogs(dog_id, owner_user_id) ON DELETE CASCADE,
    CONSTRAINT vet_access_subject_length CHECK (char_length(vet_subject_id) BETWEEN 1 AND 128),
    CONSTRAINT vet_access_level_valid CHECK (access_level IN ('VIEW','VIEW_HEALTH','EDIT'))
);
CREATE INDEX idx_vet_access_dog_active ON vet_access_grants(dog_id, revoked, expires_at);

CREATE TABLE safety_events (
    safety_event_id TEXT PRIMARY KEY,
    dog_id TEXT NOT NULL,
    owner_user_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    status TEXT NOT NULL,
    latitude_e6 INTEGER,
    longitude_e6 INTEGER,
    accuracy_meters INTEGER,
    occurred_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT safety_events_dog_owner_fk FOREIGN KEY (dog_id, owner_user_id) REFERENCES dogs(dog_id, owner_user_id) ON DELETE CASCADE,
    CONSTRAINT safety_event_type_length CHECK (char_length(event_type) BETWEEN 1 AND 64),
    CONSTRAINT safety_event_status_length CHECK (char_length(status) BETWEEN 1 AND 64),
    CONSTRAINT safety_lat_valid CHECK (latitude_e6 IS NULL OR latitude_e6 BETWEEN -90000000 AND 90000000),
    CONSTRAINT safety_lon_valid CHECK (longitude_e6 IS NULL OR longitude_e6 BETWEEN -180000000 AND 180000000),
    CONSTRAINT safety_accuracy_valid CHECK (accuracy_meters IS NULL OR accuracy_meters BETWEEN 0 AND 100000),
    CONSTRAINT safety_coordinates_pair CHECK ((latitude_e6 IS NULL) = (longitude_e6 IS NULL))
);
CREATE INDEX idx_safety_events_dog_occurred ON safety_events(dog_id, occurred_at DESC);

CREATE TABLE ai_insights (
    insight_id TEXT PRIMARY KEY,
    dog_id TEXT NOT NULL,
    owner_user_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    evidence_json JSONB NOT NULL,
    inference_json JSONB NOT NULL,
    recommendation_json JSONB NOT NULL,
    confidence INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ai_insights_dog_owner_fk FOREIGN KEY (dog_id, owner_user_id) REFERENCES dogs(dog_id, owner_user_id) ON DELETE CASCADE,
    CONSTRAINT ai_insights_kind_length CHECK (char_length(kind) BETWEEN 1 AND 64),
    CONSTRAINT ai_insights_confidence_valid CHECK (confidence BETWEEN 0 AND 100),
    CONSTRAINT ai_insights_evidence_size CHECK (pg_column_size(evidence_json) <= 100000),
    CONSTRAINT ai_insights_inference_size CHECK (pg_column_size(inference_json) <= 100000),
    CONSTRAINT ai_insights_recommendation_size CHECK (pg_column_size(recommendation_json) <= 100000)
);
CREATE INDEX idx_ai_insights_dog_created ON ai_insights(dog_id, created_at DESC);

CREATE TABLE google_play_rtdn_messages (
    message_id TEXT PRIMARY KEY,
    received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    processing_started_at TIMESTAMPTZ NULL,
    processed_at TIMESTAMPTZ NULL
);
CREATE INDEX idx_google_play_rtdn_unprocessed ON google_play_rtdn_messages(received_at) WHERE processed_at IS NULL;

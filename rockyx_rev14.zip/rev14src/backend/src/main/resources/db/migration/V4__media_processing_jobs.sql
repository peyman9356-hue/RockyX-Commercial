CREATE TABLE media_processing_jobs (
    job_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    media_id TEXT NOT NULL REFERENCES media_assets(media_id) ON DELETE CASCADE,
    status TEXT NOT NULL,
    attempts INT NOT NULL DEFAULT 0,
    available_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    locked_by TEXT,
    locked_at TIMESTAMPTZ,
    result TEXT,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    CONSTRAINT uq_media_processing_job UNIQUE (media_id)
);
CREATE INDEX idx_media_processing_jobs_claim ON media_processing_jobs(status, available_at, created_at);

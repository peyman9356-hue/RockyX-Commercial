CREATE TABLE auth_sessions (
    session_id UUID PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    provider TEXT NOT NULL,
    refresh_token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at TIMESTAMPTZ,
    scopes TEXT NOT NULL DEFAULT '',
    roles TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_auth_sessions_user_active ON auth_sessions(user_id, revoked, expires_at DESC);
CREATE INDEX idx_auth_sessions_expiry ON auth_sessions(expires_at);

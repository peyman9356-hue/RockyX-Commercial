CREATE TABLE accounts (
    user_id TEXT PRIMARY KEY,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    account_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE sync_operations (
    operation_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    payload_version INTEGER NOT NULL,
    payload_json JSONB NOT NULL,
    client_changed_at TIMESTAMPTZ NOT NULL,
    server_accepted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sync_operations_user_accepted ON sync_operations(user_id, server_accepted_at DESC);
CREATE INDEX idx_sync_operations_entity ON sync_operations(user_id, entity_type, entity_id);

CREATE TABLE submissions (
    submission_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    mission_id TEXT NOT NULL,
    state TEXT NOT NULL,
    visibility TEXT NOT NULL,
    consent_version INTEGER NOT NULL,
    media_checksum TEXT NOT NULL,
    server_updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_submissions_user_updated ON submissions(user_id, server_updated_at DESC);
CREATE INDEX idx_submissions_mission ON submissions(user_id, mission_id);

CREATE TABLE idempotency_keys (
    user_id TEXT NOT NULL,
    key TEXT NOT NULL,
    response_json JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, key)
);
CREATE INDEX idx_idempotency_created_at ON idempotency_keys(created_at);

CREATE TABLE entitlements (
    user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    product_id TEXT NOT NULL,
    tier TEXT NOT NULL,
    state TEXT NOT NULL,
    starts_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    source TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, product_id)
);
CREATE INDEX idx_entitlements_user_state ON entitlements(user_id, state, expires_at);

CREATE TABLE google_play_purchases (
    purchase_token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES accounts(user_id) ON DELETE CASCADE,
    product_id TEXT NOT NULL,
    state TEXT NOT NULL,
    acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_google_play_purchases_user ON google_play_purchases(user_id, updated_at DESC);

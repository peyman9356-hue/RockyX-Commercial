CREATE TABLE media_security_events (
    event_id UUID PRIMARY KEY,
    media_id TEXT NOT NULL REFERENCES media_assets(media_id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    result TEXT NOT NULL,
    details TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_media_security_events_media_created ON media_security_events(media_id, created_at DESC);

CREATE TABLE media_moderation_decisions (
    media_id TEXT PRIMARY KEY REFERENCES media_assets(media_id) ON DELETE CASCADE,
    decision TEXT NOT NULL,
    reason_code TEXT,
    reviewer_type TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

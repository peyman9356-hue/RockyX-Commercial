CREATE TABLE content_documents (
    content_id TEXT PRIMARY KEY,
    locale TEXT NOT NULL,
    content_version TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('DRAFT','PUBLISHED','ARCHIVED')),
    revision INTEGER NOT NULL CHECK (revision > 0),
    schema_version INTEGER NOT NULL CHECK (schema_version > 0),
    catalog_json JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    published_at TIMESTAMPTZ
);
CREATE INDEX idx_content_documents_locale_status ON content_documents(locale,status,published_at DESC);

CREATE TABLE content_revisions (
    content_id TEXT NOT NULL REFERENCES content_documents(content_id) ON DELETE CASCADE,
    revision INTEGER NOT NULL,
    locale TEXT NOT NULL,
    content_version TEXT NOT NULL,
    schema_version INTEGER NOT NULL,
    catalog_json JSONB NOT NULL,
    created_by TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(content_id, revision)
);

CREATE TABLE content_audit_events (
    event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id TEXT NOT NULL REFERENCES content_documents(content_id) ON DELETE CASCADE,
    actor_user_id TEXT NOT NULL,
    action TEXT NOT NULL,
    revision INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_content_audit_content_created ON content_audit_events(content_id,created_at DESC);

package com.rockyx.backend

import com.rockyx.backend.ai.*
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class PersonalizationTest {
    @Test fun `completed lessons are excluded and ranking is deterministic`() {
        val provider = LocalPersonalizationProvider()
        val request = AiRecommendationRequest(2, "Beginner", listOf("leash"), listOf("pulling"), listOf(
            AiLessonSignal("b", listOf("leash"), durationMinutes = 10),
            AiLessonSignal("a", listOf("leash"), durationMinutes = 10, inProgress = true),
            AiLessonSignal("done", listOf("leash"), completed = true)
        ), 3)
        val result = provider.recommend(request)
        assertEquals(listOf("a", "b"), result.map { it.lessonId })
        assertTrue(result.first().confidence >= result.last().confidence)
    }

    @Test fun `safety policy rejects oversized limits`() {
        val request = AiRecommendationRequest(1, "Beginner", lessons = emptyList(), limit = 21)
        kotlin.test.assertFails { PersonalizationSafetyPolicy.validate(request) }
    }
}

package com.rockyx.backend

import com.rockyx.backend.auth.SessionManager
import com.rockyx.backend.auth.SessionSecurityConfig
import com.rockyx.backend.infra.InMemoryAuthSessionRepository
import java.security.KeyPairGenerator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue
import kotlin.test.assertNull

class SessionScopePreservationTest {
    @Test
    fun issuedAndRotatedSessionsPreserveExactScopesAndRoles() {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val privateKey = kp.private as java.security.interfaces.RSAPrivateCrtKey
        val repository = InMemoryAuthSessionRepository()
        val manager = SessionManager(
            SessionSecurityConfig("https://issuer.example", "rockyx-mobile", "test-key", privateKey, 300, 3600),
            repository
        )
        val scopes = setOf("account:read")
        val roles = setOf("user")

        val first = manager.issue("u1", "google", scopes, roles, 1000)
        val firstStored = repository.findActiveByRefreshHash(SessionManager.hash(first.refreshToken), 1000)
        assertNotNull(firstStored)
        assertEquals(scopes, firstStored.scopes)
        assertEquals(roles, firstStored.roles)

        val second = manager.rotate(first.refreshToken, 2000)
        assertNotNull(second)
        val secondStored = repository.findActiveByRefreshHash(SessionManager.hash(second.refreshToken), 2000)
        assertNotNull(secondStored)
        assertEquals(scopes, secondStored.scopes)
        assertEquals(roles, secondStored.roles)
    }

    @Test
    fun concurrentStyleSecondConsumptionOfSameRefreshTokenIsRejected() {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val privateKey = kp.private as java.security.interfaces.RSAPrivateCrtKey
        val repository = InMemoryAuthSessionRepository()
        val manager = SessionManager(
            SessionSecurityConfig("https://issuer.example", "rockyx-mobile", "test-key", privateKey, 300, 3600),
            repository
        )
        val first = manager.issue("u3", "google", setOf("account:read"), setOf("user"), 1000)
        val rotated = manager.rotate(first.refreshToken, 2000)
        assertNotNull(rotated)
        assertNull(manager.rotate(first.refreshToken, 2000))
    }

    @Test
    fun emptyScopeSetDoesNotGainImplicitPrivileges() {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val privateKey = kp.private as java.security.interfaces.RSAPrivateCrtKey
        val repository = InMemoryAuthSessionRepository()
        val manager = SessionManager(
            SessionSecurityConfig("https://issuer.example", "rockyx-mobile", "test-key", privateKey, 300, 3600),
            repository
        )

        val issued = manager.issue("u2", "google", emptySet(), emptySet(), 1000)
        val stored = repository.findActiveByRefreshHash(SessionManager.hash(issued.refreshToken), 1000)
        assertNotNull(stored)
        assertTrue(stored.scopes.isEmpty())
        assertTrue(stored.roles.isEmpty())
    }
}

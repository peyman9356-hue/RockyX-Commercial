package com.rockyx.backend.auth

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class AuthPolicyTest {
    @Test
    fun rejectAllVerifierFailsClosed() = kotlinx.coroutines.runBlocking {
        assertFalse(RejectAllTokenVerifier().verify("anything") != null)
    }

    @Test
    fun scopeAndRoleChecksAreExact() {
        val principal = AuthenticatedPrincipal("u1", "issuer", setOf("account:read"), setOf("user"))
        assertTrue(principal.hasScope("account:read"))
        assertFalse(principal.hasScope("account:write"))
        assertTrue(principal.hasRole("user"))
        assertFalse(principal.hasRole("admin"))
    }
}

package com.rockyx.backend

import com.rockyx.backend.auth.SessionManager
import com.rockyx.backend.auth.SessionSecurityConfig
import com.rockyx.backend.auth.publicKey
import com.rockyx.backend.infra.InMemoryAuthSessionRepository
import java.security.KeyPairGenerator
import java.time.Instant
import kotlin.test.Test
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class SessionAuthTest {
    private fun manager(): SessionManager {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val privateKey = kp.private as java.security.interfaces.RSAPrivateCrtKey
        return SessionManager(SessionSecurityConfig("https://issuer.example", "rockyx-mobile", "test-key", privateKey, 300, 3600), InMemoryAuthSessionRepository())
    }

    @Test fun refreshRotationInvalidatesOldToken() {
        val m=manager(); val first=m.issue("u1","oidc",setOf("account:read"),emptySet(),1000)
        val second=m.rotate(first.refreshToken,2000)
        assertNotNull(second)
        assertNull(m.rotate(first.refreshToken,2001))
    }

    @Test fun expiredRefreshTokenIsRejected() {
        val m=manager(); val first=m.issue("u1","oidc",emptySet(),emptySet(),1000)
        assertNull(m.rotate(first.refreshToken,4_000_001))
    }
    @Test fun revokedSessionMakesExistingAccessTokenInvalid() = kotlinx.coroutines.test.runTest {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val privateKey = kp.private as java.security.interfaces.RSAPrivateCrtKey
        val repository = InMemoryAuthSessionRepository()
        val config = SessionSecurityConfig("https://issuer.example", "rockyx-mobile", "test-key", privateKey, 300, 3600)
        val manager = SessionManager(config, repository)
        val now = Instant.now().epochSecond
        val tokens = manager.issue("u1", "google", setOf("account:read"), emptySet(), now)
        val verifier = com.rockyx.backend.auth.SessionAccessTokenVerifier(config, config.publicKey(), repository)
        assertNotNull(verifier.verify(tokens.accessToken))
        manager.revoke(tokens.refreshToken, now + 1)
        assertNull(verifier.verify(tokens.accessToken))
    }

}

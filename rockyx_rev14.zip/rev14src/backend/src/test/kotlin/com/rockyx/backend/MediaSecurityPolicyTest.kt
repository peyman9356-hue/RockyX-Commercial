package com.rockyx.backend

import com.rockyx.backend.media.MediaSecurityPolicy
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class MediaSecurityPolicyTest {
    @Test fun acceptsSupportedVideoWithSha256() {
        assertNull(MediaSecurityPolicy.validateUpload("video/mp4", 1024, "a".repeat(64)))
    }
    @Test fun rejectsUnsupportedType() {
        assertEquals("UNSUPPORTED_MEDIA_TYPE", MediaSecurityPolicy.validateUpload("application/octet-stream", 1024, "a".repeat(64)))
    }
    @Test fun rejectsInvalidChecksum() {
        assertEquals("INVALID_CHECKSUM", MediaSecurityPolicy.validateUpload("video/mp4", 1024, "bad"))
    }
}

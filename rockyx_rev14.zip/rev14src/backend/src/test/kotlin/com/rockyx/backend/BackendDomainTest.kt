package com.rockyx.backend

import com.rockyx.backend.infra.*
import com.rockyx.backend.domain.*
import kotlin.test.Test
import kotlin.test.assertEquals

class BackendDomainTest {
    @Test fun `sync operation is idempotent`() {
        val repo = InMemorySyncRepository()
        val req = SyncOperationRequest("op-1", "DOG_PROFILE", "dog-1", 1, "{}", 10)
        val a = repo.accept("user-1", req)
        val b = repo.accept("user-1", req)
        assertEquals(a, b)
    }

    @Test fun `submission defaults to pending upload`() {
        val repo = InMemorySubmissionRepository()
        val result = repo.create("user-1", SubmissionCreateRequest("s1", "m1", "PRIVATE", 1, "sha256"))
        assertEquals("PENDING_UPLOAD", result.state)
    }
}

// Phase 15: media security policy tests are kept pure so they run without external services.

package com.rockyx.backend

import com.rockyx.backend.api.SecurityPolicy
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class SecurityPolicyTest {
    @Test fun `idempotency keys are bounded`() {
        assertTrue(SecurityPolicy.validIdempotencyKey("request-123"))
        assertFalse(SecurityPolicy.validIdempotencyKey("x".repeat(129)))
        assertFalse(SecurityPolicy.validIdempotencyKey("bad\nkey"))
    }

    @Test fun `payload is bounded`() {
        assertTrue(SecurityPolicy.validJsonPayload("{}"))
        assertFalse(SecurityPolicy.validJsonPayload("x".repeat(SecurityPolicy.MAX_PAYLOAD_JSON + 1)))
    }

    @Test fun `checksums require sha256 hex`() {
        assertTrue(SecurityPolicy.validChecksum("a".repeat(64)))
        assertFalse(SecurityPolicy.validChecksum("a".repeat(63)))
        assertFalse(SecurityPolicy.validChecksum("g".repeat(64)))
    }

    @Test fun `authorization header must be bounded bearer`() {
        assertTrue(SecurityPolicy.validTokenHeader("Bearer abc"))
        assertFalse(SecurityPolicy.validTokenHeader("Basic abc"))
        assertFalse(SecurityPolicy.validTokenHeader("Bearer " + "x".repeat(16_385)))
    }
}

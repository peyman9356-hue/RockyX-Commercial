package com.rockyx.backend

import com.rockyx.backend.domain.*
import com.rockyx.backend.infra.InMemoryEcosystemRepository
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class EcosystemFoundationTest {
    private val repo = InMemoryEcosystemRepository()

    @Test
    fun dogIdentitySupportsMultipleDogsAndVersioning() {
        val a = repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky", "American Akita", weightGrams = 50000))
        val b = repo.upsertDog("u1", DogUpsertRequest("dog-b", "Luna", "Mixed"))
        assertEquals(2, repo.listDogs("u1").size)
        val a2 = repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky X", expectedProfileVersion = a.profileVersion, weightGrams = 51000))
        assertEquals(a.profileVersion + 1, a2.profileVersion)
        assertEquals("Rocky X", repo.getDog("u1", a.dogId)?.name)
        assertNotNull(b)
    }

    @Test
    fun eventsAreScopedToTheOwnerDogAndIdempotent() {
        repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky"))
        val request = DogEventCreateRequest("evt-1", "dog-a", "BEHAVIOR_OBSERVED", "{\"behavior\":\"calm\"}", 1000)
        repo.addDogEvent("u1", request)
        repo.addDogEvent("u1", request)
        assertEquals(1, repo.listDogEvents("u1", "dog-a").size)
        assertNull(repo.getDog("u2", "dog-a"))
    }

    @Test
    fun vetAccessExpiresAndCanBeRevoked() {
        repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky"))
        repo.createVetAccess("u1", VetAccessCreateRequest("grant-1", "dog-a", "vet-1", "VIEW"))
        assertNotNull(repo.getDogForVet("vet-1", "dog-a"))
        assertEquals(1, repo.listVetAccess("u1", "dog-a").size)
        assertEquals(true, repo.revokeVetAccess("u1", "grant-1"))
        assertNull(repo.getDogForVet("vet-1", "dog-a"))
    }

    @Test
    fun deviceAndSafetyDataStayBoundToOwnerDog() {
        repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky"))
        repo.upsertDevice("u1", DeviceUpsertRequest("module-1", "dog-a", "SMART_MODULE", batteryPercent = 88))
        repo.addSafetyEvent("u1", SafetyEventCreateRequest("safe-1", "dog-a", "LOCATION", "RECORDED", 29700000, 60700000, 8, 2000))
        assertEquals(1, repo.listDevices("u1", "dog-a").size)
        assertEquals(1, repo.listSafetyEvents("u1", "dog-a").size)
        assertEquals(0, repo.listDevices("u2", "dog-a").size)
    }
    @Test
    fun idempotencyKeysCannotCrossOwnerBoundaries() {
        repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky"))
        repo.upsertDog("u2", DogUpsertRequest("dog-b", "Luna"))
        val event = DogEventCreateRequest("shared-id", "dog-a", "BEHAVIOR", "{}", 1000)
        repo.addDogEvent("u1", event)
        kotlin.test.assertFailsWith<IllegalArgumentException> {
            repo.addDogEvent("u2", event.copy(dogId = "dog-b"))
        }
    }

    @Test
    fun safetyCoordinatesMustBeCompleteAndValid() {
        repo.upsertDog("u1", DogUpsertRequest("dog-a", "Rocky"))
        kotlin.test.assertFailsWith<IllegalArgumentException> {
            repo.addSafetyEvent("u1", SafetyEventCreateRequest("s1", "dog-a", "LOCATION", "RECORDED", latitudeE6 = 100000000, longitudeE6 = 0, occurredAtEpochMs = 1000))
        }
        kotlin.test.assertFailsWith<IllegalArgumentException> {
            repo.addSafetyEvent("u1", SafetyEventCreateRequest("s2", "dog-a", "LOCATION", "RECORDED", latitudeE6 = 1000, longitudeE6 = null, occurredAtEpochMs = 1000))
        }
    }

}

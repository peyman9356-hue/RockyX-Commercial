package com.rockyx.backend

import com.rockyx.backend.infra.InMemoryEntitlementRepository
import com.rockyx.backend.infra.InMemoryPurchaseRepository
import com.rockyx.backend.infra.VerifiedPurchaseRecord
import com.rockyx.backend.domain.EntitlementResponse
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class BillingPolicyTest {
    @Test fun `purchase token cannot be linked to two users in repository layer`() {
        val repo = InMemoryPurchaseRepository()
        repo.upsert(VerifiedPurchaseRecord("u1", "pro_monthly", "hash", "ACTIVE", true, 1L))
        val found = repo.findByTokenHash("hash")
        assertNotNull(found)
        assertEquals("u1", found.userId)
    }

    @Test fun `entitlement repository replaces same product deterministically`() {
        val repo = InMemoryEntitlementRepository()
        repo.upsert("u1", EntitlementResponse("pro_monthly", "PRO", "ACTIVE", 100L))
        repo.upsert("u1", EntitlementResponse("pro_monthly", "PRO", "EXPIRED", 50L))
        assertEquals("EXPIRED", repo.list("u1").single().state)
    }
}

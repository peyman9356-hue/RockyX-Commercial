package com.rockyx.backend

import com.rockyx.backend.domain.*
import com.rockyx.backend.infra.*
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class ContentRepositoryTest {
    private val catalog = """{"schemaVersion":1,"contentVersion":"1.0.0","locale":"en-US","courses":[{"id":"course-1","title":"Basics"}]}"""

    @Test fun `draft is not published until explicit publish`() {
        val repo = InMemoryContentRepository()
        val request = ContentUpsertRequest("en-US", "1.0.0", 1, catalog)
        repo.upsert("catalog-en", request, "admin-1")
        assertEquals(null, repo.getPublished("en-US"))
        repo.publish("catalog-en", 1, "admin-1")
        assertEquals(ContentStatus.PUBLISHED, repo.getPublished("en-US")?.status)
    }

    @Test fun `stale revision is rejected`() {
        val repo = InMemoryContentRepository()
        repo.upsert("catalog-en", ContentUpsertRequest("en-US", "1.0.0", 1, catalog), "admin-1")
        assertFailsWith<ContentConflictException> {
            repo.upsert("catalog-en", ContentUpsertRequest("en-US", "1.0.1", 1, catalog, expectedRevision = 0), "admin-2")
        }
    }

    @Test fun `duplicate course ids are rejected`() {
        val repo = InMemoryContentRepository()
        val duplicate = """{"courses":[{"id":"x"},{"id":"x"}]}"""
        assertFailsWith<ContentValidationException> { repo.upsert("catalog-dup", ContentUpsertRequest("en-US", "1.0.0", 1, duplicate), "admin-1") }
    }

}

package com.rockyx.backend

import com.rockyx.backend.infra.InMemoryRtdnMessageRepository
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class RtdnRepositoryTest {
    @Test fun duplicateMessageIsNotProcessedTwice() {
        val repo = InMemoryRtdnMessageRepository()
        assertTrue(repo.claim("m-1"))
        assertFalse(repo.claim("m-1"))
        repo.markProcessed("m-1")
        assertFalse(repo.claim("m-1"))
    }
}

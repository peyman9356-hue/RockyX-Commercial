# Rocky X Backend — Phase 12

PostgreSQL persistence foundation for Rocky X.

## Persistence
- PostgreSQL-backed repositories for accounts, sync operations, submissions and idempotency keys.
- Entitlement table reserved for verified server-side commerce state; no entitlement is invented by this phase.
- Flyway migrations are versioned under `src/main/resources/db/migration`.
- HikariCP provides bounded connection pooling.
- Transactions are used around create/accept operations.
- Unique keys make sync operation and submission writes idempotent at the database layer.

PostgreSQL 18.6 is the current supported 18.x minor release as of August 13, 2026. The PostgreSQL project supports a major version for five years and recommends current minor releases. urlPostgreSQL versioning policyhttps://www.postgresql.org/support/versioning/

## Runtime configuration
Set:
- `ROCKYX_DATABASE_URL`
- `ROCKYX_DATABASE_USER`
- `ROCKYX_DATABASE_PASSWORD`
- optional `ROCKYX_DATABASE_POOL_SIZE`

If these variables are absent, the server intentionally falls back to in-memory repositories for development. This is not production persistence.

## Local database
`docker compose up -d` from this directory starts PostgreSQL for development. Change the example password for any shared environment.

## Production boundary
Database credentials must come from a secret manager/environment, never source control. Backups, restore drills, replicas, monitoring, encryption-at-rest, TLS, retention and disaster recovery are deployment responsibilities and are not falsely marked complete here.


## Security / Authentication
- External OIDC/OAuth2 identity provider boundary; Rocky X does not collect or store user passwords in this backend.
- RS256 JWT validation via HTTPS JWKS with issuer and audience validation. JWKS keys are cached and rate-limited.
- Authentication is fail-closed when JWT configuration is missing. Production startup also fails if JWT or database configuration is absent.
- Server-side scope authorization is enforced per endpoint: `account:read`, `sync:write`, `submission:write`, `entitlement:read`.
- Request IDs are generated server-side; client-supplied request IDs are not trusted.
- Security headers and optional HTTPS enforcement are enabled.
- Production must terminate TLS correctly and set `ROCKYX_REQUIRE_TLS=true`.

### Required production auth configuration
See `.env.security.example` for the required variables. Never commit issuer credentials, signing keys, client secrets, or database passwords.

The design follows current Ktor JWT guidance for signature/payload validation and OWASP guidance that authentication and authorization are distinct and that authorization must be enforced server-side for every protected request. citeturn1search0turn0search0

## Phase 24 CMS authorization
CMS read/write routes require a verified identity, the matching `content:read` or `content:write` scope, and the `admin` role. Publishing is explicit and guarded by an optimistic revision check.

# Phase 20 — Observability + Analytics

## Scope
Vendor-neutral observability and privacy-minimal product analytics foundation.

## Backend
- Telemetry boundary for counters/events/timings.
- Request and error counters without raw request payloads.
- Liveness/readiness endpoints.
- Development metrics snapshot.
- Sanitization rules for common PII/secrets.

## Android
- Analytics event/repository boundary.
- Persistent local buffer for offline periods (bounded to 500 events).
- Redaction of email, phone, tokens, authorization, address, raw video and payload fields.

## Production boundary
OpenTelemetry is a suitable vendor-neutral export layer. Official OpenTelemetry Android documentation describes offline buffering and attribute redaction, while Ktor documents OpenTelemetry server tracing. Production exporters, dashboards, alerting, crash backend and retention policies remain deployment integrations.

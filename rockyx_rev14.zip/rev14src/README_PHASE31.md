# Rocky X — Phase 31

**Identity Provider Adapters & Account Onboarding**

Version 0.31.0 / versionCode 31

This phase connects a real Google identity flow to the existing first-party session system and introduces authenticated account onboarding/profile data. It also establishes the Android passkey transport boundary without pretending that WebAuthn server verification is finished.

### Production prerequisites
- Google Auth Platform / OAuth configuration
- Rocky X Web Client ID configured as `ROCKYX_GOOGLE_WEB_CLIENT_ID`
- Production API URL over HTTPS
- Phase 30 session signing configuration
- PostgreSQL migrations including V10

### Important
No secrets, OAuth client secrets, signing keys, or service credentials are stored in the repository.

# Rocky X — Revision 12 Release Boundary Audit

Revision 11 deep review found a remaining production-boundary problem: the backend could start in production with `UnconfiguredMediaSecurityScanner`, while the worker would then retry unconfigured media jobs indefinitely.

Revision 12 makes this an explicit startup blocker. Production now fails closed unless a real media security scanner is supplied. Development mode keeps the deterministic placeholder for architecture/testing only.

Status: STATICALLY HARDENED / BUILD UNVERIFIED / RUNTIME UNVERIFIED / NOT RELEASE-READY.

# Phase 29 — Authenticated API Client + Entitlement Synchronization

Version 0.29.0 / versionCode 29

## Objective
Close the Android-to-backend security boundary created by Phases 26–28 without putting an identity provider, token, or backend URL into application logic.

## Implemented
- Provider-neutral `AuthTokenProvider` boundary.
- Production API client using Ktor Client 3.5.2 + OkHttp engine, explicit request/connect/socket timeouts, and bounded response parsing.
- Bearer authentication with dynamic token loading; token refresh remains owned by the future real auth adapter.
- HTTPS-only API base URL.
- Purchase verification is asynchronous and runs off the main thread.
- Purchase verification calls `/api/v1/billing/google-play/subscriptions/verify`.
- Deterministic idempotency key derived from product + purchase token.
- Entitlement snapshot calls `/api/v1/entitlements`.
- Server entitlement snapshot replaces local paid-access state only after a successful authenticated response.
- Local entitlement storage is not used as proof of purchase.
- Billing UI now refuses purchase orchestration while signed out.
- Offer selection prefers the configured offer ID instead of blindly selecting the first Play offer.
- Backend verification route now actually stores/replays its idempotent response.
- No access token, refresh token, purchase token, prompt, or API response body is written to telemetry.
- Existing offline-first architecture is preserved.

## Security decisions
- The mobile client never receives Google Play service-account credentials.
- The mobile client never verifies Google purchases by itself.
- A successful Play callback without successful server verification does not grant access.
- A successful server verification followed by temporary entitlement-sync failure does not fabricate local access; a background sync is scheduled.
- The HTTP client does not log request/response bodies.
- Release builds require an HTTPS API base URL when one is configured; an empty URL remains an explicit unconfigured state.

## Honest boundary
A real external identity provider is still required. `UnconfiguredAuthTokenProvider` intentionally supplies no credentials, so the production API cannot be accidentally contacted as an anonymous user.

The environment used for this phase does not contain the complete Gradle/Android SDK toolchain, so a full Android build is not claimed. Static/source validation and archive integrity checks were performed.

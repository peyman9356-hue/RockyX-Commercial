# Rocky X Project Rules

- Never claim production infrastructure is complete when it is not.
- Never put database credentials or API secrets in source control.
- Server-side authorization and entitlements are authoritative.
- Database migrations are append-only and versioned.
- Preserve previous project versions.
- Prefer repository interfaces and provider-neutral boundaries.
- Every durable write must have an idempotency strategy where retries are possible.
- Production deployment must include backup/restore validation, TLS, secret management and monitoring before release.


## Security placement rule
Authentication must be provided by an external standards-based identity provider. The backend verifies tokens and enforces authorization; the Android client is never the final authority for access. Production must fail closed when identity or persistence configuration is incomplete.


## Reliability rule
Failures must be classified, safely recorded, and recovered with bounded retries. Never expose stack traces or raw user data in API errors/telemetry.


## Phase 24 — Admin / CMS / Content Management
Rocky X now has a server-side, versioned content-management boundary with draft/publish lifecycle, optimistic concurrency, audit history, locale-aware published catalogs, and role/scope authorization.


## Phase 25
AI Personalization is provider-neutral, safety-gated, deterministic/offline-capable, and does not embed model credentials or vendor SDKs.

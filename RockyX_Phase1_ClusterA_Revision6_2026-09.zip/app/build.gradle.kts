import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.rockyx.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.rockyx.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 34
        versionName = "0.32.2"
        buildConfigField("String", "ROCKYX_API_BASE_URL", "\"${providers.gradleProperty("rockyxApiBaseUrl").orNull ?: ""}\"")
        buildConfigField("String", "ROCKYX_GOOGLE_WEB_CLIENT_ID", "\"${providers.gradleProperty("rockyxGoogleWebClientId").orNull ?: ""}\"")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        buildConfig = true
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            // Signing is intentionally supplied by the CI/release environment, never committed.
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val media3Version = "1.10.1"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    // Google Play Billing boundary for the production purchase adapter.
    implementation("com.android.billingclient:billing-ktx:9.1.0")
    implementation("androidx.work:work-runtime:2.11.2")
    implementation("io.ktor:ktor-client-core:3.5.2")
    implementation("io.ktor:ktor-client-okhttp:3.5.2")
    implementation("io.ktor:ktor-client-auth:3.5.2")
    // Stable Credential Manager 1.6.0; Google ID SDK 1.2.0 verified against Google release notes.
    implementation("androidx.credentials:credentials:1.6.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.6.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.2.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("androidx.core:core-ktx:1.18.0")
}


package com.rockyx.app.ui

import android.content.Context
import com.rockyx.app.data.commerce.EntitlementStore
import com.rockyx.app.data.content.LocalContentRepository
import com.rockyx.app.data.dog.DogStore
import com.rockyx.app.data.account.LocalAccountStore
import com.rockyx.app.data.connectivity.AndroidConnectivityRepository
import com.rockyx.app.data.account.UnconfiguredAuthProvider
import com.rockyx.app.data.account.UnconfiguredAuthTokenProvider
import com.rockyx.app.data.network.RockyXApiClient
import com.rockyx.app.data.sync.LocalSyncStore
import com.rockyx.app.data.sync.UnconfiguredSyncTransport
import com.rockyx.app.data.progress.ProgressStore
import com.rockyx.app.data.submission.SubmissionStore
import com.rockyx.app.data.submission.UnconfiguredSubmissionUploadGateway
import com.rockyx.app.domain.repository.AuthPort
import com.rockyx.app.domain.usecase.*
import com.rockyx.app.reliability.LocalReliabilityRepository
import com.rockyx.app.ai.LocalPersonalizationProvider

class AppController(context: Context) {
    val reliability = LocalReliabilityRepository(context)
    private val content = LocalContentRepository(context)
    private val progress = ProgressStore(context)
    private val entitlements = EntitlementStore(context)
    val submissions = SubmissionStore(context)
    private val submissionUploader = UnconfiguredSubmissionUploadGateway()
    private val accountStore = LocalAccountStore(context)
    private val sessionTokens = com.rockyx.app.data.account.SecureSessionTokenStore(context)
    private val authProvider = UnconfiguredAuthProvider()
    private val syncStore = LocalSyncStore(context)
    private val syncTransport = UnconfiguredSyncTransport()
    private val connectivity = AndroidConnectivityRepository(context)
    val accountSession = GetAccountSession(accountStore)
    val signIn = SignIn(accountStore, authProvider)
    val signOut = SignOut(accountStore, authProvider)
    val syncPendingChanges = SyncPendingChanges(accountStore, syncStore, syncTransport)
    val resilientSync = ResilientSync(accountStore, connectivity, syncStore, syncTransport)
    val auth: AuthPort = object : AuthPort {
        override fun isSignedIn() = accountStore.session().isAuthenticated()
        override fun currentUserId(): String? = accountStore.session().takeIf { it.isAuthenticated() }?.userId
    }
    val commercePlans = com.rockyx.app.data.commerce.ProductCatalog.plans(context)
    private val authTokenProvider = com.rockyx.app.data.account.SessionStoreAuthTokenProvider(sessionTokens)
    val api = RockyXApiClient(BuildConfig.ROCKYX_API_BASE_URL, authTokenProvider)
    val sessionAuth = com.rockyx.app.data.account.SessionAuthCoordinator(api, sessionTokens, accountStore)
    val googleIdentity = com.rockyx.app.data.account.GoogleCredentialManagerIdentityProvider(context, BuildConfig.ROCKYX_GOOGLE_WEB_CLIENT_ID)
    init { authTokenProvider.refreshHandler = { sessionAuth.refresh().getOrNull()?.let { sessionTokens.accessToken() } } }
    val billingVerification = if (BuildConfig.ROCKYX_API_BASE_URL.isNotBlank())
        com.rockyx.app.data.commerce.ApiPurchaseVerificationGateway(api)
    else com.rockyx.app.data.commerce.UnconfiguredPurchaseVerificationGateway()
    val billingOrchestrator = com.rockyx.app.data.commerce.BillingPurchaseOrchestrator(billingVerification)
    val dog = DogStore(context)
    private val accessPolicy = CanAccess(entitlements)
    val catalog = GetLearningCatalog(content)
    val getCourse = GetCourse(content)
    val startLesson = StartLesson(progress)
    val completeExercise = CompleteExercise(progress)
    val submitQuiz = SubmitQuiz(content, progress)
    val updateMission = UpdateMission(progress)
    val evaluateLesson = EvaluateLesson(content, progress)
    val lessonState = GetLessonState(content, progress) { accessPolicy(it) }
    val courseProgress = GetCourseProgress(content, progress)
    val nextLesson = GetNextLesson(content, progress)
    val personalized = GetPersonalizedLessons(content, progress, dog, LocalPersonalizationProvider())
    val saveSubmission = SaveSubmission(submissions)
    val queueSubmission = QueueSubmission(submissions, submissionUploader)
    fun state(id: String) = progress.snapshot().lessons[id]
    fun canAccess(access: com.rockyx.app.domain.model.Access) = accessPolicy.invoke(access)
    fun entitlement(productId: String) = entitlements.get(productId)
    suspend fun refreshServerEntitlements(): Result<Unit> = runCatching {
        if (!auth.isSignedIn()) error("Authentication required for entitlement sync")
        val remote = api.fetchEntitlements()
        entitlements.replaceFromServer(remote.map {
            com.rockyx.app.domain.model.Entitlement(
                productId = it.productId,
                tier = it.tier,
                state = com.rockyx.app.domain.model.EntitlementState.valueOf(it.state),
                startsAt = null,
                expiresAt = it.expiresAtEpochMs,
                source = "server"
            )
        })
    }

    fun saveLocalTrial(plan: com.rockyx.app.domain.model.PricingPlan) {
        val now = System.currentTimeMillis()
        val expires = if (plan.trialDays > 0) now + plan.trialDays * 86_400_000L else now + 30L * 86_400_000L
        entitlements.save(com.rockyx.app.domain.model.Entitlement(plan.productId, plan.tier, com.rockyx.app.domain.model.EntitlementState.ACTIVE, now, expires, "local-test"))
    }
}

package com.rockyx.app.data.sync

import android.content.Context
import com.rockyx.app.data.LocalDataCorruptionException
import com.rockyx.app.domain.repository.SyncRepository
import com.rockyx.app.domain.sync.*
import org.json.JSONArray
import org.json.JSONObject

/** Offline-first durable sync queue. It stores intent, never credentials. */
class LocalSyncStore(context: Context) : SyncRepository {
    private val prefs = context.getSharedPreferences("rockyx_sync_v1", Context.MODE_PRIVATE)
    private val key = "queue"
    private val successKey = "lastSuccessfulSyncAt"

    override fun snapshot(): SyncSnapshot = SyncSnapshot(
        state = if (pending().isEmpty()) SyncState.IDLE else SyncState.QUEUED,
        lastSuccessfulSyncAt = prefs.getLong(successKey, 0L).takeIf { it > 0L },
        pendingCount = pending().size
    )

    override fun enqueue(operation: SyncOperation) {
        val items = pending().filterNot { it.id == operation.id }.toMutableList()
        items.add(operation)
        save(items)
    }

    override fun pending(limit: Int): List<SyncOperation> = load().take(limit.coerceAtLeast(1))

    override fun markSucceeded(operationId: String) {
        save(load().filterNot { it.id == operationId })
        prefs.edit().putLong(successKey, System.currentTimeMillis()).apply()
    }

    override fun markFailed(operationId: String, error: String) {
        save(load().map { if (it.id == operationId) it.copy(attemptCount = it.attemptCount + 1, lastError = error.take(500)) else it })
    }

    private fun load(): List<SyncOperation> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            buildList { for (i in 0 until a.length()) add(fromJson(a.getJSONObject(i))) }
        } catch (t: Throwable) {
            quarantineCorruptRaw(raw)
            throw LocalDataCorruptionException("sync_queue", t)
        }
    }

    private fun quarantineCorruptRaw(raw: String) {
        val quarantineKey = "${key}.corrupt.${System.currentTimeMillis()}"
        prefs.edit().putString(quarantineKey, raw).remove(key).apply()
    }

    private fun save(items: List<SyncOperation>) {
        val a = JSONArray()
        items.forEach { a.put(toJson(it)) }
        prefs.edit().putString(key, a.toString()).apply()
    }

    private fun fromJson(j: JSONObject): SyncOperation {
        val id = j.getString("id").trim().also { require(it.isNotEmpty()) { "sync operation id is blank" } }
        val entityId = j.getString("entityId").trim().also { require(it.isNotEmpty()) { "sync entity id is blank" } }
        val payloadVersion = j.optInt("payloadVersion", 1).also { require(it >= 1) { "payloadVersion must be >= 1" } }
        val createdAt = j.optLong("createdAt", 0L).also { require(it > 0L) { "createdAt must be positive" } }
        val attemptCount = j.optInt("attemptCount", 0).also { require(it >= 0) { "attemptCount must be >= 0" } }
        return SyncOperation(
            id = id,
            type = SyncOperationType.valueOf(j.getString("type")),
            entityId = entityId,
            payloadVersion = payloadVersion,
            createdAt = createdAt,
            attemptCount = attemptCount,
            lastError = j.optString("lastError", "").ifBlank { null }
        )
    }

    private fun toJson(o: SyncOperation) = JSONObject().apply {
        put("id", o.id); put("type", o.type.name); put("entityId", o.entityId)
        put("payloadVersion", o.payloadVersion); put("createdAt", o.createdAt)
        put("attemptCount", o.attemptCount); put("lastError", o.lastError)
    }
}

package com.rockyx.app.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DefaultDownloaderFactory
import androidx.media3.exoplayer.upstream.DefaultDataSource
import androidx.media3.exoplayer.upstream.cache.CacheDataSource
import androidx.media3.exoplayer.upstream.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.core.app.NotificationCompat
import com.rockyx.app.MainActivity
import java.io.File

@UnstableApi
object MediaDownloadRepository {
    private const val DIR = "media_cache"
    private var cache: SimpleCache? = null

    @Synchronized
    fun cache(context: Context): SimpleCache {
        return cache ?: SimpleCache(
            File(context.filesDir, DIR),
            androidx.media3.exoplayer.upstream.cache.NoOpCacheEvictor(),
            StandaloneDatabaseProvider(context)
        ).also { cache = it }
    }

    fun dataSourceFactory(context: Context): CacheDataSource.Factory {
        val upstream = DefaultDataSource.Factory(context, DefaultHttpDataSource.Factory())
        return CacheDataSource.Factory().setCache(cache(context)).setUpstreamDataSourceFactory(upstream)
    }
}

@UnstableApi
class RockyXDownloadService : DownloadService(1001) {
    override fun getDownloadManager(): DownloadManager {
        val context = applicationContext
        val db = StandaloneDatabaseProvider(context)
        val upstream = DefaultDataSource.Factory(context, DefaultHttpDataSource.Factory())
        val cache = MediaDownloadRepository.cache(context)
        val factory = DefaultDownloaderFactory(
            CacheDataSource.Factory().setCache(cache).setUpstreamDataSourceFactory(upstream),
            2_000L
        )
        return DownloadManager(context, androidx.media3.exoplayer.offline.DefaultDownloadIndex(db), factory)
    }

    override fun getScheduler() = null

    override fun getForegroundNotification(downloads: MutableList<Download>, notMetRequirements: Int): Notification {
        ensureChannel()
        val active = downloads.count { it.state == Download.STATE_DOWNLOADING }
        val done = downloads.count { it.state == Download.STATE_COMPLETED }
        val intent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "rockyx_media_downloads")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Rocky X — Media")
            .setContentText("در حال دانلود: $active • کامل‌شده: $done")
            .setContentIntent(intent)
            .setOngoing(active > 0)
            .build()
    }

    private fun ensureChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("rockyx_media_downloads", "Rocky X Downloads", NotificationManager.IMPORTANCE_LOW))
    }
}

package com.rockyx.backend.media

interface ObjectStoragePort {
    fun createUploadUrl(objectKey: String, contentType: String, checksum: String, expiresAtEpochMs: Long): String?
    fun createDownloadUrl(objectKey: String, expiresAtEpochMs: Long): String?
    fun delete(objectKey: String): Boolean
}

/** Production adapter is intentionally not provider-coupled. Configure S3-compatible/CDN storage at deployment. */
class UnconfiguredObjectStorage : ObjectStoragePort {
    override fun createUploadUrl(objectKey: String, contentType: String, checksum: String, expiresAtEpochMs: Long): String? = null
    override fun createDownloadUrl(objectKey: String, expiresAtEpochMs: Long): String? = null
    override fun delete(objectKey: String): Boolean = false
}

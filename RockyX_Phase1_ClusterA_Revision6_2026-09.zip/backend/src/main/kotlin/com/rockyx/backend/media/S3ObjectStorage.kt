package com.rockyx.backend.media

import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.s3.S3Client
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest
import software.amazon.awssdk.services.s3.model.PutObjectRequest
import software.amazon.awssdk.services.s3.presigner.S3Presigner
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest
import software.amazon.awssdk.services.s3.presigner.model.PutObjectPresignRequest
import java.net.URI
import java.time.Duration
import java.util.Base64

/** S3-compatible storage adapter. Credentials come only from the runtime credential provider chain. */
class S3ObjectStorage private constructor(
    private val bucket: String,
    private val client: S3Client,
    private val presigner: S3Presigner
) : ObjectStoragePort, AutoCloseable {

    data class SignedUpload(val url: String, val requiredHeaders: Map<String, String>)

    override fun createUploadUrl(objectKey: String, contentType: String, checksum: String, expiresAtEpochMs: Long): String? =
        createSignedUpload(objectKey, contentType, checksum, expiresAtEpochMs)?.url

    fun createSignedUpload(objectKey: String, contentType: String, checksum: String, expiresAtEpochMs: Long): SignedUpload? {
        val seconds = ((expiresAtEpochMs - System.currentTimeMillis()) / 1000L).coerceIn(1L, 900L)
        val checksumBase64 = Base64.getEncoder().encodeToString(hexToBytes(checksum))
        val request = PutObjectRequest.builder()
            .bucket(bucket).key(objectKey).contentType(contentType).checksumSHA256(checksumBase64).build()
        val presigned = presigner.presignPutObject(
            PutObjectPresignRequest.builder().signatureDuration(Duration.ofSeconds(seconds)).putObjectRequest(request).build()
        )
        return SignedUpload(presigned.url().toString(), mapOf("Content-Type" to contentType, "x-amz-checksum-sha256" to checksumBase64))
    }

    override fun createDownloadUrl(objectKey: String, expiresAtEpochMs: Long): String? {
        val seconds = ((expiresAtEpochMs - System.currentTimeMillis()) / 1000L).coerceIn(1L, 900L)
        val request = software.amazon.awssdk.services.s3.model.GetObjectRequest.builder().bucket(bucket).key(objectKey).build()
        return presigner.presignGetObject(GetObjectPresignRequest.builder().signatureDuration(Duration.ofSeconds(seconds)).getObjectRequest(request).build()).url().toString()
    }

    override fun delete(objectKey: String): Boolean {
        client.deleteObject(DeleteObjectRequest.builder().bucket(bucket).key(objectKey).build())
        return true
    }

    /** Lightweight readiness probe for the configured bucket. */
    fun checkReady(): Boolean = runCatching { client.headBucket { it.bucket(bucket) }; true }.getOrDefault(false)

    /** Confirms the uploaded object exists and matches the declared size/type. */
    fun verifyUploadedObject(objectKey: String, expectedSizeBytes: Long, expectedContentType: String): Boolean = try {
        val head = client.headObject { it.bucket(bucket).key(objectKey) }
        head.contentLength() == expectedSizeBytes && head.contentType().equals(expectedContentType, ignoreCase = true)
    } catch (_: Exception) { false }

    override fun close() { presigner.close(); client.close() }

    companion object {
        fun fromEnvironment(): S3ObjectStorage? {
            val bucket = System.getenv("ROCKYX_STORAGE_BUCKET")?.takeIf { it.isNotBlank() } ?: return null
            val region = System.getenv("ROCKYX_STORAGE_REGION")?.takeIf { it.isNotBlank() } ?: return null
            val endpoint = System.getenv("ROCKYX_STORAGE_ENDPOINT")?.takeIf { it.isNotBlank() }?.let(URI::create)
            val clientBuilder = S3Client.builder().region(Region.of(region)).credentialsProvider(DefaultCredentialsProvider.create())
            val presignerBuilder = S3Presigner.builder().region(Region.of(region)).credentialsProvider(DefaultCredentialsProvider.create())
            if (endpoint != null) {
                clientBuilder.endpointOverride(endpoint).forcePathStyle(true)
                presignerBuilder.endpointOverride(endpoint)
            }
            return S3ObjectStorage(bucket, clientBuilder.build(), presignerBuilder.build())
        }

        private fun hexToBytes(hex: String): ByteArray {
            require(hex.length == 64 && hex.all { it in "0123456789abcdefABCDEF" }) { "Checksum must be SHA-256 hex" }
            return ByteArray(32) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        }
    }
}

package com.rockyx.backend.api

import com.rockyx.backend.auth.*
import com.rockyx.backend.infra.AuthSessionRepository
import com.rockyx.backend.infra.InMemoryAuthSessionRepository
import com.rockyx.backend.domain.*
import com.rockyx.backend.infra.*
import com.rockyx.backend.media.*
import com.rockyx.backend.observability.*
import com.rockyx.backend.ai.*
import java.util.UUID
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.Base64

private val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }

private suspend fun io.ktor.server.application.ApplicationCall.forbidden(code: String = "INSUFFICIENT_SCOPE") =
    respond(HttpStatusCode.Forbidden, ApiError(code, "Insufficient permissions", requestId()))

private suspend fun io.ktor.server.application.ApplicationCall.requireRole(
    principal: AuthenticatedPrincipal,
    role: String
): Boolean {
    if (principal.hasRole(role)) return true
    forbidden("INSUFFICIENT_ROLE")
    return false
}

private suspend fun io.ktor.server.application.ApplicationCall.requireScope(
    principal: AuthenticatedPrincipal,
    scope: String
): Boolean {
    if (principal.hasScope(scope)) return true
    forbidden()
    return false
}

fun Route.registerApiRoutes(
    verifier: AccessTokenVerifier,
    accounts: AccountRepository,
    sync: SyncRepository,
    submissions: SubmissionRepository,
    idempotency: IdempotencyRepository,
    media: MediaRepository,
    storage: ObjectStoragePort,
    securityScanner: MediaSecurityScanner,
    processingQueue: MediaProcessingQueue,
    content: ContentRepository,
    telemetry: Telemetry = InMemoryTelemetry(),
    readiness: () -> HealthSnapshot = { HealthSnapshot("rockyx-backend", "ready", "v1", "unknown", "unknown") },
    personalization: PersonalizationProvider = LocalPersonalizationProvider(),
    entitlements: EntitlementRepository = InMemoryEntitlementRepository(),
    purchases: PurchaseRepository = InMemoryPurchaseRepository(),
    playBilling: com.rockyx.backend.billing.GooglePlayPurchaseVerifier = com.rockyx.backend.billing.UnconfiguredGooglePlayPurchaseVerifier(),
    rtdnAuthenticator: com.rockyx.backend.billing.RtdnPushAuthenticator = com.rockyx.backend.billing.UnconfiguredRtdnPushAuthenticator(),
    rtdnMessages: RtdnMessageRepository = InMemoryRtdnMessageRepository(),
    authSessions: AuthSessionRepository = InMemoryAuthSessionRepository(),
    sessionManager: SessionManager? = null,
    externalIdentityVerifier: AccessTokenVerifier? = null,
    googleIdentityVerifier: AccessTokenVerifier? = null,
    accountProfiles: AccountProfileRepository = InMemoryAccountProfileRepository(),
    ecosystem: EcosystemRepository = InMemoryEcosystemRepository()
) {
    route("/api/v1") {
        get("/health") { call.respond(HealthResponse("ok", "v1")) }

        get("/ready") {
            val snapshot = readiness()
            if (snapshot.status == "ready") call.respond(snapshot)
            else call.respond(HttpStatusCode.ServiceUnavailable, snapshot)
        }

        get("/internal/metrics") {
            // Development visibility only; production should export through the Telemetry boundary.
            val snapshot = (telemetry as? InMemoryTelemetry)?.snapshot() ?: emptyMap()
            call.respond(snapshot)
        }

        post("/auth/exchange") {
            val manager = sessionManager ?: return@post call.respond(HttpStatusCode.ServiceUnavailable, ApiError("AUTH_NOT_CONFIGURED", "Authentication is not configured", requestId(), category = FailureCategory.AUTH))
            val request = try { call.receive<AuthExchangeRequest>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AUTH_REQUEST", "Invalid authentication request", requestId(), category = FailureCategory.AUTH))
            }
            if (request.idToken.length !in 32..16384 || request.provider.length !in 2..64)
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AUTH_REQUEST", "Invalid authentication request", requestId(), category = FailureCategory.AUTH))
            val verifierForProvider = when (request.provider) {
                "google" -> googleIdentityVerifier
                "oidc" -> externalIdentityVerifier
                else -> null
            } ?: return@post call.respond(HttpStatusCode.BadRequest, ApiError("UNSUPPORTED_IDENTITY_PROVIDER", "Identity provider is not configured", requestId(), category = FailureCategory.AUTH))
            val identity = verifierForProvider.verify(request.idToken)
                ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("IDENTITY_VERIFICATION_FAILED", "Identity could not be verified", requestId(), category = FailureCategory.AUTH))
            accounts.getOrCreate(identity.userId)
            val tokens = manager.issue(identity.userId, identity.provider, identity.scopes.ifEmpty { setOf("account:read", "sync:write", "submission:write", "entitlement:read", "dog:read", "dog:write", "device:read", "device:write", "vet:read", "vet:write", "safety:read", "safety:write", "ai:read", "ai:write") }, identity.roles)
            call.respond(AuthTokenResponse(tokens.accessToken, tokens.refreshToken, tokens.expiresAtEpochMs, tokens.userId))
        }

        post("/auth/refresh") {
            val manager = sessionManager ?: return@post call.respond(HttpStatusCode.ServiceUnavailable, ApiError("AUTH_NOT_CONFIGURED", "Authentication is not configured", requestId(), category = FailureCategory.AUTH))
            val request = try { call.receive<AuthRefreshRequest>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AUTH_REQUEST", "Invalid authentication request", requestId(), category = FailureCategory.AUTH))
            }
            if (request.refreshToken.length !in 32..512) return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_REFRESH_TOKEN", "Invalid refresh token", requestId(), category = FailureCategory.AUTH))
            val tokens = manager.rotate(request.refreshToken) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("REFRESH_REJECTED", "Refresh token rejected", requestId(), category = FailureCategory.AUTH))
            call.respond(AuthTokenResponse(tokens.accessToken, tokens.refreshToken, tokens.expiresAtEpochMs, tokens.userId))
        }

        post("/auth/logout") {
            val manager = sessionManager ?: return@post call.respond(HttpStatusCode.ServiceUnavailable, ApiError("AUTH_NOT_CONFIGURED", "Authentication is not configured", requestId(), category = FailureCategory.AUTH))
            val request = try { call.receive<AuthRefreshRequest>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AUTH_REQUEST", "Invalid authentication request", requestId(), category = FailureCategory.AUTH))
            }
            if (request.refreshToken.length !in 32..512) return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_REFRESH_TOKEN", "Invalid refresh token", requestId(), category = FailureCategory.AUTH))
            manager.revoke(request.refreshToken)
            call.respond(HttpStatusCode.NoContent)
        }

        get("/account/me") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "account:read")) return@get
            telemetry.count("account.read")
            call.respond(accounts.getOrCreate(principal.userId))
        }

        get("/account/profile") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "account:read")) return@get
            accounts.getOrCreate(principal.userId)
            call.respond(accountProfiles.get(principal.userId))
        }

        put("/account/profile") {
            val principal = call.requirePrincipal(verifier) ?: return@put call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "account:read")) return@put
            val body = runCatching { call.receive<AccountProfileUpdateRequest>() }.getOrElse {
                return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_PROFILE", "Invalid profile", requestId(), category = FailureCategory.CONTENT))
            }
            if ((body.displayName?.length ?: 0) > 80 || (body.locale?.length ?: 0) > 32 || (body.timeZone?.length ?: 0) > 64 || body.onboardingVersion !in 1..100)
                return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_PROFILE", "Profile fields exceed allowed limits", requestId(), category = FailureCategory.CONTENT))
            accounts.getOrCreate(principal.userId)
            call.respond(accountProfiles.update(principal.userId, body.displayName?.trim()?.ifBlank { null }, body.locale?.trim()?.ifBlank { null }, body.timeZone?.trim()?.ifBlank { null }, body.onboardingVersion))
        }

        post("/sync/operations") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "sync:write")) return@post
            val idem = call.request.headers["Idempotency-Key"]
            if (!SecurityPolicy.validIdempotencyKey(idem)) return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_IDEMPOTENCY_KEY", "Invalid Idempotency-Key", requestId(), category = FailureCategory.CONTENT))
            val body = call.receive<SyncOperationRequest>()
            if (!SecurityPolicy.validOpaque(body.operationId, SecurityPolicy.MAX_OPERATION_ID) ||
                !SecurityPolicy.validOpaque(body.entityType, SecurityPolicy.MAX_ENTITY_TYPE) ||
                !SecurityPolicy.validOpaque(body.entityId, SecurityPolicy.MAX_ENTITY_ID) ||
                !SecurityPolicy.validJsonPayload(body.payloadJson) || body.payloadVersion <= 0 || body.clientChangedAtEpochMs <= 0L) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_SYNC_REQUEST", "Invalid sync request", requestId(), category = FailureCategory.CONTENT))
            }
            val prior = idempotency.get(principal.userId, idem)
            if (prior != null) return@post call.respondText(prior, ContentType.Application.Json)
            val response = sync.accept(principal.userId, body)
            telemetry.count("sync.accepted")
            idempotency.put(principal.userId, idem, json.encodeToString(response))
            call.respond(response)
        }

        post("/submissions") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "submission:write")) return@post
            val idem = call.request.headers["Idempotency-Key"]
            if (!SecurityPolicy.validIdempotencyKey(idem)) return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_IDEMPOTENCY_KEY", "Invalid Idempotency-Key", requestId(), category = FailureCategory.CONTENT))
            val body = call.receive<SubmissionCreateRequest>()
            if (!SecurityPolicy.validOpaque(body.submissionId, SecurityPolicy.MAX_SUBMISSION_ID) ||
                !SecurityPolicy.validOpaque(body.missionId, SecurityPolicy.MAX_MISSION_ID) ||
                !SecurityPolicy.validChecksum(body.mediaChecksum)) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_SUBMISSION_REQUEST", "Invalid submission request", requestId(), category = FailureCategory.CONTENT))
            }
            val prior = idempotency.get(principal.userId, idem)
            if (prior != null) return@post call.respondText(prior, ContentType.Application.Json)
            val response = try { submissions.create(principal.userId, body) } catch (e: IllegalArgumentException) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_SUBMISSION", e.message ?: "Invalid submission", requestId()))
            }
            idempotency.put(principal.userId, idem, json.encodeToString(response))
            telemetry.count("submission.created")
            call.respond(HttpStatusCode.Created, response)
        }

        post("/media/upload-intents") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "submission:write")) return@post
            val body = call.receive<MediaUploadIntentRequest>()
            if (!SecurityPolicy.validOpaque(body.submissionId, SecurityPolicy.MAX_SUBMISSION_ID) || !SecurityPolicy.validChecksum(body.checksum)) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_MEDIA_REQUEST", "Invalid media request", requestId(), category = FailureCategory.CONTENT))
            }
            MediaSecurityPolicy.validateUpload(body.contentType, body.sizeBytes, body.checksum)?.let { code ->
                return@post call.respond(HttpStatusCode.BadRequest, ApiError(code, "Media upload is not allowed", requestId()))
            }
            val submission = submissions.get(principal.userId, body.submissionId) ?: return@post call.respond(HttpStatusCode.NotFound, ApiError("SUBMISSION_NOT_FOUND", "Submission not found", requestId()))
            val mediaId = UUID.randomUUID().toString()
            val objectKey = "users/${principal.userId}/submissions/${submission.submissionId}/$mediaId"
            val expires = System.currentTimeMillis() + 15 * 60 * 1000L
            val asset = MediaAsset(mediaId, principal.userId, submission.submissionId, objectKey, body.contentType, body.sizeBytes, body.checksum, "UPLOAD_PENDING", System.currentTimeMillis(), System.currentTimeMillis())
            media.create(asset)
            val url = storage.createUploadUrl(objectKey, body.contentType, body.checksum, expires)
            val headers = if (storage is S3ObjectStorage) storage.createSignedUpload(objectKey, body.contentType, body.checksum, expires)?.requiredHeaders ?: emptyMap() else emptyMap()
            call.respond(MediaUploadIntentResponse(mediaId, objectKey, url, expires, if (url == null) "STORAGE_NOT_CONFIGURED" else "READY", headers))
        }

        post("/media/complete") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "submission:write")) return@post
            val body = call.receive<MediaCompleteRequest>()
            val asset = media.getForUser(principal.userId, body.mediaId) ?: return@post call.respond(HttpStatusCode.NotFound, ApiError("MEDIA_NOT_FOUND", "Media not found", requestId()))
            if (asset.objectKey != body.objectKey) return@post call.respond(HttpStatusCode.Forbidden, ApiError("MEDIA_KEY_MISMATCH", "Media object does not belong to this asset", requestId()))
            if (asset.checksum != body.checksum) return@post call.respond(HttpStatusCode.BadRequest, ApiError("MEDIA_CHECKSUM_MISMATCH", "Checksum mismatch", requestId()))
            val quarantined = media.markReady(principal.userId, body.mediaId, body.checksum) ?: return@post call.respond(HttpStatusCode.Conflict, ApiError("MEDIA_NOT_READY", "Media could not be completed", requestId()))
            val queued = processingQueue.enqueue(quarantined.mediaId)
            if (!queued) {
                call.respond(HttpStatusCode.Accepted, quarantined.copy(state = "QUARANTINED"))
            } else {
                call.respond(HttpStatusCode.Accepted, quarantined)
            }
        }

        get("/content/catalog") {
            val locale = call.request.queryParameters["locale"]?.trim()?.takeIf { it.isNotBlank() }
                ?: return@get call.respond(HttpStatusCode.BadRequest, ApiError("LOCALE_REQUIRED", "Locale is required", requestId(), category = FailureCategory.CONTENT))
            val document = content.getPublished(locale)
                ?: return@get call.respond(HttpStatusCode.NotFound, ApiError("CONTENT_NOT_FOUND", "Published content not found", requestId(), category = FailureCategory.CONTENT))
            telemetry.count("content.published.read", tags = mapOf("locale" to locale))
            call.respond(document)
        }

        get("/admin/content") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "content:read")) return@get
            if (!call.requireRole(principal, "admin")) return@get
            val locale = call.request.queryParameters["locale"]?.trim()?.takeIf { it.isNotBlank() }
            call.respond(content.list(locale))
        }

        get("/admin/content/{contentId}") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "content:read")) return@get
            if (!call.requireRole(principal, "admin")) return@get
            val id = call.parameters["contentId"]?.trim().orEmpty()
            if (!SecurityPolicy.validOpaque(id, 128)) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_CONTENT_ID", "Invalid content id", requestId(), category = FailureCategory.CONTENT))
            val document = content.get(id) ?: return@get call.respond(HttpStatusCode.NotFound, ApiError("CONTENT_NOT_FOUND", "Content not found", requestId(), category = FailureCategory.CONTENT))
            call.respond(document)
        }

        put("/admin/content/{contentId}") {
            val principal = call.requirePrincipal(verifier) ?: return@put call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "content:write")) return@put
            if (!call.requireRole(principal, "admin")) return@put
            val id = call.parameters["contentId"]?.trim().orEmpty()
            if (!SecurityPolicy.validOpaque(id, 128)) return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_CONTENT_ID", "Invalid content id", requestId(), category = FailureCategory.CONTENT))
            val body = try { call.receive<ContentUpsertRequest>() } catch (_: Exception) {
                return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_CONTENT_REQUEST", "Invalid content request", requestId(), category = FailureCategory.CONTENT))
            }
            try {
                val result = content.upsert(id, body, principal.userId)
                telemetry.count("content.draft.saved")
                call.respond(HttpStatusCode.Created, result)
            } catch (e: ContentConflictException) {
                call.respond(HttpStatusCode.Conflict, ApiError("CONTENT_REVISION_CONFLICT", e.message ?: "Revision conflict", requestId(), category = FailureCategory.CONTENT))
            } catch (e: IllegalArgumentException) {
                call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_CONTENT", e.message ?: "Invalid content", requestId(), category = FailureCategory.CONTENT))
            }
        }

        post("/admin/content/{contentId}/publish") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "content:write")) return@post
            if (!call.requireRole(principal, "admin")) return@post
            val id = call.parameters["contentId"]?.trim().orEmpty()
            if (!SecurityPolicy.validOpaque(id, 128)) return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_CONTENT_ID", "Invalid content id", requestId(), category = FailureCategory.CONTENT))
            val body = try { call.receive<ContentPublishRequest>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_PUBLISH_REQUEST", "Invalid publish request", requestId(), category = FailureCategory.CONTENT))
            }
            try {
                val result = content.publish(id, body.expectedRevision, principal.userId)
                telemetry.count("content.published")
                call.respond(result)
            } catch (e: ContentConflictException) {
                call.respond(HttpStatusCode.Conflict, ApiError("CONTENT_REVISION_CONFLICT", e.message ?: "Revision conflict", requestId(), category = FailureCategory.CONTENT))
            } catch (e: NoSuchElementException) {
                call.respond(HttpStatusCode.NotFound, ApiError("CONTENT_NOT_FOUND", "Content not found", requestId(), category = FailureCategory.CONTENT))
            }
        }

        post("/ai/recommendations") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId(), category = FailureCategory.AUTH))
            if (!call.requireScope(principal, "ai:read")) return@post
            val body = try { call.receive<AiRecommendationRequest>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AI_REQUEST", "Invalid personalization request", requestId(), category = FailureCategory.CONTENT))
            }
            try {
                PersonalizationSafetyPolicy.validate(body)
                telemetry.count("ai.recommendations.requested")
                call.respond(personalization.recommend(body))
            } catch (_: IllegalArgumentException) {
                call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AI_REQUEST", "Invalid personalization request", requestId(), category = FailureCategory.CONTENT))
            } catch (_: Exception) {
                call.respond(HttpStatusCode.ServiceUnavailable, ApiError("AI_PROVIDER_UNAVAILABLE", "Personalization service unavailable", requestId(), retryable = true, category = FailureCategory.NETWORK))
            }
        }

        // Rocky X ecosystem foundation: lifelong dog identity, devices, safety, vet access and AI evidence.
        get("/dogs") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "dog:read")) return@get
            call.respond(ecosystem.listDogs(principal.userId))
        }

        get("/dogs/{dogId}") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "dog:read")) return@get
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            if (!SecurityPolicy.validOpaque(dogId, 128)) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_ID", "Invalid dog id", requestId(), category = FailureCategory.CONTENT))
            val dog = ecosystem.getDog(principal.userId, dogId) ?: return@get call.respond(HttpStatusCode.NotFound, ApiError("DOG_NOT_FOUND", "Dog not found", requestId(), category = FailureCategory.CONTENT))
            call.respond(dog)
        }

        put("/dogs/{dogId}") {
            val principal = call.requirePrincipal(verifier) ?: return@put call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "dog:write")) return@put
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            val body = try { call.receive<DogUpsertRequest>() } catch (_: Exception) { return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_REQUEST", "Invalid dog request", requestId(), category = FailureCategory.CONTENT)) }
            if (dogId != body.dogId || !SecurityPolicy.validOpaque(dogId, 128)) return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_ID", "Invalid dog id", requestId(), category = FailureCategory.CONTENT))
            try { call.respond(ecosystem.upsertDog(principal.userId, body)) }
            catch (_: IllegalArgumentException) { call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG", "Invalid dog profile", requestId(), category = FailureCategory.CONTENT)) }
        }

        post("/dogs/{dogId}/events") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "dog:write")) return@post
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            val body = try { call.receive<DogEventCreateRequest>() } catch (_: Exception) { return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_EVENT", "Invalid dog event", requestId(), category = FailureCategory.CONTENT)) }
            if (dogId != body.dogId || !SecurityPolicy.validOpaque(dogId, 128)) return@post call.respond(HttpStatusCode.BadRequest, ApiError("DOG_ID_MISMATCH", "Dog id mismatch", requestId(), category = FailureCategory.CONTENT))
            try { call.respond(HttpStatusCode.Created, ecosystem.addDogEvent(principal.userId, body)) }
            catch (_: IllegalArgumentException) { call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_EVENT", "Invalid dog event", requestId(), category = FailureCategory.CONTENT)) }
        }

        get("/dogs/{dogId}/events") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "dog:read")) return@get
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            val limit = call.request.queryParameters["limit"]?.toIntOrNull() ?: 100
            if (!SecurityPolicy.validOpaque(dogId, 128)) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_ID", "Invalid dog id", requestId()))
            if (limit !in 1..200) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_LIMIT", "Invalid limit", requestId()))
            call.respond(ecosystem.listDogEvents(principal.userId, dogId, limit))
        }

        put("/devices/{deviceId}") {
            val principal = call.requirePrincipal(verifier) ?: return@put call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "device:write")) return@put
            val deviceId = call.parameters["deviceId"]?.trim().orEmpty()
            val body = try { call.receive<DeviceUpsertRequest>() } catch (_: Exception) { return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DEVICE_REQUEST", "Invalid device request", requestId())) }
            if (deviceId != body.deviceId || !SecurityPolicy.validOpaque(deviceId, 128)) return@put call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DEVICE_ID", "Invalid device id", requestId()))
            try { call.respond(ecosystem.upsertDevice(principal.userId, body)) } catch (_: IllegalArgumentException) { call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DEVICE", "Invalid device", requestId())) }
        }

        get("/devices") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "device:read")) return@get
            call.respond(ecosystem.listDevices(principal.userId, call.request.queryParameters["dogId"]?.trim()?.takeIf { it.isNotBlank() }))
        }

        post("/vet/access") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "vet:write")) return@post
            val body = try { call.receive<VetAccessCreateRequest>() } catch (_: Exception) { return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_VET_ACCESS", "Invalid veterinary access request", requestId())) }
            try { call.respond(HttpStatusCode.Created, ecosystem.createVetAccess(principal.userId, body)) } catch (_: IllegalArgumentException) { call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_VET_ACCESS", "Invalid veterinary access request", requestId())) }
        }

        get("/dogs/{dogId}/vet/access") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "vet:read")) return@get
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            if (!SecurityPolicy.validOpaque(dogId, 128)) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_ID", "Invalid dog id", requestId()))
            call.respond(ecosystem.listVetAccess(principal.userId, dogId))
        }

        delete("/vet/access/{grantId}") {
            val principal = call.requirePrincipal(verifier) ?: return@delete call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "vet:write")) return@delete
            val ok = ecosystem.revokeVetAccess(principal.userId, call.parameters["grantId"].orEmpty())
            if (ok) call.respond(HttpStatusCode.NoContent) else call.respond(HttpStatusCode.NotFound, ApiError("VET_ACCESS_NOT_FOUND", "Access grant not found", requestId()))
        }

        get("/vet/dogs/{dogId}") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "vet:read")) return@get
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            if (!SecurityPolicy.validOpaque(dogId, 128)) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_DOG_ID", "Invalid dog id", requestId()))
            val dog = ecosystem.getDogForVet(principal.userId, dogId) ?: return@get call.respond(HttpStatusCode.NotFound, ApiError("VET_DOG_NOT_FOUND", "Dog is not shared with this veterinary account", requestId()))
            call.respond(dog)
        }

        post("/dogs/{dogId}/safety/events") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "safety:write")) return@post
            val body = try { call.receive<SafetyEventCreateRequest>() } catch (_: Exception) { return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_SAFETY_EVENT", "Invalid safety event", requestId())) }
            if (body.dogId != call.parameters["dogId"]) return@post call.respond(HttpStatusCode.BadRequest, ApiError("DOG_ID_MISMATCH", "Dog id mismatch", requestId()))
            try { call.respond(HttpStatusCode.Created, ecosystem.addSafetyEvent(principal.userId, body)) } catch (_: IllegalArgumentException) { call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_SAFETY_EVENT", "Invalid safety event", requestId())) }
        }

        get("/dogs/{dogId}/safety/events") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "safety:read")) return@get
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            val limit = call.request.queryParameters["limit"]?.toIntOrNull() ?: 100
            if (!SecurityPolicy.validOpaque(dogId, 128) || limit !in 1..200) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_SAFETY_QUERY", "Invalid safety query", requestId()))
            call.respond(ecosystem.listSafetyEvents(principal.userId, dogId, limit))
        }

        get("/dogs/{dogId}/ai/insights") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "ai:read")) return@get
            val dogId = call.parameters["dogId"]?.trim().orEmpty()
            val limit = call.request.queryParameters["limit"]?.toIntOrNull() ?: 50
            if (!SecurityPolicy.validOpaque(dogId, 128) || limit !in 1..100) return@get call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_AI_QUERY", "Invalid AI query", requestId()))
            call.respond(ecosystem.listAiInsights(principal.userId, dogId, limit))
        }

        get("/entitlements") {
            val principal = call.requirePrincipal(verifier) ?: return@get call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId()))
            if (!call.requireScope(principal, "entitlement:read")) return@get
            call.respond(entitlements.list(principal.userId))
        }

        post("/billing/google-play/rtdn") {
            val auth = call.request.headers[HttpHeaders.Authorization]
            if (!rtdnAuthenticator.configured() || !rtdnAuthenticator.verify(auth)) {
                return@post call.respond(HttpStatusCode.Unauthorized, ApiError("RTDN_UNAUTHORIZED", "Invalid notification authentication", requestId(), category = FailureCategory.AUTH))
            }
            val envelope = try { call.receive<com.rockyx.backend.billing.PubSubPushEnvelope>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_RTDN_ENVELOPE", "Invalid Pub/Sub envelope", requestId(), category = FailureCategory.BILLING))
            }
            val message = envelope.message ?: return@post call.respond(HttpStatusCode.BadRequest, ApiError("MISSING_RTDN_MESSAGE", "Pub/Sub message is required", requestId(), category = FailureCategory.BILLING))
            val messageId = message.messageId?.takeIf { SecurityPolicy.validOpaque(it, 256) }
                ?: return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_RTDN_MESSAGE_ID", "Invalid Pub/Sub message id", requestId(), category = FailureCategory.BILLING))
            if (!rtdnMessages.claim(messageId)) return@post call.respond(HttpStatusCode.NoContent)
            try {
                val encoded = message.data?.takeIf { it.length in 1..1_000_000 }
                    ?: throw IllegalArgumentException("Missing RTDN data")
                val decoded = String(Base64.getDecoder().decode(encoded), Charsets.UTF_8)
                val notification = json.decodeFromString<com.rockyx.backend.billing.PlayRtdn>(decoded)
                val expectedPackage = System.getenv("ROCKYX_PLAY_PACKAGE_NAME")
                if (expectedPackage.isNullOrBlank() || notification.packageName != expectedPackage) {
                    throw IllegalArgumentException("RTDN package mismatch")
                }
                notification.subscriptionNotification?.let { sub ->
                    val token = sub.purchaseToken?.takeIf { it.length in 20..4096 }
                        ?: throw IllegalArgumentException("Missing subscription purchase token")
                    val tokenHash = java.security.MessageDigest.getInstance("SHA-256").digest(token.toByteArray()).joinToString("") { "%02x".format(it) }
                    val existing = purchases.findByTokenHash(tokenHash)
                    if (existing == null) {
                        telemetry.count("billing.rtdn.unknown_token")
                    } else {
                        val verified = playBilling.verifySubscription(existing.productId, token)
                        purchases.upsert(VerifiedPurchaseRecord(existing.userId, verified.productId, verified.purchaseTokenHash, verified.state, verified.acknowledged, System.currentTimeMillis()))
                        entitlements.upsert(existing.userId, EntitlementResponse(verified.productId, verified.tier, verified.state, verified.expiresAtEpochMs))
                        if (verified.state == "ACTIVE" && !verified.acknowledged) {
                            runCatching { playBilling.acknowledgeSubscription(verified.productId, token) }
                                .onSuccess { purchases.upsert(VerifiedPurchaseRecord(existing.userId, verified.productId, verified.purchaseTokenHash, verified.state, true, System.currentTimeMillis())) }
                                .onFailure { telemetry.count("billing.acknowledge_failed") }
                        }
                        telemetry.count("billing.rtdn.reconciled", tags = mapOf("type" to (sub.notificationType?.toString() ?: "unknown"), "state" to verified.state))
                    }
                }
                notification.oneTimeProductNotification?.let { oneTime ->
                    telemetry.count("billing.rtdn.one_time_ignored", tags = mapOf("sku" to (oneTime.sku ?: "unknown")))
                }
                if (notification.testNotification != null) telemetry.count("billing.rtdn.test")
                rtdnMessages.markProcessed(messageId)
                call.respond(HttpStatusCode.NoContent)
            } catch (_: IllegalArgumentException) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_RTDN", "Invalid Google Play notification", requestId(), category = FailureCategory.BILLING))
            } catch (_: Exception) {
                telemetry.count("billing.rtdn.failed")
                return@post call.respond(HttpStatusCode.ServiceUnavailable, ApiError("RTDN_PROCESSING_FAILED", "Notification processing failed", requestId(), retryable = true, category = FailureCategory.BILLING))
            }
        }

        post("/billing/google-play/subscriptions/verify") {
            val principal = call.requirePrincipal(verifier) ?: return@post call.respond(HttpStatusCode.Unauthorized, ApiError("AUTH_REQUIRED", "Authentication required", requestId(), category = FailureCategory.AUTH))
            if (!call.requireScope(principal, "entitlement:write")) return@post
            val idem = call.request.headers["Idempotency-Key"]
            if (!SecurityPolicy.validIdempotencyKey(idem)) return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_IDEMPOTENCY_KEY", "Invalid Idempotency-Key", requestId(), category = FailureCategory.BILLING))
            val body = try { call.receive<PlayPurchaseVerifyRequest>() } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_PURCHASE_REQUEST", "Invalid purchase request", requestId(), category = FailureCategory.BILLING))
            }
            if (!SecurityPolicy.validOpaque(body.productId, 200) || body.purchaseToken.length !in 20..4096) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_PURCHASE_REQUEST", "Invalid purchase request", requestId(), category = FailureCategory.BILLING))
            }
            val prior = idempotency.get(principal.userId, idem)
            if (prior != null) return@post call.respondText(prior, ContentType.Application.Json)
            if (!playBilling.configured()) return@post call.respond(HttpStatusCode.ServiceUnavailable, ApiError("BILLING_NOT_CONFIGURED", "Google Play billing verification is not configured", requestId(), retryable = true, category = FailureCategory.BILLING))
            val verified = try { playBilling.verifySubscription(body.productId, body.purchaseToken) } catch (e: IllegalArgumentException) {
                return@post call.respond(HttpStatusCode.BadRequest, ApiError("INVALID_PURCHASE", "Purchase could not be verified", requestId(), category = FailureCategory.BILLING))
            } catch (_: Exception) {
                return@post call.respond(HttpStatusCode.BadGateway, ApiError("PLAY_VERIFICATION_FAILED", "Google Play verification failed", requestId(), retryable = true, category = FailureCategory.BILLING))
            }
            val existing = purchases.findByTokenHash(verified.purchaseTokenHash)
            if (existing != null && existing.userId != principal.userId) {
                return@post call.respond(HttpStatusCode.Conflict, ApiError("PURCHASE_TOKEN_ALREADY_LINKED", "Purchase token is already linked to another account", requestId(), category = FailureCategory.BILLING))
            }
            accounts.getOrCreate(principal.userId)
            val claim = VerifiedPurchaseRecord(principal.userId, verified.productId, verified.purchaseTokenHash, verified.state, verified.acknowledged, System.currentTimeMillis())
            if (!purchases.claim(claim)) {
                return@post call.respond(HttpStatusCode.Conflict, ApiError("PURCHASE_TOKEN_ALREADY_LINKED", "Purchase token is already linked to another account", requestId(), category = FailureCategory.BILLING))
            }
            val entitlement = EntitlementResponse(verified.productId, verified.tier, verified.state, verified.expiresAtEpochMs)
            entitlements.upsert(principal.userId, entitlement)
            var acknowledged = verified.acknowledged
            if (verified.state == "ACTIVE" && !acknowledged) {
                try { playBilling.acknowledgeSubscription(verified.productId, body.purchaseToken); acknowledged = true }
                catch (_: Exception) { telemetry.count("billing.acknowledge_failed"); acknowledged = false }
            }
            purchases.upsert(VerifiedPurchaseRecord(principal.userId, verified.productId, verified.purchaseTokenHash, verified.state, acknowledged, System.currentTimeMillis()))
            telemetry.count("billing.purchase.verified", tags = mapOf("tier" to verified.tier, "state" to verified.state))
            val response = PlayPurchaseVerifyResponse(verified.productId, verified.tier, verified.state, verified.expiresAtEpochMs, acknowledged)
            idempotency.put(principal.userId, idem, json.encodeToString(response))
            call.respond(response)
        }
    }
}


package com.rockyx.backend.infra.db

import com.rockyx.backend.domain.EntitlementResponse
import com.rockyx.backend.infra.*
import java.time.OffsetDateTime
import java.time.ZoneOffset
import javax.sql.DataSource

class PostgresEntitlementRepository(private val ds: DataSource) : EntitlementRepository {
    override fun list(userId: String): List<EntitlementResponse> = ds.connection.use { c ->
        c.prepareStatement("SELECT product_id,tier,state,expires_at FROM entitlements WHERE user_id=? ORDER BY product_id").use { ps ->
            ps.setString(1, userId)
            ps.executeQuery().use { rs -> buildList {
                while (rs.next()) add(EntitlementResponse(rs.getString(1), rs.getString(2), rs.getString(3), rs.getObject(4, OffsetDateTime::class.java)?.toInstant()?.toEpochMilli()))
            }}
        }
    }

    override fun upsert(userId: String, entitlement: EntitlementResponse) = ds.connection.use { c ->
        c.prepareStatement("""
            INSERT INTO entitlements(user_id,product_id,tier,state,starts_at,expires_at,source,updated_at)
            VALUES (?,?,?,?,?,?,?,now())
            ON CONFLICT(user_id,product_id) DO UPDATE SET tier=EXCLUDED.tier,state=EXCLUDED.state,
              expires_at=EXCLUDED.expires_at,source=EXCLUDED.source,updated_at=now()
        """.trimIndent()).use { ps ->
            ps.setString(1,userId); ps.setString(2,entitlement.productId); ps.setString(3,entitlement.tier); ps.setString(4,entitlement.state)
            ps.setObject(5, OffsetDateTime.now(ZoneOffset.UTC)); if (entitlement.expiresAtEpochMs == null) ps.setObject(6,null) else ps.setObject(6, OffsetDateTime.ofInstant(java.time.Instant.ofEpochMilli(entitlement.expiresAtEpochMs), ZoneOffset.UTC)); ps.setString(7,"google-play")
            ps.executeUpdate()
        }
    }
}

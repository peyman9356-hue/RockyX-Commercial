package com.rockyx.backend.infra.db

import com.rockyx.backend.infra.*
import java.time.OffsetDateTime
import java.time.ZoneOffset
import javax.sql.DataSource

class PostgresPurchaseRepository(private val ds: DataSource) : PurchaseRepository {
    override fun findByTokenHash(tokenHash: String): VerifiedPurchaseRecord? = ds.connection.use { c ->
        c.prepareStatement("SELECT user_id,product_id,purchase_token_hash,state,acknowledged,updated_at FROM google_play_purchases WHERE purchase_token_hash=?").use { ps ->
            ps.setString(1,tokenHash); ps.executeQuery().use { rs -> if (rs.next()) VerifiedPurchaseRecord(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getBoolean(5),rs.getObject(6,OffsetDateTime::class.java).toInstant().toEpochMilli()) else null }
        }
    }

    override fun claim(record: VerifiedPurchaseRecord): Boolean = ds.connection.use { c ->
        c.prepareStatement("""
            INSERT INTO google_play_purchases(purchase_token_hash,user_id,product_id,state,acknowledged,updated_at)
            VALUES(?,?,?,?,?,now()) ON CONFLICT(purchase_token_hash) DO NOTHING
        """.trimIndent()).use { ps ->
            ps.setString(1,record.purchaseTokenHash); ps.setString(2,record.userId); ps.setString(3,record.productId); ps.setString(4,record.state); ps.setBoolean(5,record.acknowledged)
            val inserted = ps.executeUpdate() == 1
            if (inserted) true else findByTokenHash(record.purchaseTokenHash)?.userId == record.userId
        }
    }

    override fun upsert(record: VerifiedPurchaseRecord) = ds.connection.use { c ->
        c.prepareStatement("""
          INSERT INTO google_play_purchases(user_id,product_id,purchase_token_hash,state,acknowledged,updated_at)
          VALUES(?,?,?,?,?,now()) ON CONFLICT(purchase_token_hash) DO UPDATE SET user_id=EXCLUDED.user_id,product_id=EXCLUDED.product_id,state=EXCLUDED.state,acknowledged=EXCLUDED.acknowledged,updated_at=now()
        """.trimIndent()).use { ps ->
            ps.setString(1,record.userId); ps.setString(2,record.productId); ps.setString(3,record.purchaseTokenHash); ps.setString(4,record.state); ps.setBoolean(5,record.acknowledged); ps.executeUpdate()
        }
    }
}

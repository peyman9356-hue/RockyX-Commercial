package com.rockyx.backend.auth

import com.auth0.jwk.JwkProviderBuilder
import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import java.net.URI
import java.security.interfaces.RSAPublicKey
import java.util.concurrent.TimeUnit

/** Verifies Google OIDC ID tokens. The server never trusts the client-supplied user id/email. */
class GoogleIdentityVerifier(private val config: GoogleIdentityConfig) : AccessTokenVerifier {
    private val jwks = JwkProviderBuilder(config.jwksUrl)
        .cached(10, 24, TimeUnit.HOURS)
        .rateLimited(10, 1, TimeUnit.MINUTES)
        .build()

    override suspend fun verify(bearerToken: String): AuthenticatedPrincipal? = try {
        val decoded = JWT.decode(bearerToken)
        if (decoded.algorithm != "RS256") return null
        val keyId = decoded.keyId?.takeIf { it.isNotBlank() } ?: return null
        val publicKey = jwks.get(keyId).publicKey as? RSAPublicKey ?: return null
        val verifier = JWT.require(Algorithm.RSA256(publicKey, null))
            .withIssuer(config.issuer)
            .withAudience(config.clientId)
            .build()
        val jwt = verifier.verify(bearerToken)
        val subject = jwt.subject?.takeIf { it.isNotBlank() && it.length <= 256 } ?: return null
        AuthenticatedPrincipal(subject, "google")
    } catch (_: Exception) { null }
}

data class GoogleIdentityConfig(
    val clientId: String,
    val issuer: String = "https://accounts.google.com",
    val jwksUrl: String = "https://www.googleapis.com/oauth2/v3/certs"
) {
    init {
        require(clientId.isNotBlank() && clientId.length <= 512)
        require(URI(jwksUrl).scheme == "https")
        require(issuer == "https://accounts.google.com" || issuer == "accounts.google.com")
    }

    companion object {
        fun fromEnvironment(env: Map<String, String> = System.getenv()): GoogleIdentityConfig? =
            env["ROCKYX_GOOGLE_WEB_CLIENT_ID"]?.trim()?.takeIf { it.isNotBlank() }?.let { GoogleIdentityConfig(it) }
    }
}

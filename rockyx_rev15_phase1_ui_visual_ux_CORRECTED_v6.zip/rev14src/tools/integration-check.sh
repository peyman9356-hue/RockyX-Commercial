#!/usr/bin/env bash
set -euo pipefail

echo "[1/9] version consistency"
grep -q 'versionCode = 36' app/build.gradle.kts
grep -q 'versionName = "0.32.6"' app/build.gradle.kts
grep -q 'baselineVersion=0.32.6' VERSION.txt
grep -q 'architectureRevision=14' VERSION.txt
grep -q 'uxPolicy=UX-01_SIMPLE_FAST_OWNER_FIRST' VERSION.txt

echo "[2/9] required modules"
# JVM target policy: Android Java and Kotlin bytecode must be aligned at 17.
grep -q 'sourceCompatibility = JavaVersion.VERSION_17' app/build.gradle.kts
grep -q 'targetCompatibility = JavaVersion.VERSION_17' app/build.gradle.kts
grep -q 'jvmTarget.set(JvmTarget.JVM_17)' app/build.gradle.kts
grep -q 'androidx.media3:media3-datasource' app/build.gradle.kts
grep -q 'androidx.media3:media3-database' app/build.gradle.kts
grep -q 'import io.ktor.http.isSuccess' app/src/main/java/com/rockyx/app/data/network/RockyXApiClient.kt
grep -q 'Content-Type' app/src/main/java/com/rockyx/app/data/network/RockyXApiClient.kt
grep -q 'import com.rockyx.app.BuildConfig' app/src/main/java/com/rockyx/app/ui/AppController.kt
test -f app/src/main/java/com/rockyx/app/ui/AppController.kt
test -f app/src/main/java/com/rockyx/app/MainActivity.kt
test -f backend/src/main/kotlin/com/rockyx/backend/Application.kt

grep -q 'import io.ktor.server.request.*' backend/src/main/kotlin/com/rockyx/backend/Application.kt
grep -q 'ContentNegotiation' backend/src/main/kotlin/com/rockyx/backend/Application.kt
grep -q 'call.requestId()' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt
grep -q 'toList()' backend/src/main/kotlin/com/rockyx/backend/ai/Personalization.kt
grep -q 'consumeActiveByRefreshHash' backend/src/main/kotlin/com/rockyx/backend/infra/Repositories.kt
grep -q 'FOR UPDATE' backend/src/main/kotlin/com/rockyx/backend/infra/db/PostgresRepositories.kt
grep -q 'verifyUploadedObject' backend/src/main/kotlin/com/rockyx/backend/media/ObjectStoragePort.kt
grep -q 'MEDIA_UPLOAD_NOT_VERIFIED' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt
grep -q 'scopes = scopes, roles = roles' backend/src/main/kotlin/com/rockyx/backend/auth/SessionAuth.kt
grep -q 'account:write' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt
grep -q 'entitlement:write' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt

grep -q 'android:usesCleartextTraffic="false"' app/src/main/AndroidManifest.xml
grep -q 'android:name=".media.RockyXDownloadService"' app/src/main/AndroidManifest.xml
test -f app/src/main/java/com/rockyx/app/media/MediaDownloadService.kt

echo "[3/9] manifest and security boundaries"
! grep -R -nE 'AIza[0-9A-Za-z_-]{20,}|BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|ghp_[0-9A-Za-z]{30,}' app backend --exclude-dir=build --exclude='*.md' || true
! grep -R -n 'println(.*token\|Log\..*token' app/src backend/src --include='*.kt' || true

echo "[4/9] no fake production identity/payment shortcuts"
! grep -R -nE 'local-anonymous.*upload|fake.*payment|fake.*auth|TODO.*production' app/src/main backend/src/main --include='*.kt' || true

echo "[5/9] API route/client contract anchors"
grep -q '/api/v1/auth/exchange' app/src/main/java/com/rockyx/app/data/network/RockyXApiClient.kt
grep -q 'post("/auth/exchange")' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt
grep -q '/api/v1/entitlements' app/src/main/java/com/rockyx/app/data/network/RockyXApiClient.kt
grep -q 'get("/entitlements")' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt

echo "[6/9] content and commerce data boundaries"
test -f app/src/main/assets/content/catalog_v1.json
test -f app/src/main/assets/commerce/catalog_v1.json

echo "[7/9] migrations"
for f in backend/src/main/resources/db/migration/V{1..11}_*.sql; do test -f "$f"; done

echo "[8/9] integrated feature anchors"
for f in \
 app/src/main/java/com/rockyx/app/media/MediaEngine.kt \
 app/src/main/java/com/rockyx/app/ai/Personalization.kt \
 app/src/main/java/com/rockyx/app/data/commerce/GooglePlayBillingClient.kt \
 app/src/main/java/com/rockyx/app/data/account/GoogleCredentialManagerIdentityProvider.kt \
 app/src/main/java/com/rockyx/app/data/submission/SubmissionStore.kt \
 backend/src/main/kotlin/com/rockyx/backend/billing/GooglePlayBilling.kt; do test -f "$f"; done

echo "[9/9] Gradle project structure"
test -f settings.gradle.kts
test -f build.gradle.kts
test -f app/build.gradle.kts
test -f backend/build.gradle.kts
test ! -e app/build/outputs/apk/debug/app-debug.apk
test -f ROCKY_X_MASTER_PRODUCT_DEFINITION.md
test -f ROCKY_X_MASTER_SYSTEM_ARCHITECTURE.md
test -f ROCKY_X_GAP_REPAIR_PLAN.md
test -f ROCKY_X_CAPABILITY_MATRIX.md
echo "Rocky X ecosystem architecture checks: PASS"
grep -q 'class SessionAccessTokenVerifier' backend/src/main/kotlin/com/rockyx/backend/auth/SessionAuth.kt
grep -q 'sessions.isActive' backend/src/main/kotlin/com/rockyx/backend/auth/SessionAuth.kt
grep -q 'CompositeAccessTokenVerifier(sessionVerifierInMemory)' backend/src/main/kotlin/com/rockyx/backend/Application.kt
grep -q 'CompositeAccessTokenVerifier(sessionVerifierPostgres)' backend/src/main/kotlin/com/rockyx/backend/Application.kt
grep -q 'val serverScopes' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt
grep -q 'ROCKYX_MEDIA_SECURITY_SCANNER' backend/src/main/kotlin/com/rockyx/backend/Application.kt
grep -q 'get("/internal/metrics")' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt
grep -q 'respond(HttpStatusCode.NotFound)' backend/src/main/kotlin/com/rockyx/backend/api/Routes.kt

! grep -R -n "CompleteExercise(progress)\|UpdateMission(progress)" app/src/main/java --include="*.kt" || true

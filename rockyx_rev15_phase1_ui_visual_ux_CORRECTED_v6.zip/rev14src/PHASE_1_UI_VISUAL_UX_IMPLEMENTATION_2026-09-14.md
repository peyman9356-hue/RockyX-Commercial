# Rocky X — Phase 1 UI / Visual / UX

Scope: fixed professional shell, Home center, More Menu, Library, Account at bottom of Library, expandable categories, bottom composer, overlay/back behavior.

Reference-driven design is the governing basis. No unverified green palette is promoted to the brand UI.

This revision is not release-ready until CI build, real-device smoke test, and reference comparison pass.

# Rocky X — SIT Product Wedge V1 — V8-integrated prototype patch

DESIGN / VALIDATION ONLY. Not production-ready and not scientifically validated.

Integration target: extracted Rocky X Rev15 Phase1 V8 (`rev14src`).

This revision deliberately keeps Training Decision Engine models under `domain.training` and reuses the existing V8 `DogProfile` in `domain.model.Models.kt`; it does not create a duplicate dog profile model. It also adds validation for session ownership and evidence linkage.

Files:
- `app/src/main/java/com/rockyx/app/domain/training/TrainingModels.kt`
- `app/src/main/java/com/rockyx/app/domain/training/SitSessionAggregator.kt`
- `app/src/main/java/com/rockyx/app/domain/training/TrainingDecisionEngine.kt`
- `app/src/main/java/com/rockyx/app/domain/training/TrainingValidation.kt`
- `app/src/test/java/com/rockyx/app/domain/training/SitDecisionEngineTest.kt`

No MainActivity/UI/backend/billing/auth/media files are changed.

The aggregation thresholds remain prototype-only and are not a dog-training mastery standard.

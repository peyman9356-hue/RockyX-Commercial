package com.rockyx.app.domain.training

/**
 * Prototype-only deterministic policy.
 *
 * IMPORTANT:
 * This is a product-validation rule set, not a scientifically validated
 * mastery standard. Production thresholds remain OPEN until validated.
 */
object SitSessionAggregator {
    const val RULE_VERSION = "SIT_AGGREGATION_V1_PROTOTYPE"

    fun evaluate(
        session: TrainingSession,
        evidence: List<SitEvidence>,
        evaluationId: String = "eval-${session.sessionId}"
    ): Evaluation {
        require(session.attempts.isNotEmpty()) { "Session must contain at least one attempt." }
        require(TrainingValidation.validateSession(session).isEmpty()) { "Invalid training session." }
        val evidenceById = evidence.associateBy { it.evidenceId }
        val valid = session.attempts
            .flatMap { it.evidenceIds }
            .mapNotNull(evidenceById::get)
            .filter { it.status == EvidenceStatus.VALID }
            .filter { it.dogId == session.dogId }
            .filter { it.sessionId == null || it.sessionId == session.sessionId }
            .filter { it.attemptId == null || session.attempts.any { a -> a.attemptId == it.attemptId && it.evidenceId in a.evidenceIds } }

        if (valid.isEmpty()) {
            return Evaluation(
                evaluationId, session.sessionId,
                session.attempts.map { it.attemptId }, emptyList(),
                EvaluationResult.NOT_ASSESSED, EvaluationStatus.INSUFFICIENT,
                ConfidenceTier.LOW, RULE_VERSION
            )
        }

        val passes = valid.count { it.sitResult == SitResult.YES }
        val fails = valid.count { it.sitResult == SitResult.NO }

        val result = when {
            valid.size >= 3 && passes == valid.size -> EvaluationResult.PASS
            passes > fails -> EvaluationResult.PARTIAL
            fails > passes -> EvaluationResult.FAIL
            else -> EvaluationResult.PARTIAL
        }

        val confidence = when {
            valid.size >= 3 -> ConfidenceTier.MEDIUM
            else -> ConfidenceTier.LOW
        }

        return Evaluation(
            evaluationId = evaluationId,
            sessionId = session.sessionId,
            attemptIds = session.attempts.map { it.attemptId },
            evidenceIds = valid.map { it.evidenceId },
            result = result,
            status = EvaluationStatus.VALID,
            confidenceTier = confidence,
            evaluationRuleVersion = RULE_VERSION
        )
    }
}

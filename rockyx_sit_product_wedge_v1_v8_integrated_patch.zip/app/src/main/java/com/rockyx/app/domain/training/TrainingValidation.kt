package com.rockyx.app.domain.training

object TrainingValidation {
    fun validateSession(session: TrainingSession): List<String> = buildList {
        if (session.sessionId.isBlank()) add("SESSION_ID_REQUIRED")
        if (session.dogId.isBlank()) add("DOG_ID_REQUIRED")
        if (session.skillId.isBlank()) add("SKILL_ID_REQUIRED")
        if (session.contextId.isBlank()) add("CONTEXT_ID_REQUIRED")
        val ids = session.attempts.map { it.attemptId }
        if (ids.size != ids.toSet().size) add("DUPLICATE_ATTEMPT_ID")
        session.attempts.forEach { a ->
            if (a.sessionId != session.sessionId) add("ATTEMPT_SESSION_MISMATCH:${a.attemptId}")
            if (a.sequenceNumber < 1) add("INVALID_ATTEMPT_SEQUENCE:${a.attemptId}")
            if (a.evidenceIds.any(String::isBlank)) add("BLANK_EVIDENCE_ID:${a.attemptId}")
        }
    }

    fun validateEvidence(session: TrainingSession, evidence: List<SitEvidence>): List<String> = buildList {
        val attemptMap = session.attempts.associateBy { it.attemptId }
        evidence.forEach { e ->
            if (e.dogId != session.dogId) add("EVIDENCE_DOG_MISMATCH:${e.evidenceId}")
            if (e.sessionId != null && e.sessionId != session.sessionId) add("EVIDENCE_SESSION_MISMATCH:${e.evidenceId}")
            e.attemptId?.let { id ->
                if (attemptMap[id] == null) add("UNKNOWN_ATTEMPT:${e.evidenceId}")
            }
        }
    }
}

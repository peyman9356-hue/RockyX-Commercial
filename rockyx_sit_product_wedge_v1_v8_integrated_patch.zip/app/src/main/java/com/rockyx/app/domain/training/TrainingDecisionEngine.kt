package com.rockyx.app.domain.training

object TrainingDecisionEngine {
    const val ENGINE_VERSION = "TRAINING_DECISION_ENGINE_V1_SIT_PROTOTYPE"

    fun deriveSkillState(
        dogId: String,
        skillId: String,
        evaluation: Evaluation,
        evidence: List<SitEvidence>
    ): SkillState {
        val valid = evidence.filter {
            it.evidenceId in evaluation.evidenceIds &&
            it.status == EvidenceStatus.VALID
        }

        val lureDependent = valid.any { it.lureStatus == LureStatus.REQUIRED }
        val result = evaluation.result

        val acquisition = when {
            evaluation.status != EvaluationStatus.VALID -> SkillAcquisition.UNKNOWN
            result == EvaluationResult.PASS && !lureDependent ->
                SkillAcquisition.RELIABLE
            result == EvaluationResult.PASS || result == EvaluationResult.PARTIAL ->
                SkillAcquisition.EMERGING
            result == EvaluationResult.FAIL ->
                SkillAcquisition.NOT_ESTABLISHED
            else -> SkillAcquisition.UNKNOWN
        }

        val mastery = when (acquisition) {
            SkillAcquisition.RELIABLE, SkillAcquisition.STRONG -> MasteryStatus.ACQUIRED
            SkillAcquisition.EMERGING -> MasteryStatus.NOT_MASTERED
            SkillAcquisition.NOT_ESTABLISHED -> MasteryStatus.REGRESSION
            SkillAcquisition.UNKNOWN -> MasteryStatus.NOT_MASTERED
        }

        val reasons = buildList {
            if (result == EvaluationResult.PASS) add("SESSION_PASS")
            if (result == EvaluationResult.FAIL) add("SESSION_FAIL")
            if (lureDependent) add("LURE_DEPENDENCE")
            if (valid.any { it.responseQuality != ResponseQuality.IMMEDIATE }) {
                add("RESPONSE_NOT_CONSISTENTLY_IMMEDIATE")
            }
            if (valid.isEmpty()) add("NO_VALID_EVIDENCE")
        }

        return SkillState(
            dogId = dogId,
            skillId = skillId,
            acquisition = acquisition,
            masteryStatus = mastery,
            lastEvaluatedSessionId = evaluation.sessionId,
            reasonCodes = reasons
        )
    }

    fun decide(
        dogId: String,
        skillId: String,
        evaluation: Evaluation,
        state: SkillState,
        decisionId: String = "decision-${evaluation.evaluationId}"
    ): Decision {
        val reasons = buildList {
            addAll(state.reasonCodes)
            add("TRIGGER_EVALUATION:${evaluation.evaluationId}")
        }

        val type = when {
            evaluation.status == EvaluationStatus.INSUFFICIENT ->
                DecisionType.REVIEW
            evaluation.result == EvaluationResult.FAIL ->
                DecisionType.SIMPLIFY
            state.acquisition == SkillAcquisition.EMERGING ->
                DecisionType.REPEAT
            state.acquisition == SkillAcquisition.RELIABLE ->
                DecisionType.ADVANCE
            else ->
                DecisionType.REVIEW
        }

        return Decision(
            decisionId = decisionId,
            dogId = dogId,
            skillId = skillId,
            triggeringEvaluationId = evaluation.evaluationId,
            type = type,
            reasonCodes = reasons,
            engineVersion = ENGINE_VERSION
        )
    }

    fun nextAction(decision: Decision, state: SkillState): NextAction =
        when (decision.type) {
            DecisionType.SIMPLIFY -> NextAction(
                decision.decisionId,
                "Simplify the Sit exercise",
                "Reduce the difficulty, then repeat Sit in the same calm context."
            )
            DecisionType.REPEAT -> NextAction(
                decision.decisionId,
                "Repeat Sit with less help",
                "Repeat in the same calm context and gradually reduce lure dependence."
            )
            DecisionType.ADVANCE -> NextAction(
                decision.decisionId,
                "Increase the challenge",
                "Move to a slightly more difficult context and test Sit again."
            )
            DecisionType.REVIEW -> NextAction(
                decision.decisionId,
                "Review the exercise",
                "Check the instruction and record another valid practice session."
            )
            else -> NextAction(
                decision.decisionId,
                "Continue practice",
                "Repeat the current exercise and record the next valid attempts."
            )
        }
}

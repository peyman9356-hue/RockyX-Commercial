package com.rockyx.app.domain.training

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SitDecisionEngineTest {

    private fun session() = TrainingSession(
        sessionId = "S1",
        dogId = "D-ROCKY",
        skillId = "sit",
        contextId = "C1",
        attempts = listOf(
            TrainingAttempt("A1", "S1", 1, listOf("E1")),
            TrainingAttempt("A2", "S1", 2, listOf("E2")),
            TrainingAttempt("A3", "S1", 3, listOf("E3"))
        )
    )

    @Test fun allSuccessfulWithLureProducesEmergingAndRepeat() {
        val s = session()
        val e = listOf(
            SitEvidence("E1","D-ROCKY","A1","S1","C1",CueType.VERBAL_AND_HAND_SIGNAL,LureStatus.REQUIRED,SitResult.YES,ResponseQuality.IMMEDIATE,RewardTiming.IMMEDIATE),
            SitEvidence("E2","D-ROCKY","A2","S1","C1",CueType.VERBAL_AND_HAND_SIGNAL,LureStatus.REQUIRED,SitResult.YES,ResponseQuality.IMMEDIATE,RewardTiming.IMMEDIATE),
            SitEvidence("E3","D-ROCKY","A3","S1","C1",CueType.VERBAL_AND_HAND_SIGNAL,LureStatus.REQUIRED,SitResult.YES,ResponseQuality.DELAYED,RewardTiming.IMMEDIATE)
        )
        val evaluation = SitSessionAggregator.evaluate(s, e)
        val state = TrainingDecisionEngine.deriveSkillState("D-ROCKY","sit",evaluation,e)
        val decision = TrainingDecisionEngine.decide("D-ROCKY","sit",evaluation,state)

        assertEquals(EvaluationResult.PASS, evaluation.result)
        assertEquals(SkillAcquisition.EMERGING, state.acquisition)
        assertEquals(DecisionType.REPEAT, decision.type)
        assertTrue(state.reasonCodes.contains("LURE_DEPENDENCE"))
    }

    @Test fun repeatedFailureSimplifies() {
        val s = session()
        val e = s.attempts.mapIndexed { i, a ->
            SitEvidence("E${i+1}","D-ROCKY",a.attemptId,"S1","C1",CueType.VERBAL,LureStatus.REQUIRED,SitResult.NO,ResponseQuality.REPROMPT_REQUIRED,RewardTiming.NOT_DELIVERED)
        }
        val evaluation = SitSessionAggregator.evaluate(s, e)
        val state = TrainingDecisionEngine.deriveSkillState("D-ROCKY","sit",evaluation,e)
        val decision = TrainingDecisionEngine.decide("D-ROCKY","sit",evaluation,state)

        assertEquals(EvaluationResult.FAIL, evaluation.result)
        assertEquals(DecisionType.SIMPLIFY, decision.type)
    }

    @Test fun invalidEvidenceCannotChangeState() {
        val s = session()
        val e = listOf(
            SitEvidence("E1","D-ROCKY","A1","S1","C1",CueType.VERBAL,LureStatus.NOT_REQUIRED,SitResult.YES,ResponseQuality.IMMEDIATE,RewardTiming.IMMEDIATE,status=EvidenceStatus.INVALID),
            SitEvidence("E2","D-ROCKY","A2","S1","C1",CueType.VERBAL,LureStatus.NOT_REQUIRED,SitResult.YES,ResponseQuality.IMMEDIATE,RewardTiming.IMMEDIATE,status=EvidenceStatus.INVALID)
        )
        val evaluation = SitSessionAggregator.evaluate(s, e)
        assertEquals(EvaluationStatus.INSUFFICIENT, evaluation.status)
        assertEquals(EvaluationResult.NOT_ASSESSED, evaluation.result)
    }

    @Test fun deterministicSameInputProducesSameOutput() {
        val s = session()
        val e = s.attempts.mapIndexed { i, a ->
            SitEvidence("E${i+1}","D-ROCKY",a.attemptId,"S1","C1",CueType.VERBAL,LureStatus.REQUIRED,SitResult.YES,ResponseQuality.IMMEDIATE,RewardTiming.IMMEDIATE)
        }
        val first = SitSessionAggregator.evaluate(s, e)
        val second = SitSessionAggregator.evaluate(s, e)
        assertEquals(first, second)
    }
}

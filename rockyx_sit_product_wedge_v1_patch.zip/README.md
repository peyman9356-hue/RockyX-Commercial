# Rocky X — SIT Product-Wedge V1 Prototype

This is a **prototype patch**, not a claim that the production Training Decision Engine is complete.

It implements one narrow deterministic loop:

Practice → Evidence → Session Evaluation → Skill State → Decision → Next Action

## Important

The aggregation thresholds are explicitly labeled prototype rules. They are **not** a scientifically validated dog-training mastery standard.

The patch is designed to be copied into the extracted `rev14src` project from Rocky X Rev15 Phase1 V8.

## Integration target

- `app/src/main/java/com/rockyx/app/domain/training/`
- `app/src/test/java/com/rockyx/app/domain/training/`

No existing V8 files are overwritten by this patch.

## Status

- Implementation: PROTOTYPE
- Production readiness: NO
- Scientific validation: OPEN
- Backend integration: NOT INCLUDED
- UI integration: NOT INCLUDED

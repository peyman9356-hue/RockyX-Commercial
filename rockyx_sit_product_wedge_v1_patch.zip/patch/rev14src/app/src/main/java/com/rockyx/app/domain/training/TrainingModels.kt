package com.rockyx.app.domain.training

enum class CueType { VERBAL, HAND_SIGNAL, VERBAL_AND_HAND_SIGNAL }
enum class LureStatus { REQUIRED, NOT_REQUIRED }
enum class SitResult { YES, NO }
enum class ResponseQuality { IMMEDIATE, DELAYED, REPROMPT_REQUIRED }
enum class RewardTiming { IMMEDIATE, LATE, NOT_DELIVERED }

enum class ContextType {
    HOME_CALM,
    OUTSIDE_CALM,
    OUTSIDE_DISTRACTION,
    UNKNOWN
}

enum class EvidenceStatus { VALID, INVALID, SUPERSEDED }

enum class EvaluationResult {
    NOT_ASSESSED, FAIL, PARTIAL, PASS, MASTERED
}

enum class EvaluationStatus {
    VALID, REVIEW_REQUIRED, SUPERSEDED, PENDING_REMOTE_EVALUATION, INSUFFICIENT
}

enum class ConfidenceTier { LOW, MEDIUM, HIGH }

enum class SkillAcquisition {
    NOT_ESTABLISHED, EMERGING, RELIABLE, STRONG, UNKNOWN
}

enum class MasteryStatus {
    NOT_MASTERED, ACQUIRED, MAINTENANCE, REGRESSION, REFRESH_NEEDED
}

enum class DecisionType {
    START, REPEAT, SIMPLIFY, ADVANCE, MAINTAIN, REFRESH,
    REVIEW, SAFETY_ESCALATION, NO_ACTION
}

data class DogProfileRef(
    val dogId: String
)

data class TrainingContext(
    val contextId: String,
    val type: ContextType
)

data class SitEvidence(
    val evidenceId: String,
    val dogId: String,
    val attemptId: String? = null,
    val sessionId: String? = null,
    val contextId: String,
    val cueType: CueType,
    val lureStatus: LureStatus,
    val sitResult: SitResult,
    val responseQuality: ResponseQuality,
    val rewardTiming: RewardTiming,
    val status: EvidenceStatus = EvidenceStatus.VALID,
    val schemaVersion: Int = 1
)

data class TrainingAttempt(
    val attemptId: String,
    val sessionId: String,
    val sequenceNumber: Int,
    val evidenceIds: List<String>
)

data class TrainingSession(
    val sessionId: String,
    val dogId: String,
    val skillId: String,
    val contextId: String,
    val attempts: List<TrainingAttempt>,
    val lessonId: String = "sit",
    val lessonVersion: Int = 1,
    val exerciseId: String = "sit-practice",
    val exerciseVersion: Int = 1
)

data class Evaluation(
    val evaluationId: String,
    val sessionId: String,
    val attemptIds: List<String>,
    val evidenceIds: List<String>,
    val result: EvaluationResult,
    val status: EvaluationStatus,
    val confidenceTier: ConfidenceTier,
    val evaluationRuleVersion: String,
    val evaluatorVersion: String = "SELF_REPORT_V1"
)

data class SkillState(
    val dogId: String,
    val skillId: String,
    val acquisition: SkillAcquisition,
    val masteryStatus: MasteryStatus,
    val lastEvaluatedSessionId: String?,
    val reasonCodes: List<String>
)

data class Decision(
    val decisionId: String,
    val dogId: String,
    val skillId: String,
    val triggeringEvaluationId: String,
    val type: DecisionType,
    val reasonCodes: List<String>,
    val engineVersion: String
)

data class NextAction(
    val decisionId: String,
    val title: String,
    val instruction: String
)
